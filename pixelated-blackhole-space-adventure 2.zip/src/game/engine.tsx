import { useEffect, useRef } from "react";
import { Input } from "./input";
import { AUDIO, sfx } from "./audio";
import { getSave, commit, type SaveState } from "./save";

export const VW = 320;
export const VH = 180;

export interface SceneCtx {
  W: number;
  H: number;
  input: Input;
  save: SaveState;
  goto: (screen: string, payload?: any) => void;
  sfx: (n: string) => void;
  shake: (a: number) => void;
  flash: (a: number, color?: string) => void;
  payload: any;
  time: number;
}

export interface Scene {
  music?: string | null;
  init?(c: SceneCtx): void;
  update(dt: number, c: SceneCtx): void;
  draw(ctx: CanvasRenderingContext2D, c: SceneCtx): void;
  dispose?(): void;
}

export function GameCanvas({
  makeScene,
  sceneKey,
  payload,
  onGoto,
  input,
  crt,
}: {
  makeScene: (key: string, payload: any) => Scene;
  sceneKey: string;
  payload: any;
  onGoto: (s: string, p?: any) => void;
  input: Input;
  crt: boolean;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gotoRef = useRef(onGoto);
  gotoRef.current = onGoto;
  const crtRef = useRef(crt);
  crtRef.current = crt;

  useEffect(() => {
    const cv = canvasRef.current;
    if (!cv) return;
    cv.width = VW;
    cv.height = VH;
    const ctx = cv.getContext("2d", { alpha: false })!;
    ctx.imageSmoothingEnabled = false;

    let shakeAmt = 0;
    let flashAmt = 0;
    let flashCol = "#ffffff";
    const c: SceneCtx = {
      W: VW,
      H: VH,
      input,
      save: getSave(),
      goto: (s, p) => gotoRef.current(s, p),
      sfx,
      shake: (a) => {
        if (getSave().settings.shake) shakeAmt = Math.max(shakeAmt, a);
      },
      flash: (a, col) => {
        flashAmt = Math.max(flashAmt, a);
        if (col) flashCol = col;
      },
      payload,
      time: 0,
    };

    const scene = makeScene(sceneKey, payload);
    scene.init?.(c);
    if (scene.music !== undefined) AUDIO.music(scene.music);

    let raf = 0;
    let last = performance.now();
    let acc = 0;

    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      let dt = (now - last) / 1000;
      last = now;
      if (dt > 0.1) dt = 0.1;
      c.time += dt;
      acc += dt;
      scene.update(dt, c);

      ctx.save();
      if (shakeAmt > 0.05) {
        const sx = (Math.random() - 0.5) * shakeAmt;
        const sy = (Math.random() - 0.5) * shakeAmt;
        ctx.translate(Math.round(sx), Math.round(sy));
        shakeAmt *= Math.pow(0.0025, dt);
      } else shakeAmt = 0;
      ctx.fillStyle = "#000";
      ctx.fillRect(-20, -20, VW + 40, VH + 40);
      scene.draw(ctx, c);
      ctx.restore();

      if (flashAmt > 0.01) {
        ctx.globalAlpha = Math.min(1, flashAmt);
        ctx.fillStyle = flashCol;
        ctx.fillRect(0, 0, VW, VH);
        ctx.globalAlpha = 1;
        flashAmt -= dt * 3.2;
      }
      if (crtRef.current) {
        ctx.globalAlpha = 0.14;
        ctx.fillStyle = "#000";
        for (let y = 0; y < VH; y += 2) ctx.fillRect(0, y, VW, 1);
        ctx.globalAlpha = 1;
      }
      if (acc > 1) {
        acc = 0;
        commit();
      }
      input.endFrame();
    };
    raf = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(raf);
      scene.dispose?.();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sceneKey, payload]);

  return (
    <canvas
      ref={canvasRef}
      className="pixelated block"
      style={{ width: "100%", height: "100%", objectFit: "contain", imageRendering: "pixelated" }}
    />
  );
}
