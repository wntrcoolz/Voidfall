import { AUDIO } from "./audio";

export interface HomeData {
  built: boolean;
  style: string;
  level: number;
  wall: number;
  floor: number;
  furniture: { id: string; x: number }[];
  name: string;
  lastRest?: number;
  days?: number;
}
export interface PlanetSave {
  visited: boolean;
  kills: number;
  wrecked: number;
  home: HomeData;
}
export interface SaveState {
  coins: number;
  gems: number;
  holes: number;
  ship: string;
  owned: string[];
  paint: number;
  decal: number;
  trail: number;
  upg: Record<string, number>;
  char: { skin: number; suit: number; hair: number; visor: number; name: string };
  planets: Record<string, PlanetSave>;
  settings: {
    sfx: number;
    music: number;
    crt: boolean;
    shake: boolean;
    autofire: boolean;
    touch: "auto" | "on" | "off";
    difficulty: 0 | 1 | 2;
  };
  codes: string[];
  stats: { kills: number; rocks: number; deaths: number; runs: number; ly: number; built: number };
  purchases: number;
}

const KEY = "voidfall_save_v2";

function freshPlanet(): PlanetSave {
  return {
    visited: false,
    kills: 0,
    wrecked: 0,
    home: { built: false, style: "shack", level: 1, wall: 0, floor: 0, furniture: [], name: "MY PLACE" },
  };
}

export function defaultSave(): SaveState {
  return {
    coins: 500,
    gems: 3,
    holes: 0,
    ship: "rust",
    owned: ["rust"],
    paint: 0,
    decal: 0,
    trail: 0,
    upg: { engine: 0, laser: 0, rof: 0, hull: 0, shield: 0, magnet: 0, spread: 0, drill: 0 },
    char: { skin: 0, suit: 1, hair: 0, visor: 0, name: "PILOT" },
    planets: {},
    settings: { sfx: 0.7, music: 0.45, crt: true, shake: true, autofire: true, touch: "auto", difficulty: 1 },
    codes: [],
    stats: { kills: 0, rocks: 0, deaths: 0, runs: 0, ly: 0, built: 0 },
    purchases: 0,
  };
}

let state: SaveState = load();
const listeners = new Set<() => void>();

function load(): SaveState {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const p = JSON.parse(raw);
      return { ...defaultSave(), ...p, settings: { ...defaultSave().settings, ...(p.settings || {}) }, upg: { ...defaultSave().upg, ...(p.upg || {}) }, char: { ...defaultSave().char, ...(p.char || {}) }, stats: { ...defaultSave().stats, ...(p.stats || {}) } };
    }
  } catch {
    /* ignore */
  }
  return defaultSave();
}

export function getSave(): SaveState {
  return state;
}

export function planetSave(id: string): PlanetSave {
  if (!state.planets[id]) state.planets[id] = freshPlanet();
  return state.planets[id];
}

let saveTimer: number | null = null;
export function commit() {
  listeners.forEach((l) => l());
  if (saveTimer) return;
  saveTimer = window.setTimeout(() => {
    saveTimer = null;
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* quota */
    }
  }, 250);
}

export function mutate(fn: (s: SaveState) => void) {
  fn(state);
  commit();
}

export function subscribe(l: () => void) {
  listeners.add(l);
  return () => listeners.delete(l);
}

export function resetSave() {
  const fresh = defaultSave();
  for (const k of Object.keys(state)) delete (state as any)[k];
  Object.assign(state, fresh);
  commit();
}

export function importSave(code: string): boolean {
  try {
    const json = decodeURIComponent(escape(atob(code.trim())));
    const p = JSON.parse(json);
    if (typeof p !== "object" || p == null) return false;
    const merged = { ...defaultSave(), ...p };
    for (const k of Object.keys(state)) delete (state as any)[k];
    Object.assign(state, merged);
    commit();
    return true;
  } catch {
    return false;
  }
}

export function exportSave(): string {
  try {
    return btoa(unescape(encodeURIComponent(JSON.stringify(state))));
  } catch {
    return "";
  }
}

export function applySettings() {
  AUDIO.setSfxVol(state.settings.sfx);
  AUDIO.setMusicVol(state.settings.music);
}

// ---- derived ship stats ----
import { SHIPS, UPGRADES } from "./data";
export function currentShip() {
  return SHIPS.find((s) => s.id === state.ship) || SHIPS[0];
}
export function shipStats() {
  const s = currentShip();
  const u = state.upg;
  return {
    speed: 52 + s.speed * 7 + u.engine * 7,
    fireDelay: Math.max(0.07, 0.34 - s.fire * 0.014 - u.rof * 0.016),
    dmg: 8 + s.dmg * 3 + u.laser * 4,
    maxHp: 50 + s.hull * 10 + u.hull * 18,
    shield: u.shield,
    magnet: 18 + u.magnet * 26,
    barrels: 1 + u.spread,
    drill: u.drill,
  };
}
export function maxUpg(id: string) {
  return UPGRADES.find((u) => u.id === id)?.max ?? 5;
}
