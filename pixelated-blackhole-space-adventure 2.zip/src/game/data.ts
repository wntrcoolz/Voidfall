// All static game data: ships, planets, upgrades, shop, furniture, codes, credits.

export interface ShipDef {
  id: string;
  name: string;
  desc: string;
  cost: number;
  currency: "coin" | "gem" | "free";
  speed: number; // 1-10
  fire: number; // 1-10
  dmg: number; // 1-10
  hull: number; // 1-10
  sprite: string;
}

export const SHIPS: ShipDef[] = [
  { id: "rust", name: "RUSTBUCKET", desc: "HELD TOGETHER BY DUCT TAPE AND HOPE.", cost: 0, currency: "free", speed: 4, fire: 4, dmg: 3, hull: 5, sprite: "rust" },
  { id: "needle", name: "NEEDLE MK2", desc: "FAST. FRAGILE. FABULOUS.", cost: 1200, currency: "coin", speed: 8, fire: 6, dmg: 3, hull: 3, sprite: "needle" },
  { id: "hauler", name: "HAULER-9", desc: "A FLYING BRICK WITH GUNS.", cost: 2400, currency: "coin", speed: 3, fire: 4, dmg: 6, hull: 9, sprite: "hauler" },
  { id: "viper", name: "VIPER-X", desc: "MILITARY SURPLUS. STILL WARM.", cost: 4800, currency: "coin", speed: 7, fire: 8, dmg: 6, hull: 5, sprite: "viper" },
  { id: "saucer", name: "STOLEN SAUCER", desc: "THE OWNERS WANT IT BACK.", cost: 30, currency: "gem", speed: 9, fire: 7, dmg: 7, hull: 6, sprite: "saucer" },
  { id: "obsidian", name: "OBSIDIAN", desc: "BUILT FROM COLLAPSED STAR METAL.", cost: 65, currency: "gem", speed: 8, fire: 9, dmg: 9, hull: 8, sprite: "obsidian" },
  { id: "lastlight", name: "THE LAST LIGHT", desc: "IT HAS SEEN THE OTHER SIDE.", cost: 120, currency: "gem", speed: 10, fire: 10, dmg: 10, hull: 10, sprite: "lastlight" },
];

export const PAINTS: { name: string; a: string; b: string; c: string }[] = [
  { name: "RUST", a: "#c9773a", b: "#7d3f20", c: "#f0c27b" },
  { name: "BONE", a: "#e8dcc0", b: "#9a8f74", c: "#c04a3a" },
  { name: "PLUM", a: "#a35cb0", b: "#5b2a63", c: "#f3a0d8" },
  { name: "MOSS", a: "#7fa04a", b: "#3f5a27", c: "#d8e07a" },
  { name: "ASH", a: "#9aa3ad", b: "#4e565f", c: "#e2b13c" },
  { name: "EMBER", a: "#e05a3c", b: "#8a2418", c: "#ffd08a" },
  { name: "DEEP", a: "#4a6fa5", b: "#233a5e", c: "#9fd4ff" },
  { name: "VOID", a: "#3a3350", b: "#1b1728", c: "#c7a8ff" },
];
PAINTS[2] = { name: "PLUM", a: "#a35cb0", b: "#5b2a63", c: "#f3a0d8" };

export const DECALS = ["NONE", "STRIPE", "CHEVRON", "SKULL", "STAR", "BOLT"];
export const TRAILS = [
  { name: "FIRE", c: ["#ffe9a0", "#ffae3b", "#e0562a"] },
  { name: "PLASMA", c: ["#dff4ff", "#7fc2e8", "#3a6ea8"] },
  { name: "TOXIC", c: ["#e8ff9f", "#8fd13f", "#3c6b1e"] },
  { name: "SOOT", c: ["#c4c4c4", "#7a7a7a", "#3d3d3d"] },
  { name: "VOID", c: ["#e0c2ff", "#8a5ad0", "#3b2260"] },
];

export interface UpgradeDef {
  id: string;
  name: string;
  desc: string;
  max: number;
  base: number;
}
export const UPGRADES: UpgradeDef[] = [
  { id: "engine", name: "ENGINE", desc: "MOVE FASTER", max: 8, base: 220 },
  { id: "laser", name: "LASER", desc: "MORE DAMAGE", max: 8, base: 260 },
  { id: "rof", name: "COOLANT", desc: "FASTER FIRE RATE", max: 8, base: 240 },
  { id: "hull", name: "HULL", desc: "MORE HEALTH", max: 8, base: 300 },
  { id: "shield", name: "SHIELD", desc: "ABSORBS 1 HIT, RECHARGES", max: 5, base: 500 },
  { id: "magnet", name: "MAGNET", desc: "PULLS IN LOOT", max: 5, base: 350 },
  { id: "spread", name: "MULTISHOT", desc: "EXTRA LASER BARRELS", max: 4, base: 900 },
  { id: "drill", name: "VOID DRILL", desc: "SURVIVE DEEPER IN THE HOLE", max: 6, base: 700 },
];
export const upgradeCost = (u: UpgradeDef, lvl: number) => Math.round(u.base * Math.pow(1.65, lvl));

export interface PlanetDef {
  id: string;
  name: string;
  desc: string;
  dist: number; // travel difficulty 1-10
  sky: [string, string];
  ground: string;
  ground2: string;
  rock: string;
  core: string;
  band: string;
  band2: string;
  ring?: boolean;
  hazard: string;
  alien: string;
  gravity: number;
  reward: number;
}

export const PLANETS: PlanetDef[] = [
  { id: "mercury", name: "MERCURY", desc: "SCORCHED ROCK. NO AIR. GREAT VIEWS.", dist: 2, sky: ["#2a2024", "#6b4a3a"], ground: "#8a7a6a", ground2: "#5d5148", rock: "#b5a394", core: "#9a8b7c", band: "#cfc0ae", band2: "#6e6055", hazard: "SOLAR FLARES", alien: "crawler", gravity: 0.38, reward: 120 },
  { id: "venus", name: "VENUS", desc: "ACID CLOUDS. MELTS MOST THINGS.", dist: 3, sky: ["#6b3a1e", "#d68b3c"], ground: "#c08a45", ground2: "#7d4f22", rock: "#e0a85c", core: "#e8a13c", band: "#f7d08a", band2: "#a35d1e", hazard: "ACID RAIN", alien: "blob", gravity: 0.9, reward: 180 },
  { id: "earth", name: "EARTH", desc: "HOME. YOU LEFT IT. IT IS FINE.", dist: 1, sky: ["#2b4a7a", "#8fc0e8"], ground: "#4a8a3c", ground2: "#2d5a26", rock: "#6f6f60", core: "#3a7ad4", band: "#5ec45a", band2: "#2d6bb0", hazard: "TRAFFIC", alien: "drone", gravity: 1, reward: 100 },
  { id: "mars", name: "MARS", desc: "RED DUST AND OLD SECRETS.", dist: 3, sky: ["#5b2a20", "#c67a52"], ground: "#a4502e", ground2: "#6b3018", rock: "#c9704a", core: "#c0392b", band: "#e07a55", band2: "#8a2b18", hazard: "DUST STORMS", alien: "strider", gravity: 0.38, reward: 200 },
  { id: "jupiter", name: "JUPITER", desc: "NO GROUND. WE BUILT A PLATFORM.", dist: 5, sky: ["#4a3320", "#c9a276"], ground: "#c9a276", ground2: "#8a6a44", rock: "#e0c49a", core: "#d9b382", band: "#f0dcbc", band2: "#9c6b3e", hazard: "CRUSHING WINDS", alien: "floater", gravity: 2.5, reward: 340 },
  { id: "saturn", name: "SATURN", desc: "THE RINGS ARE MOSTLY DEBRIS. AND SHIPS.", dist: 6, sky: ["#3a3346", "#b8a9c9"], ground: "#a89bbc", ground2: "#6a5f80", rock: "#cbbfdc", core: "#c8b48a", band: "#efe0bb", band2: "#8c7a55", ring: true, hazard: "RING SHRAPNEL", alien: "strider", gravity: 1.1, reward: 420 },
  { id: "uranus", name: "URANUS", desc: "COLD, SIDEWAYS, AND JUDGING YOU.", dist: 7, sky: ["#1e4a52", "#7fd0d8"], ground: "#6fb4c0", ground2: "#35707c", rock: "#9fdce6", core: "#6fd0dc", band: "#b6f0f7", band2: "#3d95a4", ring: true, hazard: "ICE SHARDS", alien: "blob", gravity: 0.9, reward: 480 },
  { id: "neptune", name: "NEPTUNE", desc: "SUPERSONIC WINDS. DIAMOND RAIN.", dist: 8, sky: ["#141f52", "#4a6fd8"], ground: "#3f57b0", ground2: "#22306e", rock: "#6d84d8", core: "#3550c8", band: "#7f96ee", band2: "#1c2a80", hazard: "DIAMOND RAIN", alien: "floater", gravity: 1.1, reward: 560 },
  { id: "pluto", name: "PLUTO", desc: "STILL A PLANET HERE. WE VOTED.", dist: 9, sky: ["#1a1626", "#5a5170"], ground: "#8d8496", ground2: "#4e4859", rock: "#bdb4c6", core: "#a89a9a", band: "#d8ccc8", band2: "#6a5c5c", hazard: "ABSOLUTE ZERO", alien: "crawler", gravity: 0.06, reward: 650 },
  { id: "sun", name: "THE SUN", desc: "DO NOT LAND. SERIOUSLY.", dist: 10, sky: ["#5a1a00", "#ffb43c"], ground: "#ff9a1e", ground2: "#c04e00", rock: "#ffd05a", core: "#ffb43c", band: "#fff0a0", band2: "#e05a00", hazard: "EVERYTHING", alien: "flare", gravity: 27, reward: 1500 },
];

export interface HomeStyle {
  id: string;
  name: string;
  cost: number;
  wall: string;
  wall2: string;
  roof: string;
  roof2: string;
}
export const HOME_STYLES: HomeStyle[] = [
  { id: "shack", name: "SCRAP SHACK", cost: 0, wall: "#8a7a5c", wall2: "#5c4f36", roof: "#9a5a3a", roof2: "#6a3a24" },
  { id: "pod", name: "SURVIVAL POD", cost: 900, wall: "#c2c8cf", wall2: "#7b838d", roof: "#c0553c", roof2: "#7d3324" },
  { id: "dome", name: "GLASS DOME", cost: 2600, wall: "#8fb6c9", wall2: "#4e7286", roof: "#b9d7e4", roof2: "#6d95a8" },
  { id: "base", name: "ALLOY BASE", cost: 5200, wall: "#7e8a99", wall2: "#4a5462", roof: "#d0a23c", roof2: "#8a681e" },
  { id: "citadel", name: "VOID CITADEL", cost: 25, wall: "#4a3f66", wall2: "#241d3c", roof: "#a07fd8", roof2: "#5b418f" },
];

export interface FurnitureDef {
  id: string;
  name: string;
  cost: number;
  w: number;
  h: number;
}
export const FURNITURE: FurnitureDef[] = [
  { id: "bed", name: "BUNK", cost: 200, w: 26, h: 12 },
  { id: "lamp", name: "LAMP", cost: 120, w: 7, h: 20 },
  { id: "console", name: "CONSOLE", cost: 450, w: 22, h: 16 },
  { id: "plant", name: "ALIEN PLANT", cost: 260, w: 12, h: 18 },
  { id: "rug", name: "RUG", cost: 90, w: 30, h: 4 },
  { id: "tv", name: "SCREEN", cost: 600, w: 24, h: 14 },
  { id: "crate", name: "CRATE", cost: 70, w: 12, h: 12 },
  { id: "trophy", name: "VOID TROPHY", cost: 1800, w: 10, h: 18 },
];

export const SKINS = ["#e8b48a", "#c98a5e", "#8a5a3a", "#5c3a24", "#a8d8a0", "#c0c8d8", "#d8a0c0"];
export const SUITS = ["#d8d8e0", "#e0552f", "#3a6ea8", "#4a8a3c", "#c9a23c", "#6a4a8a", "#2a2a33"];
export const HAIRS = ["#2a1a10", "#6b3a1a", "#d8c07a", "#c04a3a", "#8a8a9a", "#4a8ad8", "#e0e0e0"];
export const VISORS = ["#7fd0e8", "#e0c060", "#e07a7a", "#a0e090", "#dddddd", "#c090e0"];

export interface ShopPack {
  id: string;
  name: string;
  coins: number;
  gems: number;
  price: string;
  tag?: string;
}
export const COIN_PACKS: ShopPack[] = [
  { id: "c1", name: "POCKET CHANGE", coins: 1000, gems: 0, price: "$0.99" },
  { id: "c2", name: "SPACE WALLET", coins: 5500, gems: 2, price: "$4.99", tag: "POPULAR" },
  { id: "c3", name: "ASTEROID VAULT", coins: 13000, gems: 6, price: "$9.99" },
  { id: "c4", name: "GALACTIC BANK", coins: 40000, gems: 20, price: "$24.99", tag: "BEST VALUE" },
];
export const GEM_PACKS: ShopPack[] = [
  { id: "g1", name: "SHARD", coins: 0, gems: 10, price: "$1.99" },
  { id: "g2", name: "CLUSTER", coins: 500, gems: 30, price: "$4.99" },
  { id: "g3", name: "GEODE", coins: 2000, gems: 80, price: "$12.99", tag: "POPULAR" },
  { id: "g4", name: "SINGULARITY", coins: 9000, gems: 250, price: "$39.99", tag: "WHALE" },
];

export const CODES: Record<string, { coins?: number; gems?: number; ship?: string; msg: string }> = {
  VOIDFALL: { coins: 1500, gems: 3, msg: "WELCOME TO THE VOID" },
  "1MFINZO": { coins: 5000, gems: 10, msg: "FINZO SENDS HIS REGARDS" },
  LOXA: { coins: 3000, gems: 8, msg: "LOXA OPENED THE VAULT" },
  DEVDEV1: { coins: 3000, gems: 8, msg: "DEV TOOLS UNLOCKED" },
  SPAGHETTI: { coins: 2500, msg: "YOU HAVE BEEN STRETCHED" },
  EVENTHORIZON: { gems: 25, msg: "NO TURNING BACK" },
  PIXEL90: { coins: 9000, gems: 5, msg: "RETRO MODE ENGAGED" },
  FREESHIP: { ship: "saucer", msg: "SAUCER ACQUIRED. DO NOT ASK HOW." },
  BLACKHOLE: { coins: 10000, gems: 15, msg: "THE HOLE PAYS OUT" },
};

export const CREDITS: { role: string; name: string }[] = [
  { role: "GAME DESIGN", name: "1MFINZO - DISCORD" },
  { role: "PIXEL ART", name: "LOXA - DISCORD" },
  { role: "PROGRAMMING", name: "DEVDEV1 - DISCORD" },
  { role: "SOUND / CHIPTUNE", name: "BLUE_M4GE - DISCORD" },
  { role: "LEVEL DESIGN", name: "NOVA.EXE - DISCORD" },
  { role: "STORY / WRITING", name: "STARWHALE - DISCORD" },
  { role: "UI / MENUS", name: "PIXELPOP - DISCORD" },
  { role: "PLAYTEST LEAD", name: "GRAVITON - DISCORD" },
  { role: "QA CREW", name: "MOONDUST - DISCORD" },
  { role: "COMMUNITY", name: "THE VOIDRUNNERS" },
  { role: "SPECIAL THANKS", name: "EVERY PLAYER WHO JUMPED IN" },
];
