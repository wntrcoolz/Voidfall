export type Btn = "left" | "right" | "up" | "down" | "fire" | "action" | "alt" | "pause" | "start";

const MAP: Record<string, Btn> = {
  ArrowLeft: "left",
  KeyA: "left",
  ArrowRight: "right",
  KeyD: "right",
  ArrowUp: "up",
  KeyW: "up",
  ArrowDown: "down",
  KeyS: "down",
  Space: "fire",
  KeyJ: "fire",
  KeyZ: "fire",
  KeyE: "action",
  KeyK: "action",
  KeyX: "action",
  Enter: "start",
  KeyQ: "alt",
  ShiftLeft: "alt",
  Escape: "pause",
  KeyP: "pause",
};

export class Input {
  down: Record<string, boolean> = {};
  pressed: Record<string, boolean> = {};
  pointer = { active: false, x: 0, y: 0, downNow: false, id: -1 };
  private held: Record<string, boolean> = {};
  usedTouch = false;

  constructor() {
    window.addEventListener("keydown", this.onKeyDown, { passive: false });
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.clear);
  }

  onKeyDown = (e: KeyboardEvent) => {
    const b = MAP[e.code];
    if (!b) return;
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
    if (!this.down[b]) this.pressed[b] = true;
    this.down[b] = true;
  };
  onKeyUp = (e: KeyboardEvent) => {
    const b = MAP[e.code];
    if (!b) return;
    this.down[b] = false;
  };
  clear = () => {
    this.down = {};
    this.held = {};
  };

  press(b: Btn) {
    this.usedTouch = true;
    if (!this.down[b]) this.pressed[b] = true;
    this.down[b] = true;
    this.held[b] = true;
  }
  release(b: Btn) {
    this.down[b] = false;
    this.held[b] = false;
  }

  just(b: Btn) {
    return !!this.pressed[b];
  }
  endFrame() {
    this.pressed = {};
    this.pointer.downNow = false;
  }
  dispose() {
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.clear);
  }

  get ax() {
    return (this.down.right ? 1 : 0) - (this.down.left ? 1 : 0);
  }
  get ay() {
    return (this.down.down ? 1 : 0) - (this.down.up ? 1 : 0);
  }
}
