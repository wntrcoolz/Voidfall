// Hand-drawn pixel sprites + procedural pixel renderers (black holes, planets, asteroids).
import { PAINTS } from "./data";

export type Pal = Record<string, string>;

const BASE_PAL: Pal = {
  K: "#160f1c",
  A: "#c9773a",
  B: "#7d3f20",
  C: "#f0c27b",
  D: "#6fc2e0",
  E: "#d8d8e0",
  F: "#6a6a78",
  W: "#fff6d8",
  R: "#d0402e",
  Y: "#ffd23c",
  S: "#e8b48a",
  U: "#d8d8e0",
  H: "#2a1a10",
  V: "#7fd0e8",
  G: "#6fc04a",
  P: "#a35cb0",
};

function norm(rows: string[]): string[] {
  const w = rows.reduce((m, r) => Math.max(m, r.length), 0);
  return rows.map((r) => r.padEnd(w, "."));
}

export const SHIP_SPRITES: Record<string, string[]> = {
  rust: norm([
    ".......K.......",
    "......KCK......",
    "......KCK......",
    ".....KCACK.....",
    ".....KAAAK.....",
    "....KAAAAAK....",
    "....KADDDAK....",
    "....KADDDAK....",
    "....KAAAAAK....",
    "....KABBBAK....",
    "....KAAAAAK....",
    "...KCAAAAACK...",
    "...KCABBBACK...",
    "..KCCAAAAACCK..",
    "..KC.KAAAK.CK..",
    ".KCK.KAAAK.KCK.",
    ".KK..KFEFK..KK.",
    ".....KFFFK.....",
    "......KKK......",
  ]),
  needle: norm([
    ".......K.......",
    ".......C.......",
    "......KCK......",
    "......KAK......",
    "......KAK......",
    "......KDK......",
    ".....KADAK.....",
    ".....KAAAK.....",
    ".....KAAAK.....",
    ".....KABAK.....",
    ".....KAAAK.....",
    "....KCAAACK....",
    "...KCCAAACCK...",
    "..KCK.KAK.KCK..",
    "..KK..KAK..KK..",
    "......KFK......",
    ".....KFEFK.....",
    "......KFK......",
    ".......K.......",
  ]),
  hauler: norm([
    ".....KKKKK.....",
    "....KCAAACK....",
    "....KADDDAK....",
    "....KAAAAAK....",
    "...KKAAAAAKK...",
    "..KCAAAAAAACK..",
    "..KABBBBBBBAK..",
    "..KAAAAAAAAAK..",
    "..KAAAAAAAAAK..",
    "..KADDDDDDDAK..",
    "..KAAAAAAAAAK..",
    ".KCAAAAAAAAACK.",
    ".KCABBBBBBBACK.",
    ".KCAAAAAAAAACK.",
    "KCK.KAAAAAK.KCK",
    "KK..KFEFEFK..KK",
    "....KFFEFFK....",
    ".....KFEFK.....",
    "......KKK......",
  ]),
  viper: norm([
    ".......K.......",
    "......KAK......",
    "......KAK......",
    ".....KADAK.....",
    ".....KADAK.....",
    ".....KAAAK.....",
    "....KCAAACK....",
    "...KCAAAAACK...",
    "..KCAAAAAAACK..",
    ".KCAABBBBBAACK.",
    "KCAAABBBBBAAACK",
    "KCKAAAAAAAAAKCK",
    "KK.KAABBBAAK.KK",
    "...KAAAAAAAK...",
    "...KRAAAAARK...",
    "....KFEFEFK....",
    "....KFFFFFK....",
    ".....KFEFK.....",
    "......KKK......",
  ]),
  saucer: norm([
    "...............",
    "...............",
    ".....KKKKK.....",
    "....KDDDDDK....",
    "...KDWWWWWDK...",
    "...KAAAAAAAK...",
    "..KAAAAAAAAAK..",
    ".KCACACACACACK.",
    "KCAAAAAAAAAAACK",
    "KKCCCCCCCCCCCKK",
    ".KKAAAAAAAAAKK.",
    "..KKCKCKCKCKK..",
    "....KK.K.KK....",
    ".....E...E.....",
    "......F.F......",
    "...............",
    "...............",
    "...............",
    "...............",
  ]),
  obsidian: norm([
    ".......K.......",
    "......KAK......",
    "......KAK......",
    ".....KABAK.....",
    ".....KADAK.....",
    "....KABDBAK....",
    "....KAADAAK....",
    "...KCABDBACK...",
    "...KCAAAAACK...",
    "..KCAABBBAACK..",
    "..KCAAAAAAACK..",
    ".KCCAABBBAACCK.",
    ".KCKAAAAAAAKCK.",
    "KCK.KAABAAK.KCK",
    "KK..KAAAAAK..KK",
    "....KFEFEFK....",
    "....KFFEFFK....",
    ".....KFEFK.....",
    "......KKK......",
  ]),
  lastlight: norm([
    ".......K.......",
    "......KWK......",
    "......KCK......",
    ".....KCWCK.....",
    ".....KADAK.....",
    "....KCADACK....",
    "....KAWWWAK....",
    "...KCAWDWACK...",
    "...KCAAWAACK...",
    "..KCCAAWAACCK..",
    ".KCWCAAWAACWCK.",
    "KCWKAABWBAAKWCK",
    "KCK.KAAWAAK.KCK",
    "KK..KAABAAK..KK",
    "....KAAWAAK....",
    "....KCAWACK....",
    "....KFEWEFK....",
    ".....KFWFK.....",
    "......KKK......",
  ]),
};

export const HUMAN_BODY = norm([
  "..KKKK..",
  ".KHHHHK.",
  ".KHSSHK.",
  ".KSVVSK.",
  ".KSSSSK.",
  "..KUUK..",
  ".KUUUUK.",
  "KUUUUUUK",
  "KUSUUSUK",
  ".KUUUUK.",
]);
export const HUMAN_LEGS: string[][] = [
  norm([".KUUUUK.", ".KU..UK.", ".KB..BK.", ".KKK.KK."]),
  norm([".KUUUUK.", "KUU..UK.", "KB....BK", "KK....KK"]),
  norm([".KUUUUK.", ".KU..UK.", ".KB..BK.", ".KKK.KK."]),
  norm([".KUUUUK.", ".KU..UUK", "KB....BK", "KK....KK"]),
];

export const SPRITES: Record<string, string[]> = {
  ufo: norm([
    "....KKKKK....",
    "...KDWWWDK...",
    "..KDWWWWWDK..",
    ".KGGGGGGGGGK.",
    "KGCGCGCGCGCGK",
    "KKGGGGGGGGGKK",
    ".KKYKYKYKYKK.",
    "...K.K.K.K...",
  ]),
  alien_crawler: norm([
    "..K..K..",
    ".KGKKGK.",
    "KGGGGGGK",
    "KGRGGRGK",
    "KGGGGGGK",
    ".KGGGGK.",
    "K.K..K.K",
    ".K....K.",
  ]),
  alien_blob: norm([
    "..KKKK..",
    ".KPPPPK.",
    "KPPWPPPK",
    "KPWWWPPK",
    "KPPPPPPK",
    ".KPPPPK.",
    "..K..K..",
  ]),
  alien_strider: norm([
    "...KK...",
    "..KGGK..",
    ".KGRRGK.",
    "..KGGK..",
    "..KGGK..",
    ".K.KK.K.",
    ".K.KK.K.",
    "K..KK..K",
  ]),
  alien_floater: norm([
    "..KKKK..",
    ".KDDDDK.",
    "KDWWDDDK",
    "KDDDDDDK",
    ".KPPPPK.",
    "..K.K.K.",
    ".K.K.K..",
  ]),
  alien_drone: norm([
    "K.KKKK.K",
    "KKEEEEKK",
    ".KERREK.",
    ".KEEEEK.",
    "..KEEK..",
    "..K..K..",
  ]),
  alien_flare: norm([
    "..K..K..",
    ".KYRRYK.",
    "KYRWWRYK",
    "KYRWWRYK",
    ".KYRRYK.",
    "..K..K..",
  ]),
  boss: norm([
    ".....KKKKKKKKKKK.....",
    "...KKPPPPPPPPPPPKK...",
    "..KPPWWPPPPPPPWWPPK..",
    ".KPPWWWPPPPPPPWWWPPK.",
    "KPPPPPPPKKKKKPPPPPPPK",
    "KPRRPPPKDDDDDKPPPRRPK",
    "KPRRPPPKDWWWDKPPPRRPK",
    "KPPPPPPPKDDDKPPPPPPPK",
    ".KPPPPPPPKKKPPPPPPPK.",
    "..KKPPPPPPPPPPPPPKK..",
    "....KK.KK.KK.KK.KK...",
    ".....K..K..K..K..K...",
  ]),
  coin: norm([".KKK.", "KYWYK", "KYYYK", "KYWYK", ".KKK."]),
  gem: norm(["..K..", ".KDK.", "KDWDK", ".KDK.", "..K.."]),
  heart: norm([".K.K.", "KRWRK", "KRRRK", ".KRK.", "..K.."]),
  shieldpk: norm([".KKK.", "KDWDK", "KDDDK", ".KDK.", "..K.."]),
  rocket_small: norm([
    "..K..",
    ".KCK.",
    ".KAK.",
    "KAAAK",
    "KADAK",
    "KAAAK",
    "KCACK",
    "K.K.K",
    ".KFK.",
  ]),
  flag: norm(["KKKKK.", "KRRRK.", "KRRRK.", "KKKKK.", "K.....", "K.....", "K.....", "K....."]),
  crate: norm(["KKKKKKKK", "KAABBAAK", "KABBBBAK", "KABBBBAK", "KAABBAAK", "KKKKKKKK"]),
  door: norm([
    "KKKKKKKK",
    "KBBBBBBK",
    "KBWWWWBK",
    "KBWWWWBK",
    "KBWWWWBK",
    "KBWWYWBK",
    "KBWWWWBK",
    "KBBBBBBK",
  ]),
};

export function drawSprite(
  ctx: CanvasRenderingContext2D,
  rows: string[],
  x: number,
  y: number,
  s = 1,
  pal: Pal = {},
  flip = false,
) {
  const P = { ...BASE_PAL, ...pal };
  const w = rows[0]?.length ?? 0;
  for (let r = 0; r < rows.length; r++) {
    const row = rows[r];
    for (let c = 0; c < row.length; c++) {
      const ch = row[c];
      if (ch === "." || ch === " ") continue;
      const col = P[ch];
      if (!col) continue;
      ctx.fillStyle = col;
      const cx = flip ? w - 1 - c : c;
      ctx.fillRect(Math.round(x + cx * s), Math.round(y + r * s), s, s);
    }
  }
}

export function spriteSize(rows: string[], s = 1) {
  return { w: (rows[0]?.length ?? 0) * s, h: rows.length * s };
}

// ---------- SHIP ----------
export function shipPal(paintIdx: number): Pal {
  const p = PAINTS[paintIdx % PAINTS.length];
  return { A: p.a, B: p.b, C: p.c };
}

export function drawShip(
  ctx: CanvasRenderingContext2D,
  shipId: string,
  x: number,
  y: number,
  s: number,
  paint: number,
  decal: number,
  thrust: number,
  trailIdx = 0,
  t = 0,
) {
  const rows = SHIP_SPRITES[shipId] || SHIP_SPRITES.rust;
  const w = rows[0].length * s;
  const h = rows.length * s;
  const px = x - w / 2;
  const py = y - h / 2;
  if (thrust > 0) drawThrust(ctx, x, py + h - s * 2, s, thrust, trailIdx, t);
  drawSprite(ctx, rows, px, py, s, shipPal(paint));
  // decals
  const p = PAINTS[paint % PAINTS.length];
  ctx.fillStyle = p.c;
  const mid = px + w / 2;
  if (decal === 1) {
    ctx.fillRect(mid - s, py + h * 0.45, s * 2, s * 4);
  } else if (decal === 2) {
    ctx.fillRect(mid - s * 2, py + h * 0.5, s, s);
    ctx.fillRect(mid - s, py + h * 0.5 - s, s * 2, s);
    ctx.fillRect(mid + s, py + h * 0.5, s, s);
  } else if (decal === 3) {
    ctx.fillStyle = "#f2f0e6";
    ctx.fillRect(mid - s * 1.5, py + h * 0.52, s * 3, s * 2);
    ctx.fillStyle = "#160f1c";
    ctx.fillRect(mid - s, py + h * 0.52 + s * 0.2, s, s);
    ctx.fillRect(mid + s * 0.4, py + h * 0.52 + s * 0.2, s, s);
  } else if (decal === 4) {
    ctx.fillRect(mid - s * 0.5, py + h * 0.45, s, s * 3);
    ctx.fillRect(mid - s * 1.5, py + h * 0.45 + s, s * 3, s);
  } else if (decal === 5) {
    ctx.fillStyle = "#ffd23c";
    ctx.fillRect(mid, py + h * 0.42, s, s);
    ctx.fillRect(mid - s, py + h * 0.42 + s, s * 2, s);
    ctx.fillRect(mid - s, py + h * 0.42 + s * 2, s, s);
    ctx.fillRect(mid - s * 2, py + h * 0.42 + s * 3, s * 2, s);
  }
}

const TRAIL_COLORS = [
  ["#ffe9a0", "#ffae3b", "#e0562a"],
  ["#dff4ff", "#7fc2e8", "#3a6ea8"],
  ["#e8ff9f", "#8fd13f", "#3c6b1e"],
  ["#dedede", "#9a9a9a", "#4d4d4d"],
  ["#e0c2ff", "#8a5ad0", "#3b2260"],
];

export function drawThrust(
  ctx: CanvasRenderingContext2D,
  cx: number,
  y: number,
  s: number,
  power: number,
  trailIdx: number,
  t: number,
) {
  const c = TRAIL_COLORS[trailIdx % TRAIL_COLORS.length];
  const flick = (Math.sin(t * 40) + 1) * 0.5;
  const len = (3 + power * 6 + flick * 2) * s;
  for (let i = 0; i < len / s; i++) {
    const p = i / (len / s);
    const wdt = Math.max(1, Math.round((3 - p * 3) * (0.7 + power * 0.6)));
    const col = p < 0.3 ? c[0] : p < 0.65 ? c[1] : c[2];
    ctx.fillStyle = col;
    ctx.fillRect(Math.round(cx - (wdt * s) / 2), Math.round(y + i * s), wdt * s, s);
  }
}

// ---------- HUMAN ----------
export interface CharCfg {
  skin: string;
  suit: string;
  hair: string;
  visor: string;
}
export function drawHuman(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  s: number,
  cfg: CharCfg,
  frame: number,
  flip = false,
) {
  const pal: Pal = { S: cfg.skin, U: cfg.suit, H: cfg.hair, V: cfg.visor, B: "#2a2430" };
  drawSprite(ctx, HUMAN_BODY, x, y, s, pal, flip);
  drawSprite(ctx, HUMAN_LEGS[frame % 4], x, y + HUMAN_BODY.length * s, s, pal, flip);
}
export const HUMAN_W = 8;
export const HUMAN_H = 14;

// ---------- PROCEDURAL BLACK HOLE ----------
const DISK_BANDS = ["#fff8e2", "#ffe9a8", "#ffc457", "#f2892a", "#d4561f", "#a12f1d", "#6b1c2c", "#3a1230"];

interface BHCache {
  cv: HTMLCanvasElement;
  last: number;
  phase: number;
}
const bhCache = new Map<string, BHCache>();

/** Cached, chunky black hole. Re-renders ~12x/sec so mobile stays smooth. */
export function drawBlackHole(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  rh: number,
  t: number,
  px = 2,
  squash = 0.26,
  intensity = 1,
) {
  const r = Math.max(3, Math.round(rh));
  const key = `${r}_${px}_${squash.toFixed(2)}_${intensity > 0.6 ? 1 : 0}`;
  const box = Math.ceil(r * 3.1) + px * 3;
  let hit = bhCache.get(key);
  if (!hit) {
    if (bhCache.size > 22) bhCache.clear();
    const cv = document.createElement("canvas");
    cv.width = box * 2;
    cv.height = box * 2;
    hit = { cv, last: -99, phase: 0 };
    bhCache.set(key, hit);
  }
  const now = t;
  if (now - hit.last > 1 / 12) {
    hit.last = now;
    hit.phase += 1 / 12;
    const c2 = hit.cv.getContext("2d")!;
    c2.clearRect(0, 0, hit.cv.width, hit.cv.height);
    renderBlackHole(c2, box, box, r, hit.phase, px, squash, intensity);
  }
  ctx.drawImage(hit.cv, Math.round(cx - box), Math.round(cy - box));
}

function renderBlackHole(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  rh: number,
  t: number,
  px: number,
  squash: number,
  intensity: number,
) {
  const rOut = rh * (2.9 + Math.sin(t * 0.7) * 0.05);
  const rIn = rh * 1.18;
  const box = Math.ceil(rOut) + px * 2;
  const x0 = Math.floor((cx - box) / px) * px;
  const x1 = Math.ceil((cx + box) / px) * px;
  const y0 = Math.floor((cy - box) / px) * px;
  const y1 = Math.ceil((cy + box) / px) * px;

  const band = (dr: number, ang: number, dy: number) => {
    const n =
      Math.sin(ang * 3 + t * 2.2) * 0.06 +
      Math.sin(ang * 7 - t * 1.4) * 0.04 +
      Math.sin(dr * 0.4 - t * 3) * 0.03;
    const f = Math.min(0.999, Math.max(0, (dr + n) * (1 + (dy > 0 ? 0.02 : -0.02))));
    const i = Math.floor(Math.pow(f, 0.72) * DISK_BANDS.length);
    return DISK_BANDS[Math.min(DISK_BANDS.length - 1, i)];
  };

  // pass 1: far side of the disk (top)
  for (let py = y0; py <= y1; py += px) {
    for (let pxx = x0; pxx <= x1; pxx += px) {
      const dx = pxx + px / 2 - cx;
      const dy = py + px / 2 - cy;
      if (dy > 0) continue;
      const ry = dy / squash;
      const d = Math.hypot(dx, ry);
      if (d < rIn || d > rOut) continue;
      const dr = (d - rIn) / (rOut - rIn);
      ctx.fillStyle = band(dr, Math.atan2(ry, dx), dy);
      ctx.fillRect(pxx, py, px, px);
    }
  }
  // lensed halo arc over the top of the hole
  for (let py = y0; py <= cy; py += px) {
    for (let pxx = x0; pxx <= x1; pxx += px) {
      const dx = pxx + px / 2 - cx;
      const dy = py + px / 2 - cy;
      const d = Math.hypot(dx, dy * 1.05);
      if (d < rh * 1.04 || d > rh * 1.42) continue;
      const dr = (d - rh * 1.04) / (rh * 0.38);
      ctx.fillStyle = band(dr * 0.85, Math.atan2(dy, dx) * 2 + t, -1);
      ctx.fillRect(pxx, py, px, px);
    }
  }
  // event horizon
  for (let py = y0; py <= y1; py += px) {
    for (let pxx = x0; pxx <= x1; pxx += px) {
      const dx = pxx + px / 2 - cx;
      const dy = py + px / 2 - cy;
      const d = Math.hypot(dx, dy);
      if (d > rh) continue;
      ctx.fillStyle = d > rh * 0.94 ? "#1a0d16" : "#000000";
      ctx.fillRect(pxx, py, px, px);
    }
  }
  // photon ring
  for (let a = 0; a < Math.PI * 2; a += 0.035) {
    const r = rh * 1.02;
    const x = cx + Math.cos(a) * r;
    const y = cy + Math.sin(a) * r;
    ctx.fillStyle = intensity > 0.6 ? "#ffeeba" : "#c89a5a";
    ctx.fillRect(Math.floor(x / px) * px, Math.floor(y / px) * px, px, px);
  }
  // pass 2: near side of the disk (bottom, drawn over the hole)
  for (let py = cy; py <= y1; py += px) {
    for (let pxx = x0; pxx <= x1; pxx += px) {
      const dx = pxx + px / 2 - cx;
      const dy = py + px / 2 - cy;
      if (dy <= 0) continue;
      const ry = dy / squash;
      const d = Math.hypot(dx, ry);
      if (d < rIn || d > rOut) continue;
      const dr = (d - rIn) / (rOut - rIn);
      ctx.fillStyle = band(dr, Math.atan2(ry, dx), dy);
      ctx.fillRect(pxx, py, px, px);
    }
  }
}

// ---------- PROCEDURAL PLANET ----------
export interface PlanetLook {
  core: string;
  band: string;
  band2: string;
  ring?: boolean;
  rock?: string;
}
export function drawPlanet(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  r: number,
  look: PlanetLook,
  t = 0,
  px = 2,
) {
  const x0 = Math.floor((cx - r - px) / px) * px;
  const x1 = Math.ceil((cx + r + px) / px) * px;
  const y0 = Math.floor((cy - r - px) / px) * px;
  const y1 = Math.ceil((cy + r + px) / px) * px;
  if (look.ring) {
    for (let pyy = y0 - r * 0.4; pyy <= y1 + r * 0.4; pyy += px)
      for (let pxx = x0 - r * 0.9; pxx <= x1 + r * 0.9; pxx += px) {
        const dx = pxx - cx;
        const dy = (pyy - cy) / 0.22;
        const d = Math.hypot(dx, dy);
        if (d > r * 1.35 && d < r * 1.9 && pyy - cy > -r * 0.1) {
          ctx.fillStyle = d > r * 1.7 ? look.band2 : look.band;
          ctx.fillRect(pxx, pyy, px, px);
        }
      }
  }
  for (let pyy = y0; pyy <= y1; pyy += px) {
    for (let pxx = x0; pxx <= x1; pxx += px) {
      const dx = (pxx + px / 2 - cx) / r;
      const dy = (pyy + px / 2 - cy) / r;
      const d2 = dx * dx + dy * dy;
      if (d2 > 1) continue;
      const z = Math.sqrt(1 - d2);
      const lat = Math.asin(Math.max(-1, Math.min(1, dy)));
      const n =
        Math.sin(lat * 6 + Math.sin(dx * 3 + t * 0.4) * 0.8) * 0.5 +
        Math.sin((dx + t * 0.06) * 9) * 0.2;
      let col = n > 0.25 ? look.band : n < -0.25 ? look.band2 : look.core;
      // lighting from upper-left
      const light = (-dx * 0.6 - dy * 0.6 + z * 0.8) * 1.05;
      if (light < 0.15) col = shade(col, -0.55);
      else if (light < 0.45) col = shade(col, -0.28);
      else if (light > 1.0) col = shade(col, 0.22);
      if (d2 > 0.93) col = shade(col, -0.45);
      ctx.fillStyle = col;
      ctx.fillRect(pxx, pyy, px, px);
    }
  }
  if (look.ring) {
    for (let pyy = cy; pyy <= y1 + r * 0.5; pyy += px)
      for (let pxx = x0 - r * 0.9; pxx <= x1 + r * 0.9; pxx += px) {
        const dx = pxx - cx;
        const dy = (pyy - cy) / 0.22;
        const d = Math.hypot(dx, dy);
        const inPlanet = Math.hypot(pxx - cx, pyy - cy) < r;
        if (!inPlanet && d > r * 1.35 && d < r * 1.9) {
          ctx.fillStyle = d > r * 1.7 ? look.band2 : look.band;
          ctx.fillRect(pxx, pyy, px, px);
        }
      }
  }
}

export function shade(hex: string, amt: number): string {
  const c = hex.replace("#", "");
  const n = parseInt(c.length === 3 ? c.split("").map((x) => x + x).join("") : c, 16);
  let r = (n >> 16) & 255,
    g = (n >> 8) & 255,
    b = n & 255;
  if (amt >= 0) {
    r += (255 - r) * amt;
    g += (255 - g) * amt;
    b += (255 - b) * amt;
  } else {
    r *= 1 + amt;
    g *= 1 + amt;
    b *= 1 + amt;
  }
  return `rgb(${r | 0},${g | 0},${b | 0})`;
}

// ---------- ASTEROIDS ----------
const rockCache = new Map<string, HTMLCanvasElement>();
export function asteroidCanvas(variant: number, size: number, color: string): HTMLCanvasElement {
  const key = `${variant}_${size}_${color}`;
  const hit = rockCache.get(key);
  if (hit) return hit;
  const g = 10 + (variant % 3) * 2;
  const cv = document.createElement("canvas");
  cv.width = g;
  cv.height = g;
  const c = cv.getContext("2d")!;
  const seed = variant * 9871 + 13;
  const rnd = (i: number) => {
    const v = Math.sin(seed + i * 127.1) * 43758.5453;
    return v - Math.floor(v);
  };
  const radii: number[] = [];
  for (let i = 0; i < 8; i++) radii.push(0.62 + rnd(i) * 0.38);
  for (let y = 0; y < g; y++)
    for (let x = 0; x < g; x++) {
      const dx = (x + 0.5) / g - 0.5;
      const dy = (y + 0.5) / g - 0.5;
      const a = (Math.atan2(dy, dx) + Math.PI) / (Math.PI * 2);
      const i = a * 8;
      const r0 = radii[Math.floor(i) % 8];
      const r1 = radii[(Math.floor(i) + 1) % 8];
      const rr = (r0 + (r1 - r0) * (i % 1)) * 0.5;
      const d = Math.hypot(dx, dy);
      if (d > rr) continue;
      const lit = -dx - dy;
      let col = color;
      if (d > rr * 0.86) col = "#160f1c";
      else if (lit > 0.12) col = shade(color, 0.22);
      else if (lit < -0.12) col = shade(color, -0.35);
      if (rnd(x * 7 + y * 13) > 0.9) col = shade(col, -0.25);
      c.fillStyle = col;
      c.fillRect(x, y, 1, 1);
    }
  rockCache.set(key, cv);
  return cv;
}

// ---------- STARFIELD ----------
export class Starfield {
  stars: { x: number; y: number; z: number; c: string }[] = [];
  constructor(n: number, w: number, h: number) {
    const cols = ["#ffffff", "#e8e0ff", "#ffe9c0", "#b9c8ff", "#d8d8d8"];
    for (let i = 0; i < n; i++)
      this.stars.push({
        x: Math.random() * w,
        y: Math.random() * h,
        z: 0.25 + Math.random() * 1,
        c: cols[(Math.random() * cols.length) | 0],
      });
  }
  update(dt: number, sx: number, sy: number, w: number, h: number) {
    for (const s of this.stars) {
      s.x -= sx * s.z * dt;
      s.y += sy * s.z * dt;
      if (s.y > h) {
        s.y -= h;
        s.x = Math.random() * w;
      }
      if (s.y < 0) {
        s.y += h;
        s.x = Math.random() * w;
      }
      if (s.x < 0) s.x += w;
      if (s.x > w) s.x -= w;
    }
  }
  draw(ctx: CanvasRenderingContext2D) {
    for (const s of this.stars) {
      ctx.fillStyle = s.c;
      const sz = s.z > 0.85 ? 2 : 1;
      ctx.fillRect(s.x | 0, s.y | 0, sz, sz);
    }
  }
}

// ---------- NEBULA BACKDROP ----------
export function makeNebula(w: number, h: number, cols: string[], density = 90): HTMLCanvasElement {
  const cv = document.createElement("canvas");
  cv.width = w;
  cv.height = h;
  const c = cv.getContext("2d")!;
  for (let i = 0; i < density; i++) {
    const x = Math.random() * w;
    const y = Math.random() * h;
    const r = 8 + Math.random() * 34;
    const col = cols[(Math.random() * cols.length) | 0];
    for (let yy = -r; yy < r; yy += 2)
      for (let xx = -r; xx < r; xx += 2) {
        const d = Math.hypot(xx, yy) / r;
        if (d > 1) continue;
        if (Math.random() > 0.55 - d * 0.5) continue;
        c.fillStyle = col;
        c.fillRect(((x + xx) | 0) - (((x + xx) | 0) % 2), ((y + yy) | 0) - (((y + yy) | 0) % 2), 2, 2);
      }
  }
  return cv;
}
