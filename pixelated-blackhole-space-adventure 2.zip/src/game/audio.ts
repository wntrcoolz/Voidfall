// Chiptune-style WebAudio engine: square/triangle/noise SFX + a tiny music sequencer.

type Wave = OscillatorType;

class AudioEngine {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  sfxBus: GainNode | null = null;
  musicBus: GainNode | null = null;
  noiseBuf: AudioBuffer | null = null;
  sfxVol = 0.7;
  musicVol = 0.45;
  private timer: number | null = null;
  private step = 0;
  private nextTime = 0;
  private track: string | null = null;

  init() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = 0.9;
    this.master.connect(this.ctx.destination);
    this.sfxBus = this.ctx.createGain();
    this.sfxBus.gain.value = this.sfxVol;
    this.sfxBus.connect(this.master);
    this.musicBus = this.ctx.createGain();
    this.musicBus.gain.value = this.musicVol;
    this.musicBus.connect(this.master);
    // noise buffer
    const len = this.ctx.sampleRate * 1.2;
    const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.noiseBuf = buf;
    // resume any track requested before audio was unlocked
    if (this.track) {
      const pending = this.track;
      this.track = null;
      this.music(pending);
    }
  }

  setSfxVol(v: number) {
    this.sfxVol = v;
    if (this.sfxBus) this.sfxBus.gain.value = v;
  }
  setMusicVol(v: number) {
    this.musicVol = v;
    if (this.musicBus) this.musicBus.gain.value = v;
  }

  private tone(
    freq: number,
    dur: number,
    wave: Wave = "square",
    vol = 0.3,
    slide = 0,
    delay = 0,
    bus: GainNode | null = this.sfxBus,
  ) {
    if (!this.ctx || !bus) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = wave;
    o.frequency.setValueAtTime(Math.max(20, freq), t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, freq + slide), t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vol, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    g.connect(bus);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private noise(dur: number, vol = 0.3, filt = 1200, delay = 0, sweep = 0) {
    if (!this.ctx || !this.noiseBuf || !this.sfxBus) return;
    const t = this.ctx.currentTime + delay;
    const s = this.ctx.createBufferSource();
    s.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter();
    f.type = "lowpass";
    f.frequency.setValueAtTime(filt, t);
    if (sweep) f.frequency.exponentialRampToValueAtTime(Math.max(60, filt + sweep), t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f);
    f.connect(g);
    g.connect(this.sfxBus);
    s.start(t);
    s.stop(t + dur + 0.02);
  }

  play(name: string) {
    if (!this.ctx) return;
    switch (name) {
      case "blip":
        this.tone(440, 0.05, "square", 0.18, 180);
        break;
      case "move":
        this.tone(300, 0.04, "square", 0.14, 60);
        break;
      case "select":
        this.tone(520, 0.07, "square", 0.2, 340);
        this.tone(780, 0.1, "square", 0.16, 200, 0.05);
        break;
      case "back":
        this.tone(400, 0.08, "square", 0.18, -180);
        break;
      case "deny":
        this.tone(180, 0.16, "sawtooth", 0.2, -60);
        break;
      case "laser":
        this.tone(900, 0.1, "square", 0.16, -700);
        this.noise(0.05, 0.06, 2400);
        break;
      case "laser2":
        this.tone(1300, 0.09, "sawtooth", 0.13, -1000);
        break;
      case "hit":
        this.noise(0.09, 0.22, 900, 0, -600);
        this.tone(220, 0.08, "square", 0.12, -120);
        break;
      case "explode":
        this.noise(0.45, 0.4, 1400, 0, -1300);
        this.tone(110, 0.35, "sawtooth", 0.2, -80);
        break;
      case "bigboom":
        this.noise(1.1, 0.5, 900, 0, -820);
        this.tone(70, 0.9, "sawtooth", 0.28, -40);
        this.tone(48, 1.2, "sine", 0.3, -20, 0.05);
        break;
      case "coin":
        this.tone(988, 0.06, "square", 0.18);
        this.tone(1318, 0.12, "square", 0.16, 0, 0.06);
        break;
      case "gem":
        this.tone(1046, 0.07, "triangle", 0.2);
        this.tone(1568, 0.07, "triangle", 0.2, 0, 0.07);
        this.tone(2093, 0.16, "triangle", 0.18, 0, 0.14);
        break;
      case "buy":
        this.tone(660, 0.08, "square", 0.2);
        this.tone(880, 0.08, "square", 0.2, 0, 0.08);
        this.tone(1320, 0.2, "square", 0.18, 0, 0.16);
        break;
      case "thrust":
        this.noise(0.5, 0.18, 500, 0, 300);
        break;
      case "launch":
        this.noise(2.4, 0.4, 420, 0, 900);
        this.tone(60, 2.2, "sawtooth", 0.2, 140);
        break;
      case "warp":
        this.tone(120, 1.2, "sawtooth", 0.22, 1600);
        this.noise(1.2, 0.18, 300, 0, 3000);
        break;
      case "alarm":
        this.tone(740, 0.16, "square", 0.2);
        this.tone(560, 0.16, "square", 0.2, 0, 0.18);
        break;
      case "jump":
        this.tone(320, 0.12, "square", 0.16, 320);
        break;
      case "step":
        this.noise(0.04, 0.09, 700);
        break;
      case "hurt":
        this.tone(300, 0.18, "sawtooth", 0.22, -200);
        this.noise(0.14, 0.14, 800);
        break;
      case "wreck":
        this.noise(0.3, 0.3, 1800, 0, -1500);
        this.tone(160, 0.2, "square", 0.14, -100);
        break;
      case "build":
        this.tone(300, 0.07, "square", 0.16);
        this.tone(450, 0.07, "square", 0.16, 0, 0.07);
        this.tone(600, 0.14, "square", 0.16, 0, 0.14);
        break;
      case "land":
        this.noise(0.6, 0.3, 700, 0, -500);
        this.tone(90, 0.5, "sine", 0.22, -30);
        break;
      case "horizon":
        this.tone(55, 3.5, "sine", 0.3, 20);
        this.tone(82, 3.5, "sawtooth", 0.1, -20);
        this.noise(3.5, 0.12, 200, 0, 800);
        break;
      case "stretch":
        this.tone(400, 1.6, "sine", 0.18, -330);
        break;
      case "singularity":
        this.tone(1200, 2.5, "sine", 0.22, -1150);
        this.tone(40, 2.5, "sine", 0.3, 10);
        this.noise(2.5, 0.2, 2500, 0, -2400);
        break;
      case "theend":
        [523, 466, 392, 311].forEach((f, i) => this.tone(f, 1.1, "triangle", 0.24, 0, i * 0.45));
        this.tone(130, 3.2, "sine", 0.22, -30, 0.2);
        break;
      case "alienhurt":
        this.tone(700, 0.12, "sawtooth", 0.18, -420);
        break;
      case "ufo":
        this.tone(300, 0.3, "sine", 0.12, 260);
        break;
      case "shield":
        this.tone(200, 0.3, "triangle", 0.2, 500);
        break;
      case "levelup":
        [392, 523, 659, 784].forEach((f, i) => this.tone(f, 0.16, "square", 0.2, 0, i * 0.09));
        break;
      case "code":
        [660, 660, 880].forEach((f, i) => this.tone(f, 0.1, "square", 0.18, 0, i * 0.1));
        break;
    }
  }

  // ---- music sequencer ----
  private patterns: Record<string, { bpm: number; bass: number[]; lead: number[]; wave: Wave; leadWave: Wave; drums?: boolean }> = {
    menu: {
      bpm: 96,
      wave: "triangle",
      leadWave: "square",
      bass: [55, 0, 55, 0, 62, 0, 62, 0, 49, 0, 49, 0, 58, 0, 58, 0],
      lead: [0, 330, 392, 0, 440, 0, 392, 330, 0, 294, 330, 0, 392, 0, 349, 0],
    },
    flight: {
      bpm: 142,
      wave: "sawtooth",
      leadWave: "square",
      bass: [82, 82, 0, 82, 110, 0, 82, 0, 73, 73, 0, 73, 98, 0, 73, 0],
      lead: [659, 0, 587, 0, 523, 0, 587, 0, 494, 0, 523, 0, 587, 0, 659, 0],
      drums: true,
    },
    void: {
      bpm: 64,
      wave: "sine",
      leadWave: "triangle",
      bass: [41, 0, 0, 0, 39, 0, 0, 0, 37, 0, 0, 0, 39, 0, 0, 0],
      lead: [0, 0, 233, 0, 0, 0, 220, 0, 0, 0, 196, 0, 0, 0, 175, 0],
    },
    planet: {
      bpm: 104,
      wave: "triangle",
      leadWave: "square",
      bass: [65, 0, 65, 0, 73, 0, 73, 0, 87, 0, 82, 0, 73, 0, 65, 0],
      lead: [523, 0, 0, 587, 0, 659, 0, 0, 587, 0, 0, 523, 0, 440, 0, 0],
    },
    end: {
      bpm: 70,
      wave: "sine",
      leadWave: "triangle",
      bass: [65, 0, 0, 0, 58, 0, 0, 0, 49, 0, 0, 0, 55, 0, 0, 0],
      lead: [262, 0, 311, 0, 392, 0, 311, 0, 262, 0, 233, 0, 196, 0, 0, 0],
    },
  };

  music(track: string | null) {
    if (this.track === track) return;
    this.track = track;
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    if (!track || !this.ctx) return;
    this.step = 0;
    this.nextTime = this.ctx.currentTime + 0.1;
    this.timer = window.setInterval(() => this.schedule(), 25);
  }

  private schedule() {
    if (!this.ctx || !this.track) return;
    const p = this.patterns[this.track];
    if (!p) return;
    const spb = 60 / p.bpm / 2;
    while (this.nextTime < this.ctx.currentTime + 0.2) {
      const i = this.step % 16;
      const delay = this.nextTime - this.ctx.currentTime;
      if (delay >= 0) {
        if (p.bass[i]) this.tone(p.bass[i], spb * 1.6, p.wave, 0.24, 0, delay, this.musicBus);
        if (p.lead[i]) this.tone(p.lead[i], spb * 1.1, p.leadWave, 0.09, 0, delay, this.musicBus);
        if (p.drums && i % 4 === 2 && this.musicBus) {
          const t = this.ctx.currentTime + delay;
          const s = this.ctx.createBufferSource();
          if (this.noiseBuf) {
            s.buffer = this.noiseBuf;
            const g = this.ctx.createGain();
            g.gain.setValueAtTime(0.09, t);
            g.gain.exponentialRampToValueAtTime(0.0001, t + 0.07);
            s.connect(g);
            g.connect(this.musicBus);
            s.start(t);
            s.stop(t + 0.09);
          }
        }
      }
      this.nextTime += spb;
      this.step++;
    }
  }
}

export const AUDIO = new AudioEngine();
export const sfx = (n: string) => AUDIO.play(n);
