import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { GameCanvas, type Scene, VW, VH } from "./game/engine";
import { Input, type Btn } from "./game/input";
import { AUDIO } from "./game/audio";
import { getSave, subscribe, applySettings } from "./game/save";
import { MainMenuScene } from "./scenes/mainmenu";
import { HangarScene, ShopScene, SettingsScene, CreditsScene, CodesScene, CharacterScene } from "./scenes/menus";
import { MapScene, FlightScene } from "./scenes/space";
import { PlanetScene, HomeScene } from "./scenes/world";
import { LaunchScene, CruiseScene, ApproachScene, HorizonScene, InsideScene, TheEndScene } from "./scenes/blackhole";

const REGISTRY: Record<string, () => Scene> = {
  menu: () => new MainMenuScene(),
  hangar: () => new HangarScene(),
  shop: () => new ShopScene(),
  settings: () => new SettingsScene(),
  credits: () => new CreditsScene(),
  codes: () => new CodesScene(),
  character: () => new CharacterScene(),
  map: () => new MapScene(),
  flight: () => new FlightScene(),
  planet: () => new PlanetScene(),
  home: () => new HomeScene(),
  launch: () => new LaunchScene(),
  cruise: () => new CruiseScene(),
  approach: () => new ApproachScene(),
  horizon: () => new HorizonScene(),
  inside: () => new InsideScene(),
  theend: () => new TheEndScene(),
};

export default function App() {
  const inputRef = useRef<Input | null>(null);
  if (!inputRef.current) inputRef.current = new Input();
  const input = inputRef.current;

  const [scene, setScene] = useState<{ key: string; payload: any; n: number }>({ key: "menu", payload: {}, n: 0 });
  const [, force] = useState(0);
  const [coarse, setCoarse] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const un = subscribe(() => force((x) => x + 1));
    return () => {
      un();
    };
  }, []);
  useEffect(() => {
    applySettings();
    const unlock = () => AUDIO.init();
    window.addEventListener("pointerdown", unlock);
    window.addEventListener("keydown", unlock);
    setCoarse(window.matchMedia?.("(pointer: coarse)").matches || "ontouchstart" in window);
    const prevent = (e: TouchEvent) => {
      if ((e.target as HTMLElement)?.dataset?.game !== undefined) e.preventDefault();
    };
    document.addEventListener("touchmove", prevent, { passive: false });
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
      document.removeEventListener("touchmove", prevent);
    };
  }, []);

  const goto = useCallback((key: string, payload?: any) => {
    AUDIO.init();
    setScene((s) => ({ key, payload: payload ?? {}, n: s.n + 1 }));
  }, []);

  const makeScene = useCallback((key: string) => {
    const id = key.split("#")[0];
    return (REGISTRY[id] || REGISTRY.menu)();
  }, []);

  const toVirtual = (clientX: number, clientY: number) => {
    const cv = wrapRef.current?.querySelector("canvas");
    if (!cv) return null;
    const r = cv.getBoundingClientRect();
    // canvas uses object-fit: contain
    const scale = Math.min(r.width / VW, r.height / VH);
    const dw = VW * scale;
    const dh = VH * scale;
    const ox = r.left + (r.width - dw) / 2;
    const oy = r.top + (r.height - dh) / 2;
    return { x: (clientX - ox) / scale, y: (clientY - oy) / scale };
  };

  const onPointerDown = (e: React.PointerEvent) => {
    if ((e.target as HTMLElement).tagName !== "CANVAS") return;
    const p = toVirtual(e.clientX, e.clientY);
    if (!p) return;
    input.pointer.active = true;
    input.pointer.downNow = true;
    input.pointer.x = p.x;
    input.pointer.y = p.y;
    input.pointer.id = e.pointerId;
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };
  const onPointerMove = (e: React.PointerEvent) => {
    if (!input.pointer.active || e.pointerId !== input.pointer.id) return;
    const p = toVirtual(e.clientX, e.clientY);
    if (!p) return;
    input.pointer.x = p.x;
    input.pointer.y = p.y;
  };
  const onPointerUp = (e: React.PointerEvent) => {
    if (e.pointerId !== input.pointer.id) return;
    input.pointer.active = false;
    input.pointer.id = -1;
  };

  const save = getSave();
  const showTouch = save.settings.touch === "on" || (save.settings.touch === "auto" && coarse);
  const sceneKey = `${scene.key}#${scene.n}`;

  const hold = useMemo(
    () => (b: Btn) => ({
      onPointerDown: (e: React.PointerEvent) => {
        e.preventDefault();
        e.stopPropagation();
        AUDIO.init();
        input.press(b);
        (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
      },
      onPointerUp: (e: React.PointerEvent) => {
        e.preventDefault();
        e.stopPropagation();
        input.release(b);
      },
      onPointerCancel: () => input.release(b),
      onPointerLeave: () => input.release(b),
      onContextMenu: (e: React.MouseEvent) => e.preventDefault(),
    }),
    [input],
  );

  return (
    <div className="fixed inset-0 flex select-none flex-col items-center justify-center overflow-hidden bg-black">
      <div
        ref={wrapRef}
        data-game=""
        className="relative h-full w-full touch-none"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
      >
        <GameCanvas makeScene={makeScene} sceneKey={sceneKey} payload={scene.payload} onGoto={goto} input={input} crt={save.settings.crt} />

        {/* top-right utility buttons */}
        <div className="pointer-events-auto absolute right-1 top-1 flex gap-1">
          <PixBtn label="ESC" small {...hold("pause")} />
          <button
            className="pix-btn pix-btn-sm"
            onPointerDown={(e) => {
              e.stopPropagation();
              const el = document.documentElement;
              if (!document.fullscreenElement) el.requestFullscreen?.().catch(() => {});
              else document.exitFullscreen?.().catch(() => {});
            }}
          >
            [ ]
          </button>
        </div>

        {showTouch && (
          <>
            <div className="absolute bottom-3 left-3 grid grid-cols-3 grid-rows-3 gap-1 opacity-90" style={{ width: 132, height: 132 }}>
              <span />
              <PixBtn label="^" {...hold("up")} />
              <span />
              <PixBtn label="<" {...hold("left")} />
              <span />
              <PixBtn label=">" {...hold("right")} />
              <span />
              <PixBtn label="v" {...hold("down")} />
              <span />
            </div>
            <div className="absolute bottom-3 right-3 flex flex-col items-end gap-2 opacity-90">
              <div className="flex gap-2">
                <PixBtn label="E" {...hold("action")} />
                <PixBtn label="FIRE" wide {...hold("fire")} />
              </div>
              <PixBtn label="SKIP" small {...hold("alt")} />
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function PixBtn({
  label,
  wide,
  small,
  ...rest
}: {
  label: string;
  wide?: boolean;
  small?: boolean;
} & React.HTMLAttributes<HTMLButtonElement>) {
  return (
    <button {...rest} className={`pix-btn ${wide ? "pix-btn-wide" : ""} ${small ? "pix-btn-sm" : ""}`}>
      {label}
    </button>
  );
}
