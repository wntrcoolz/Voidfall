import type { Scene, SceneCtx } from "../game/engine";
import { drawText, drawTextCentered, drawTitleText, textWidth } from "../game/font";
import { Starfield, drawShip, drawHuman, makeNebula, shade, drawSprite, SPRITES } from "../game/sprites";
import {
  SHIPS,
  UPGRADES,
  upgradeCost,
  PAINTS,
  DECALS,
  TRAILS,
  COIN_PACKS,
  GEM_PACKS,
  CODES,
  CREDITS,
  SKINS,
  SUITS,
  HAIRS,
  VISORS,
} from "../game/data";
import { getSave, mutate, exportSave, importSave, resetSave, applySettings, maxUpg } from "../game/save";
import { AUDIO } from "../game/audio";
import { CanvasMenu } from "./menu";
import { panel, bar, clamp, prompt, Floaters, Particles, rnd, irnd } from "./common";

// ---------------- shared chrome ----------------
class Backdrop {
  stars = new Starfield(90, 320, 180);
  neb: HTMLCanvasElement | null = null;
  init() {
    this.neb = makeNebula(320, 180, ["#1d1336", "#2b1a44", "#131029"], 45);
  }
  update(dt: number) {
    this.stars.update(dt, 6, 0, 320, 180);
  }
  draw(ctx: CanvasRenderingContext2D, title: string, t: number) {
    ctx.fillStyle = "#07040f";
    ctx.fillRect(0, 0, 320, 180);
    if (this.neb) {
      ctx.globalAlpha = 0.5;
      ctx.drawImage(this.neb, 0, 0);
      ctx.globalAlpha = 1;
    }
    this.stars.draw(ctx);
    ctx.fillStyle = "rgba(8,4,14,0.82)";
    ctx.fillRect(0, 0, 320, 180);
    ctx.fillStyle = "rgba(12,7,20,0.95)";
    ctx.fillRect(0, 0, 320, 16);
    ctx.fillStyle = "#d8b06a";
    ctx.fillRect(0, 16, 320, 1);
    drawTitleText(ctx, title, 6, 3, 1, ["#fff6d8", "#ffd23c", "#ff9a1e"], "#12071a");
    const s = getSave();
    drawSprite(ctx, SPRITES.coin, 200, 5, 1, {});
    drawText(ctx, String(s.coins), 208, 5, "#ffd23c");
    drawSprite(ctx, SPRITES.gem, 262, 5, 1, {});
    drawText(ctx, String(s.gems), 270, 5, "#9fe4ff");
    void t;
  }
}

function tabs(ctx: CanvasRenderingContext2D, names: string[], sel: number, y = 20) {
  const w = Math.floor(320 / names.length);
  names.forEach((n, i) => {
    const on = i === sel;
    ctx.fillStyle = on ? "#3a2a4a" : "#1a1226";
    ctx.fillRect(i * w, y, w - 2, 12);
    ctx.fillStyle = on ? "#d8b06a" : "#2c1d3a";
    ctx.fillRect(i * w, y, w - 2, 1);
    ctx.fillRect(i * w, y + 11, w - 2, 1);
    drawTextCentered(ctx, n, i * w + w / 2 - 1, y + 3, on ? "#fff6d8" : "#6f5f86");
  });
}

// ---------------- on-screen keyboard ----------------
const KROWS = ["ABCDEFGHIJ", "KLMNOPQRST", "UVWXYZ0123", "456789"];
export class PixelKeyboard {
  cx = 0;
  cy = 0;
  value = "";
  max = 16;
  update(c: SceneCtx): "ok" | "cancel" | null {
    const i = c.input;
    const rowLen = (r: number) => (r === 3 ? KROWS[3].length + 2 : KROWS[r].length);
    if (i.just("left")) {
      this.cx = (this.cx - 1 + rowLen(this.cy)) % rowLen(this.cy);
      c.sfx("move");
    }
    if (i.just("right")) {
      this.cx = (this.cx + 1) % rowLen(this.cy);
      c.sfx("move");
    }
    if (i.just("up")) {
      this.cy = (this.cy - 1 + 4) % 4;
      this.cx = Math.min(this.cx, rowLen(this.cy) - 1);
      c.sfx("move");
    }
    if (i.just("down")) {
      this.cy = (this.cy + 1) % 4;
      this.cx = Math.min(this.cx, rowLen(this.cy) - 1);
      c.sfx("move");
    }
    if (i.pointer.downNow) {
      const kx = Math.floor((i.pointer.x - 10) / 30);
      const ky = Math.floor((i.pointer.y - 96) / 18);
      if (kx >= 0 && ky >= 0 && ky < 4 && kx < rowLen(ky)) {
        this.cx = kx;
        this.cy = ky;
        return this.press(c);
      }
    }
    if (i.just("fire") || i.just("action")) return this.press(c);
    if (i.just("pause")) return "cancel";
    return null;
  }
  press(c: SceneCtx): "ok" | "cancel" | null {
    if (this.cy === 3) {
      if (this.cx === KROWS[3].length) {
        this.value = this.value.slice(0, -1);
        c.sfx("back");
        return null;
      }
      if (this.cx === KROWS[3].length + 1) {
        c.sfx("select");
        return "ok";
      }
    }
    const ch = KROWS[this.cy][this.cx];
    if (ch && this.value.length < this.max) {
      this.value += ch;
      c.sfx("blip");
    }
    return null;
  }
  draw(ctx: CanvasRenderingContext2D, t: number) {
    for (let r = 0; r < 4; r++) {
      const extra = r === 3 ? 2 : 0;
      for (let k = 0; k < KROWS[r].length + extra; k++) {
        const x = 10 + k * 30;
        const y = 96 + r * 18;
        const on = this.cx === k && this.cy === r;
        const isDel = r === 3 && k === KROWS[3].length;
        const isOk = r === 3 && k === KROWS[3].length + 1;
        ctx.fillStyle = on ? "#d8b06a" : "#241a33";
        ctx.fillRect(x, y, 28, 16);
        ctx.fillStyle = on ? "#fff6d8" : "#3d2b46";
        ctx.fillRect(x, y, 28, 1);
        const lbl = isDel ? "DEL" : isOk ? "OK" : KROWS[r][k];
        drawTextCentered(ctx, lbl, x + 14, y + 5, on ? "#160f1c" : isOk ? "#6fc04a" : "#c8bcd0");
      }
    }
    void t;
  }
}

// ---------------- HANGAR ----------------
export class HangarScene implements Scene {
  music = "menu" as string | null;
  bg = new Backdrop();
  t = 0;
  tab = 0;
  menu = new CanvasMenu([], 8);
  floats = new Floaters();
  msg = "";
  msgT = 0;

  init() {
    this.bg.init();
    this.rebuild();
  }
  rebuild() {
    const s = getSave();
    if (this.tab === 0) {
      this.menu.set(
        SHIPS.map((sh) => ({
          label: sh.name,
          sub: s.owned.includes(sh.id) ? (s.ship === sh.id ? "ACTIVE" : "OWNED") : sh.currency === "gem" ? `${sh.cost}G` : `${sh.cost}C`,
          color: s.owned.includes(sh.id) ? (s.ship === sh.id ? "#6fc04a" : "#c8bcd0") : "#c8bcd0",
        })),
      );
    } else if (this.tab === 1) {
      this.menu.set(
        UPGRADES.map((u) => {
          const lvl = s.upg[u.id] || 0;
          const mx = maxUpg(u.id);
          return { label: `${u.name} ${"|".repeat(lvl)}${".".repeat(mx - lvl)}`, sub: lvl >= mx ? "MAX" : `${upgradeCost(u, lvl)}C`, disabled: lvl >= mx };
        }),
      );
    } else {
      this.menu.set([
        { label: `PAINT: ${PAINTS[s.paint].name}`, sub: "< >" },
        { label: `DECAL: ${DECALS[s.decal]}`, sub: "< >" },
        { label: `TRAIL: ${TRAILS[s.trail].name}`, sub: "< >" },
      ]);
    }
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.bg.update(dt);
    this.floats.update(dt);
    this.msgT -= dt;
    const i = c.input;
    if (this.tab !== 2 && (i.just("left") || i.just("right"))) {
      this.tab = (this.tab + (i.just("right") ? 1 : 2)) % 3;
      this.menu.sel = 0;
      this.rebuild();
      c.sfx("blip");
      return;
    }
    if (this.tab === 2 && (i.just("left") || i.just("right"))) {
      const d = i.just("right") ? 1 : -1;
      mutate((s) => {
        if (this.menu.sel === 0) s.paint = (s.paint + d + PAINTS.length) % PAINTS.length;
        if (this.menu.sel === 1) s.decal = (s.decal + d + DECALS.length) % DECALS.length;
        if (this.menu.sel === 2) s.trail = (s.trail + d + TRAILS.length) % TRAILS.length;
      });
      c.sfx("blip");
      this.rebuild();
      return;
    }
    if (i.pointer.downNow && i.pointer.y < 33 && i.pointer.y > 19) {
      this.tab = clamp(Math.floor(i.pointer.x / 107), 0, 2);
      this.menu.sel = 0;
      this.rebuild();
      c.sfx("blip");
      return;
    }
    const r = this.menu.update(c, 150, 40, 164, 13);
    if (r === null) return;
    if (r === -1) {
      c.goto("menu");
      return;
    }
    const s = getSave();
    if (this.tab === 0) {
      const sh = SHIPS[r];
      if (s.owned.includes(sh.id)) {
        mutate((x) => (x.ship = sh.id));
        c.sfx("select");
        this.say(`${sh.name} EQUIPPED`);
      } else {
        const gem = sh.currency === "gem";
        const ok = gem ? s.gems >= sh.cost : s.coins >= sh.cost;
        if (ok) {
          mutate((x) => {
            if (gem) x.gems -= sh.cost;
            else x.coins -= sh.cost;
            x.owned.push(sh.id);
            x.ship = sh.id;
          });
          c.sfx("buy");
          c.flash(0.4, "#ffe9a8");
          this.say(`${sh.name} PURCHASED!`);
        } else {
          c.sfx("deny");
          this.say("NOT ENOUGH FUNDS");
        }
      }
    } else if (this.tab === 1) {
      const u = UPGRADES[r];
      const lvl = s.upg[u.id] || 0;
      const cost = upgradeCost(u, lvl);
      if (lvl >= maxUpg(u.id)) {
        c.sfx("deny");
        return;
      }
      if (s.coins >= cost) {
        mutate((x) => {
          x.coins -= cost;
          x.upg[u.id] = lvl + 1;
        });
        c.sfx("levelup");
        this.say(`${u.name} -> LV${lvl + 1}`);
      } else {
        c.sfx("deny");
        this.say("NOT ENOUGH COINS");
      }
    }
    this.rebuild();
  }
  say(m: string) {
    this.msg = m;
    this.msgT = 2;
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    this.bg.draw(ctx, "HANGAR", this.t);
    tabs(ctx, ["SHIPS", "UPGRADES", "STYLE"], this.tab);
    const s = c.save;
    // preview bay
    panel(ctx, 4, 36, 142, 138, "rgba(16,10,26,0.9)", "#3d2b46");
    ctx.fillStyle = "#1d1430";
    ctx.fillRect(10, 130, 130, 20);
    ctx.fillStyle = "#2c1d3a";
    for (let i = 0; i < 6; i++) ctx.fillRect(14 + i * 22, 132, 14, 3);
    const previewId = this.tab === 0 ? SHIPS[this.menu.sel].id : s.ship;
    drawShip(ctx, previewId, 75, 90 + Math.sin(this.t * 2) * 3, 3, s.paint, s.decal, 0.25 + Math.abs(Math.sin(this.t * 3)) * 0.1, s.trail, this.t);
    const def = SHIPS.find((x) => x.id === previewId)!;
    drawTextCentered(ctx, def.name, 75, 40, "#ffe9a8");
    const st = [
      ["SPD", def.speed + (s.upg.engine || 0)],
      ["FIR", def.fire + (s.upg.rof || 0)],
      ["DMG", def.dmg + (s.upg.laser || 0)],
      ["HUL", def.hull + (s.upg.hull || 0)],
    ] as [string, number][];
    st.forEach((row, i) => {
      drawText(ctx, row[0], 10, 152 + (i % 2) * 10, "#8a7a96");
      bar(ctx, 30, 152 + (i % 2) * 10, 38, 4, row[1] / 18, "#6fc04a");
      if (i === 1) {
        /* layout */
      }
    });
    st.slice(2).forEach((row, i) => {
      drawText(ctx, row[0], 78, 152 + i * 10, "#8a7a96");
      bar(ctx, 98, 152 + i * 10, 38, 4, row[1] / 18, "#ffd23c");
    });
    // list
    panel(ctx, 148, 36, 168, 138, "rgba(16,10,26,0.9)", "#3d2b46");
    this.menu.draw(ctx, 150, 42, 164, 13, this.t);
    if (this.tab === 0) drawText(ctx, def.desc.slice(0, 26), 152, 162, "#6f5f86");
    if (this.msgT > 0) {
      panel(ctx, 60, 80, 200, 16);
      drawTextCentered(ctx, this.msg, 160, 85, "#ffe9a8");
    }
    prompt(ctx, "ESC: BACK    < > : TABS", 174, true, this.t);
  }
}

// ---------------- SHOP ----------------
export class ShopScene implements Scene {
  music = "menu" as string | null;
  bg = new Backdrop();
  t = 0;
  tab = 0;
  menu = new CanvasMenu([], 5);
  confirm: { name: string; price: string; coins: number; gems: number } | null = null;
  csel = 0;
  adT = 0;
  parts = new Particles();
  msg = "";
  msgT = 0;

  init() {
    this.bg.init();
    this.rebuild();
  }
  rebuild() {
    if (this.tab === 0) this.menu.set(COIN_PACKS.map((p) => ({ label: `${p.name}${p.tag ? " *" : ""}`, sub: p.price })));
    else if (this.tab === 1) this.menu.set(GEM_PACKS.map((p) => ({ label: `${p.name}${p.tag ? " *" : ""}`, sub: p.price })));
    else
      this.menu.set([
        { label: "WATCH AD: +150 COINS", sub: "FREE" },
        { label: "STARTER BUNDLE", sub: "$2.99" },
        { label: "VOID PASS (COSMETICS)", sub: "$7.99" },
        { label: "MEGA VOID BUNDLE", sub: "$59.99" },
        { label: "DAILY GIFT", sub: "FREE" },
      ]);
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.bg.update(dt);
    this.parts.update(dt);
    this.msgT -= dt;
    if (this.adT > 0) {
      this.adT -= dt;
      if (this.adT <= 0) {
        mutate((s) => (s.coins += 150));
        c.sfx("coin");
        this.say("+150 COINS");
      }
      return;
    }
    if (this.confirm) {
      const i = c.input;
      if (i.just("left") || i.just("right")) {
        this.csel = 1 - this.csel;
        c.sfx("move");
      }
      if (i.pointer.downNow && i.pointer.y > 100 && i.pointer.y < 120) {
        this.csel = i.pointer.x < 160 ? 0 : 1;
        this.doConfirm(c);
        return;
      }
      if (i.just("fire") || i.just("action") || i.just("start")) this.doConfirm(c);
      if (i.just("pause")) {
        this.confirm = null;
        c.sfx("back");
      }
      return;
    }
    const i = c.input;
    if (i.just("left") || i.just("right")) {
      this.tab = (this.tab + (i.just("right") ? 1 : 2)) % 3;
      this.menu.sel = 0;
      this.rebuild();
      c.sfx("blip");
      return;
    }
    if (i.pointer.downNow && i.pointer.y < 33 && i.pointer.y > 19) {
      this.tab = clamp(Math.floor(i.pointer.x / 107), 0, 2);
      this.menu.sel = 0;
      this.rebuild();
      c.sfx("blip");
      return;
    }
    const r = this.menu.update(c, 14, 48, 292, 16);
    if (r === null) return;
    if (r === -1) {
      c.goto("menu");
      return;
    }
    if (this.tab === 2) {
      if (r === 0) {
        this.adT = 3;
        c.sfx("select");
        return;
      }
      if (r === 4) {
        mutate((s) => {
          s.coins += 250;
          s.gems += 1;
        });
        c.sfx("gem");
        this.say("DAILY GIFT CLAIMED");
        return;
      }
      const packs: Record<number, { name: string; price: string; coins: number; gems: number }> = {
        1: { name: "STARTER BUNDLE", price: "$2.99", coins: 3000, gems: 5 },
        2: { name: "VOID PASS", price: "$7.99", coins: 6000, gems: 25 },
        3: { name: "MEGA VOID BUNDLE", price: "$59.99", coins: 120000, gems: 600 },
      };
      this.confirm = packs[r];
      this.csel = 0;
      c.sfx("select");
      return;
    }
    const p = (this.tab === 0 ? COIN_PACKS : GEM_PACKS)[r];
    this.confirm = { name: p.name, price: p.price, coins: p.coins, gems: p.gems };
    this.csel = 0;
    c.sfx("select");
  }
  doConfirm(c: SceneCtx) {
    if (!this.confirm) return;
    if (this.csel === 0) {
      const cf = this.confirm;
      mutate((s) => {
        s.coins += cf.coins;
        s.gems += cf.gems;
        s.purchases++;
      });
      c.sfx("buy");
      c.flash(0.5, "#ffe9a8");
      for (let i = 0; i < 40; i++) this.parts.add(rnd(60, 260), rnd(40, 120), rnd(-40, 40), rnd(-60, 20), rnd(0.6, 1.4), ["#ffd23c", "#9fe4ff", "#fff6d8"][irnd(0, 2)], 2, 90);
      this.say(`PURCHASED ${cf.name}`);
    } else c.sfx("back");
    this.confirm = null;
  }
  say(m: string) {
    this.msg = m;
    this.msgT = 2.2;
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    this.bg.draw(ctx, "SHOP", this.t);
    tabs(ctx, ["COINS", "GEMS", "OFFERS"], this.tab);
    panel(ctx, 8, 38, 304, 108, "rgba(16,10,26,0.92)", "#3d2b46");
    const list = this.tab === 0 ? COIN_PACKS : this.tab === 1 ? GEM_PACKS : null;
    if (list) {
      list.forEach((p, i) => {
        const y = 46 + i * 16;
        const on = i === this.menu.sel;
        if (on) {
          ctx.fillStyle = "rgba(216,176,106,0.16)";
          ctx.fillRect(14, y - 2, 292, 16);
          ctx.fillStyle = "#d8b06a";
          ctx.fillRect(14, y - 2, 2, 16);
        }
        drawSprite(ctx, this.tab === 0 ? SPRITES.coin : SPRITES.gem, 20, y + 1, 1, {});
        drawText(ctx, p.name, 30, y, on ? "#fff6d8" : "#a294b8");
        const amt = `${p.coins ? p.coins + "C " : ""}${p.gems ? p.gems + "G" : ""}`;
        drawText(ctx, amt, 30, y + 8, "#6f5f86");
        drawText(ctx, p.price, 260, y + 2, on ? "#6fc04a" : "#8a7a96");
        if (p.tag) drawText(ctx, p.tag, 170, y + 8, "#ff9a8a");
      });
    } else {
      this.menu.draw(ctx, 14, 48, 292, 16, this.t);
    }
    this.parts.draw(ctx);
    drawTextCentered(ctx, "ALL PURCHASES ARE SIMULATED - NO REAL MONEY", 160, 150, "#5f5070");
    if (this.msgT > 0) {
      panel(ctx, 70, 120, 180, 16);
      drawTextCentered(ctx, this.msg, 160, 125, "#ffd23c");
    }
    if (this.adT > 0) {
      ctx.fillStyle = "rgba(0,0,0,0.88)";
      ctx.fillRect(0, 0, 320, 180);
      drawTextCentered(ctx, "FAKE AD PLAYING", 160, 70, "#ffe9a8", 2);
      drawTextCentered(ctx, "BUY VOIDCOLA. IT IS FINE.", 160, 96, "#9fe4ff");
      bar(ctx, 80, 110, 160, 6, 1 - this.adT / 3, "#6fc04a");
      drawTextCentered(ctx, `${Math.ceil(this.adT)}`, 160, 124, "#ffd23c");
    }
    if (this.confirm) {
      ctx.fillStyle = "rgba(0,0,0,0.7)";
      ctx.fillRect(0, 0, 320, 180);
      panel(ctx, 50, 52, 220, 76);
      drawTextCentered(ctx, "CONFIRM PURCHASE", 160, 58, "#ffe9a8");
      drawTextCentered(ctx, this.confirm.name, 160, 72, "#fff6d8");
      drawTextCentered(ctx, `${this.confirm.price}  ->  ${this.confirm.coins}C  ${this.confirm.gems}G`, 160, 84, "#ffd23c");
      drawTextCentered(ctx, "(SIMULATED - NOTHING IS CHARGED)", 160, 94, "#5f5070");
      for (let i = 0; i < 2; i++) {
        const x = 70 + i * 100;
        const on = i === this.csel;
        ctx.fillStyle = on ? "#d8b06a" : "#241a33";
        ctx.fillRect(x, 104, 80, 14);
        drawTextCentered(ctx, i === 0 ? "BUY" : "CANCEL", x + 40, 108, on ? "#160f1c" : "#c8bcd0");
      }
    }
    prompt(ctx, "ESC: BACK", 168, true, this.t);
    void c;
  }
}

// ---------------- SETTINGS ----------------
export class SettingsScene implements Scene {
  music = "menu" as string | null;
  bg = new Backdrop();
  t = 0;
  menu = new CanvasMenu([], 9);
  confirmReset = false;

  init() {
    this.bg.init();
    this.rebuild();
  }
  rebuild() {
    const s = getSave();
    const st = s.settings;
    this.menu.set([
      { label: "SFX VOLUME", sub: volBar(st.sfx) },
      { label: "MUSIC VOLUME", sub: volBar(st.music) },
      { label: "CRT SCANLINES", sub: st.crt ? "ON" : "OFF" },
      { label: "SCREEN SHAKE", sub: st.shake ? "ON" : "OFF" },
      { label: "AUTO FIRE (TOUCH)", sub: st.autofire ? "ON" : "OFF" },
      { label: "TOUCH CONTROLS", sub: st.touch.toUpperCase() },
      { label: "DIFFICULTY", sub: ["CHILL", "NORMAL", "BRUTAL"][st.difficulty] },
      { label: "FULLSCREEN", sub: "TOGGLE" },
      { label: "ERASE ALL DATA", sub: "!", color: "#ff9a8a" },
    ]);
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.bg.update(dt);
    const i = c.input;
    if (this.confirmReset) {
      if (i.just("fire") || i.just("action")) {
        resetSave();
        applySettings();
        this.confirmReset = false;
        this.rebuild();
        c.sfx("bigboom");
      }
      if (i.just("pause") || i.just("alt") || i.pointer.downNow) {
        this.confirmReset = false;
        c.sfx("back");
      }
      return;
    }
    const dir = i.just("right") ? 1 : i.just("left") ? -1 : 0;
    if (dir) {
      mutate((s) => {
        const st = s.settings;
        switch (this.menu.sel) {
          case 0:
            st.sfx = clamp(+(st.sfx + dir * 0.1).toFixed(2), 0, 1);
            break;
          case 1:
            st.music = clamp(+(st.music + dir * 0.1).toFixed(2), 0, 1);
            break;
          case 2:
            st.crt = !st.crt;
            break;
          case 3:
            st.shake = !st.shake;
            break;
          case 4:
            st.autofire = !st.autofire;
            break;
          case 5:
            st.touch = st.touch === "auto" ? "on" : st.touch === "on" ? "off" : "auto";
            break;
          case 6:
            st.difficulty = clamp(st.difficulty + dir, 0, 2) as 0 | 1 | 2;
            break;
        }
      });
      applySettings();
      AUDIO.play("blip");
      this.rebuild();
      return;
    }
    const r = this.menu.update(c, 30, 44, 260, 13);
    if (r === null) return;
    if (r === -1) {
      c.goto("menu");
      return;
    }
    if (r === 8) {
      this.confirmReset = true;
      c.sfx("alarm");
      return;
    }
    if (r === 7) {
      const el = document.documentElement;
      if (!document.fullscreenElement) el.requestFullscreen?.().catch(() => {});
      else document.exitFullscreen?.().catch(() => {});
      c.sfx("select");
      return;
    }
    // toggles on confirm behave like right
    mutate((s) => {
      const st = s.settings;
      if (r === 2) st.crt = !st.crt;
      if (r === 3) st.shake = !st.shake;
      if (r === 4) st.autofire = !st.autofire;
      if (r === 5) st.touch = st.touch === "auto" ? "on" : st.touch === "on" ? "off" : "auto";
      if (r === 6) st.difficulty = ((st.difficulty + 1) % 3) as 0 | 1 | 2;
      if (r === 0) st.sfx = st.sfx >= 1 ? 0 : clamp(+(st.sfx + 0.1).toFixed(2), 0, 1);
      if (r === 1) st.music = st.music >= 1 ? 0 : clamp(+(st.music + 0.1).toFixed(2), 0, 1);
    });
    applySettings();
    AUDIO.play("select");
    this.rebuild();
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    this.bg.draw(ctx, "SETTINGS", this.t);
    panel(ctx, 24, 24, 272, 132, "rgba(16,10,26,0.92)", "#3d2b46");
    drawTextCentered(ctx, "< > TO CHANGE VALUES", 160, 30, "#6f5f86");
    this.menu.draw(ctx, 30, 44, 260, 13, this.t);
    drawText(ctx, `STATS: ${c.save.stats.kills} KILLS  ${c.save.stats.rocks} ROCKS  ${c.save.holes} HOLES`, 30, 160, "#5f5070");
    if (this.confirmReset) {
      ctx.fillStyle = "rgba(0,0,0,0.8)";
      ctx.fillRect(0, 0, 320, 180);
      panel(ctx, 50, 66, 220, 50, "rgba(40,8,8,0.95)", "#d0402e");
      drawTextCentered(ctx, "ERASE EVERYTHING?", 160, 74, "#ff9a8a");
      drawTextCentered(ctx, "ALL SHIPS, HOMES AND COINS GONE.", 160, 88, "#c8bcd0");
      drawTextCentered(ctx, "FIRE = YES      ESC = NO", 160, 102, "#ffd23c");
    }
    prompt(ctx, "ESC: BACK", 170, true, this.t);
  }
}
function volBar(v: number) {
  const n = Math.round(v * 10);
  return "|".repeat(n) + ".".repeat(10 - n);
}

// ---------------- CREDITS ----------------
export class CreditsScene implements Scene {
  music = "end" as string | null;
  bg = new Backdrop();
  t = 0;
  y = 190;
  lines: { t: string; c: string; s?: number }[] = [];

  init() {
    this.bg.init();
    this.lines = [
      { t: "VOIDFALL", c: "#ffd23c", s: 2 },
      { t: "RIDE A SPACESHIP INTO A BLACK HOLE", c: "#9fe4ff" },
      { t: "", c: "#fff" },
      ...CREDITS.flatMap((cr) => [
        { t: cr.role, c: "#6f5f86" },
        { t: cr.name, c: "#fff6d8" },
        { t: "", c: "#fff" },
      ]),
      { t: "BUILT WITH", c: "#6f5f86" },
      { t: "REACT + VITE + CANVAS 2D", c: "#fff6d8" },
      { t: "ALL PIXELS DRAWN IN CODE", c: "#fff6d8" },
      { t: "CHIPTUNE VIA WEB AUDIO", c: "#fff6d8" },
      { t: "", c: "#fff" },
      { t: "NO REAL MONEY WAS SPENT", c: "#6f5f86" },
      { t: "NO REAL PILOTS WERE SPAGHETTIFIED", c: "#6f5f86" },
      { t: "", c: "#fff" },
      { t: "THANK YOU FOR FALLING IN", c: "#ffd23c" },
      { t: "", c: "#fff" },
      { t: "PRESS ESC TO RETURN", c: "#8a7a96" },
    ];
  }
  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.bg.update(dt);
    const fast = c.input.down.fire || c.input.down.down || c.input.pointer.active ? 3 : 1;
    this.y -= dt * 16 * fast;
    const h = this.lines.length * 12 + 40;
    if (this.y < -h) this.y = 190;
    if (c.input.just("pause") || c.input.just("alt") || c.input.just("action")) {
      c.sfx("back");
      c.goto("menu");
    }
  }
  draw(ctx: CanvasRenderingContext2D) {
    this.bg.draw(ctx, "CREDITS", this.t);
    this.lines.forEach((l, i) => {
      const y = this.y + i * 12;
      if (y < 16 || y > 176) return;
      if (l.s === 2) drawTitleText(ctx, l.t, 160 - textWidth(l.t, 2) / 2, y, 2, ["#fff6d8", "#ffd23c", "#ff9a1e", "#d4561f"]);
      else drawTextCentered(ctx, l.t, 160, y, l.c);
    });
    ctx.fillStyle = "rgba(8,4,14,0.9)";
    ctx.fillRect(0, 168, 320, 12);
    drawTextCentered(ctx, "HOLD FIRE TO SCROLL FASTER   ESC: BACK", 160, 171, "#5f5070");
  }
}

// ---------------- CODES / SAVE ----------------
export class CodesScene implements Scene {
  music = "menu" as string | null;
  bg = new Backdrop();
  t = 0;
  mode: "menu" | "key" = "menu";
  kb = new PixelKeyboard();
  menu = new CanvasMenu(
    [
      { label: "ENTER PROMO CODE", sub: ">" },
      { label: "DOWNLOAD SAVE FILE", sub: ".TXT" },
      { label: "COPY SAVE CODE", sub: "CLIP" },
      { label: "LOAD SAVE CODE", sub: "PASTE" },
      { label: "DOWNLOAD GAME DATA", sub: ".JSON" },
      { label: "BACK", sub: "" },
    ],
    6,
  );
  msg = "TIP: TRY THE NAMES IN THE CREDITS.";
  msgC = "#9fe4ff";

  init() {
    this.bg.init();
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.bg.update(dt);
    if (this.mode === "key") {
      const r = this.kb.update(c);
      if (r === "cancel") {
        this.mode = "menu";
        return;
      }
      if (r === "ok") {
        this.redeem(this.kb.value, c);
        this.kb.value = "";
        this.mode = "menu";
      }
      return;
    }
    const r = this.menu.update(c, 20, 44, 180, 14);
    if (r === null) return;
    if (r === -1 || r === 5) {
      c.goto("menu");
      return;
    }
    if (r === 0) {
      this.mode = "key";
      this.kb.value = "";
      c.sfx("select");
    } else if (r === 1) {
      download("voidfall-save.txt", exportSave());
      this.say("SAVE FILE DOWNLOADED", "#6fc04a");
      c.sfx("code");
    } else if (r === 2) {
      const code = exportSave();
      navigator.clipboard?.writeText(code).then(
        () => this.say("SAVE CODE COPIED", "#6fc04a"),
        () => this.say("CLIPBOARD BLOCKED", "#ff9a8a"),
      );
      c.sfx("code");
    } else if (r === 3) {
      const v = window.prompt("PASTE YOUR VOIDFALL SAVE CODE:");
      if (v && importSave(v)) {
        applySettings();
        this.say("SAVE LOADED!", "#6fc04a");
        c.sfx("levelup");
      } else {
        this.say("BAD CODE", "#ff9a8a");
        c.sfx("deny");
      }
    } else if (r === 4) {
      download("voidfall-data.json", JSON.stringify(getSave(), null, 2));
      this.say("DATA EXPORTED", "#6fc04a");
      c.sfx("code");
    }
  }

  redeem(code: string, c: SceneCtx) {
    const k = code.trim().toUpperCase();
    const s = getSave();
    if (!k) return;
    if (s.codes.includes(k)) {
      this.say("CODE ALREADY USED", "#ff9a8a");
      c.sfx("deny");
      return;
    }
    const e = CODES[k];
    if (!e) {
      this.say("INVALID CODE", "#ff9a8a");
      c.sfx("deny");
      return;
    }
    mutate((x) => {
      x.coins += e.coins || 0;
      x.gems += e.gems || 0;
      if (e.ship && !x.owned.includes(e.ship)) x.owned.push(e.ship);
      x.codes.push(k);
    });
    this.say(e.msg, "#6fc04a");
    c.sfx("levelup");
    c.flash(0.5, "#ffe9a8");
  }
  say(m: string, col: string) {
    this.msg = m;
    this.msgC = col;
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    this.bg.draw(ctx, "CODES + SAVE", this.t);
    if (this.mode === "menu") {
      panel(ctx, 14, 24, 190, 130, "rgba(16,10,26,0.92)", "#3d2b46");
      drawText(ctx, "SAVE + CODE TOOLS", 20, 30, "#ffe9a8");
      this.menu.draw(ctx, 20, 44, 180, 14, this.t);
      panel(ctx, 208, 24, 104, 130, "rgba(16,10,26,0.92)", "#3d2b46");
      drawText(ctx, "REDEEMED", 214, 30, "#ffe9a8");
      const list = c.save.codes.slice(-9);
      if (!list.length) drawText(ctx, "NONE YET", 214, 44, "#5f5070");
      list.forEach((k, i) => drawText(ctx, k.slice(0, 14), 214, 44 + i * 10, "#6fc04a"));
      panel(ctx, 14, 158, 298, 16, "rgba(16,10,26,0.92)", "#3d2b46");
      drawTextCentered(ctx, this.msg.slice(0, 46), 160, 163, this.msgC);
    } else {
      panel(ctx, 20, 24, 280, 56);
      drawTextCentered(ctx, "ENTER PROMO CODE", 160, 30, "#ffe9a8");
      ctx.fillStyle = "#0d0714";
      ctx.fillRect(40, 44, 240, 18);
      ctx.fillStyle = "#3d2b46";
      ctx.fillRect(40, 44, 240, 1);
      const v = this.kb.value + (Math.floor(this.t * 2) % 2 ? "_" : "");
      drawTextCentered(ctx, v || "_", 160, 50, "#ffd23c", 2);
      drawTextCentered(ctx, "CODES ARE HIDDEN IN THE CREDITS", 160, 68, "#5f5070");
      this.kb.draw(ctx, this.t);
      drawTextCentered(ctx, "ESC TO CANCEL", 160, 172, "#5f5070");
    }
  }
}

function download(name: string, text: string) {
  try {
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  } catch {
    /* ignore */
  }
}

// ---------------- PILOT CUSTOMIZE ----------------
export class CharacterScene implements Scene {
  music = "menu" as string | null;
  bg = new Backdrop();
  t = 0;
  menu = new CanvasMenu([], 7);
  mode: "menu" | "key" = "menu";
  kb = new PixelKeyboard();

  init() {
    this.bg.init();
    this.kb.max = 10;
    this.rebuild();
  }
  rebuild() {
    const ch = getSave().char;
    this.menu.set([
      { label: "SKIN TONE", sub: `${ch.skin + 1}/${SKINS.length}` },
      { label: "SUIT COLOR", sub: `${ch.suit + 1}/${SUITS.length}` },
      { label: "HAIR COLOR", sub: `${ch.hair + 1}/${HAIRS.length}` },
      { label: "VISOR", sub: `${ch.visor + 1}/${VISORS.length}` },
      { label: "PILOT NAME", sub: ch.name },
      { label: "RANDOMIZE", sub: "?" },
      { label: "DONE", sub: "" },
    ]);
  }
  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.bg.update(dt);
    if (this.mode === "key") {
      const r = this.kb.update(c);
      if (r) {
        if (r === "ok" && this.kb.value.trim()) mutate((s) => (s.char.name = this.kb.value.trim()));
        this.mode = "menu";
        this.rebuild();
      }
      return;
    }
    const i = c.input;
    const dir = i.just("right") ? 1 : i.just("left") ? -1 : 0;
    if (dir) {
      mutate((s) => {
        const ch = s.char;
        if (this.menu.sel === 0) ch.skin = (ch.skin + dir + SKINS.length) % SKINS.length;
        if (this.menu.sel === 1) ch.suit = (ch.suit + dir + SUITS.length) % SUITS.length;
        if (this.menu.sel === 2) ch.hair = (ch.hair + dir + HAIRS.length) % HAIRS.length;
        if (this.menu.sel === 3) ch.visor = (ch.visor + dir + VISORS.length) % VISORS.length;
      });
      c.sfx("blip");
      this.rebuild();
      return;
    }
    const r = this.menu.update(c, 150, 44, 160, 14);
    if (r === null) return;
    if (r === -1 || r === 6) {
      c.sfx("back");
      c.goto("menu");
      return;
    }
    if (r === 4) {
      this.mode = "key";
      this.kb.value = "";
      c.sfx("select");
      return;
    }
    if (r === 5) {
      mutate((s) => {
        s.char.skin = irnd(0, SKINS.length - 1);
        s.char.suit = irnd(0, SUITS.length - 1);
        s.char.hair = irnd(0, HAIRS.length - 1);
        s.char.visor = irnd(0, VISORS.length - 1);
      });
      c.sfx("levelup");
      this.rebuild();
      return;
    }
    mutate((s) => {
      const ch = s.char;
      if (r === 0) ch.skin = (ch.skin + 1) % SKINS.length;
      if (r === 1) ch.suit = (ch.suit + 1) % SUITS.length;
      if (r === 2) ch.hair = (ch.hair + 1) % HAIRS.length;
      if (r === 3) ch.visor = (ch.visor + 1) % VISORS.length;
    });
    c.sfx("blip");
    this.rebuild();
  }
  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    this.bg.draw(ctx, "PILOT", this.t);
    if (this.mode === "key") {
      panel(ctx, 20, 24, 280, 52);
      drawTextCentered(ctx, "PILOT NAME", 160, 30, "#ffe9a8");
      ctx.fillStyle = "#0d0714";
      ctx.fillRect(60, 44, 200, 18);
      drawTextCentered(ctx, this.kb.value + (Math.floor(this.t * 2) % 2 ? "_" : ""), 160, 50, "#ffd23c", 2);
      this.kb.draw(ctx, this.t);
      return;
    }
    panel(ctx, 6, 24, 138, 148, "rgba(16,10,26,0.92)", "#3d2b46");
    ctx.fillStyle = "#1d1430";
    ctx.fillRect(14, 140, 122, 24);
    const ch = c.save.char;
    const cfg = { skin: SKINS[ch.skin], suit: SUITS[ch.suit], hair: HAIRS[ch.hair], visor: VISORS[ch.visor] };
    drawHuman(ctx, 58, 60, 6, cfg, Math.floor(this.t * 6) % 4);
    drawTextCentered(ctx, ch.name, 75, 166, "#ffe9a8");
    panel(ctx, 146, 24, 168, 148, "rgba(16,10,26,0.92)", "#3d2b46");
    drawText(ctx, "APPEARANCE", 152, 30, "#ffe9a8");
    this.menu.draw(ctx, 150, 44, 160, 14, this.t);
    drawText(ctx, "< > CHANGE", 152, 158, "#5f5070");
    void shade;
  }
}
