import { drawText, drawTextCentered, textWidth } from "../game/font";
import { drawSprite, SPRITES, shade } from "../game/sprites";
import type { SaveState } from "../game/save";

export const rnd = (a: number, b: number) => a + Math.random() * (b - a);
export const irnd = (a: number, b: number) => Math.floor(rnd(a, b + 1));
export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export interface P {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  c: string;
  s: number;
  g?: number;
}

export class Particles {
  list: P[] = [];
  add(x: number, y: number, vx: number, vy: number, life: number, c: string, s = 1, g = 0) {
    if (this.list.length > 420) return;
    this.list.push({ x, y, vx, vy, life, max: life, c, s, g });
  }
  burst(x: number, y: number, n: number, cols: string[], spd = 60, life = 0.6, s = 1, g = 0) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2;
      const v = spd * (0.3 + Math.random());
      this.add(x, y, Math.cos(a) * v, Math.sin(a) * v, life * (0.5 + Math.random()), cols[(Math.random() * cols.length) | 0], s, g);
    }
  }
  update(dt: number) {
    for (let i = this.list.length - 1; i >= 0; i--) {
      const p = this.list[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.list.splice(i, 1);
        continue;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      if (p.g) p.vy += p.g * dt;
    }
  }
  draw(ctx: CanvasRenderingContext2D) {
    for (const p of this.list) {
      const f = p.life / p.max;
      ctx.fillStyle = f < 0.35 ? shade(p.c, -0.4) : p.c;
      const s = f < 0.25 ? Math.max(1, p.s - 1) : p.s;
      ctx.fillRect(p.x | 0, p.y | 0, s, s);
    }
  }
  clear() {
    this.list = [];
  }
}

export interface Floater {
  x: number;
  y: number;
  t: string;
  life: number;
  c: string;
}
export class Floaters {
  list: Floater[] = [];
  add(x: number, y: number, t: string, c = "#ffe9a8") {
    this.list.push({ x, y, t, life: 1.1, c });
  }
  update(dt: number) {
    for (let i = this.list.length - 1; i >= 0; i--) {
      const f = this.list[i];
      f.life -= dt;
      f.y -= dt * 14;
      if (f.life <= 0) this.list.splice(i, 1);
    }
  }
  draw(ctx: CanvasRenderingContext2D) {
    for (const f of this.list) {
      if (f.life < 0.35 && Math.floor(f.life * 20) % 2 === 0) continue;
      drawTextCentered(ctx, f.t, f.x, f.y, f.c, 1, "#160f1c");
    }
  }
}

export function panel(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  fill = "rgba(18,12,26,0.86)",
  border = "#d8b06a",
) {
  ctx.fillStyle = fill;
  ctx.fillRect(x, y, w, h);
  ctx.fillStyle = border;
  ctx.fillRect(x, y, w, 1);
  ctx.fillRect(x, y + h - 1, w, 1);
  ctx.fillRect(x, y, 1, h);
  ctx.fillRect(x + w - 1, y, 1, h);
  ctx.fillStyle = shade(border, -0.45);
  ctx.fillRect(x + 1, y + 1, w - 2, 1);
  ctx.fillRect(x + 1, y + h - 2, w - 2, 1);
}

export function bar(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  pct: number,
  col: string,
  bg = "#2a1e30",
) {
  ctx.fillStyle = "#160f1c";
  ctx.fillRect(x - 1, y - 1, w + 2, h + 2);
  ctx.fillStyle = bg;
  ctx.fillRect(x, y, w, h);
  ctx.fillStyle = col;
  ctx.fillRect(x, y, Math.max(0, Math.round(w * clamp(pct, 0, 1))), h);
  ctx.fillStyle = shade(col, 0.3);
  ctx.fillRect(x, y, Math.max(0, Math.round(w * clamp(pct, 0, 1))), 1);
}

export function hud(ctx: CanvasRenderingContext2D, save: SaveState, hp?: number, maxHp?: number, extra?: string) {
  ctx.fillStyle = "rgba(10,6,16,0.72)";
  ctx.fillRect(0, 0, 320, 11);
  ctx.fillStyle = "#3d2b46";
  ctx.fillRect(0, 11, 320, 1);
  drawSprite(ctx, SPRITES.coin, 3, 3, 1, {});
  drawText(ctx, String(save.coins), 10, 3, "#ffd23c", 1, "#160f1c");
  drawSprite(ctx, SPRITES.gem, 46, 3, 1, {});
  drawText(ctx, String(save.gems), 53, 3, "#9fe4ff", 1, "#160f1c");
  if (hp !== undefined && maxHp) {
    drawText(ctx, "HULL", 84, 3, "#c8bcd0");
    bar(ctx, 108, 3, 52, 5, hp / maxHp, hp / maxHp > 0.35 ? "#6fc04a" : "#d0402e");
  }
  if (extra) drawText(ctx, extra, 320 - textWidth(extra, 1) - 4, 3, "#e8dcc0", 1, "#160f1c");
}

export function prompt(ctx: CanvasRenderingContext2D, txt: string, y: number, blink = true, t = 0) {
  if (blink && Math.floor(t * 2) % 2 === 0) return;
  drawTextCentered(ctx, txt, 160, y, "#ffe9a8", 1, "#160f1c");
}

export function dither(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, c: string, density = 0.5) {
  ctx.fillStyle = c;
  for (let yy = y; yy < y + h; yy += 2)
    for (let xx = x; xx < x + w; xx += 2) {
      if (((xx + yy) / 2) % 2 < density * 2) ctx.fillRect(xx, yy, 2, 2);
    }
}

export function vgrad(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, top: string, bot: string, steps = 12) {
  for (let i = 0; i < steps; i++) {
    const t = i / (steps - 1);
    ctx.fillStyle = mix(top, bot, t);
    ctx.fillRect(x, Math.round(y + (h * i) / steps), w, Math.ceil(h / steps) + 1);
  }
}

export function mix(a: string, b: string, t: number): string {
  const pa = parseHex(a);
  const pb = parseHex(b);
  return `rgb(${(pa[0] + (pb[0] - pa[0]) * t) | 0},${(pa[1] + (pb[1] - pa[1]) * t) | 0},${(pa[2] + (pb[2] - pa[2]) * t) | 0})`;
}
function parseHex(h: string): [number, number, number] {
  if (h.startsWith("rgb")) {
    const m = h.match(/\d+/g)!;
    return [+m[0], +m[1], +m[2]];
  }
  const c = h.replace("#", "");
  const s = c.length === 3 ? c.split("").map((x) => x + x).join("") : c;
  const n = parseInt(s, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function fmtTime(s: number) {
  const m = Math.floor(s / 60);
  const ss = Math.floor(s % 60);
  return `${m}:${ss < 10 ? "0" : ""}${ss}`;
}
