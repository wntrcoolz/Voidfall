import type { Scene, SceneCtx } from "../game/engine";
import { drawText, drawTextCentered, drawTitleText, textWidth } from "../game/font";
import { Starfield, drawPlanet, drawBlackHole, drawSprite, SPRITES, asteroidCanvas, makeNebula, drawShip } from "../game/sprites";
import { PLANETS, type PlanetDef } from "../game/data";
import { mutate, planetSave, getSave } from "../game/save";
import { PlayerShip, type Bullet } from "./ship";
import { Particles, Floaters, panel, bar, hud, clamp, rnd, irnd, prompt } from "./common";

// ============================== SOLAR SYSTEM MAP ==============================
export class MapScene implements Scene {
  music = "menu" as string | null;
  t = 0;
  sel = 2;
  stars = new Starfield(120, 320, 180);
  neb!: HTMLCanvasElement;
  targets: { id: string; x: number; y: number; r: number; def?: PlanetDef }[] = [];

  init() {
    this.neb = makeNebula(320, 180, ["#211436", "#331d47", "#151030"], 40);
    const ys = [96, 70, 104, 66, 108, 64, 100, 72];
    PLANETS.forEach((p, i) => {
      if (p.id === "sun") return;
      this.targets.push({ id: p.id, x: 26 + i * 30, y: ys[i % ys.length], r: 7 + p.dist * 0.6, def: p });
    });
    const sun = PLANETS.find((p) => p.id === "sun")!;
    this.targets.unshift({ id: "sun", x: 8, y: 88, r: 16, def: sun });
    this.targets.push({ id: "blackhole", x: 300, y: 88, r: 10 });
    this.sel = this.targets.findIndex((x) => x.id === "earth");
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.stars.update(dt, 4, 0, 320, 180);
    const i = c.input;
    if (i.just("left")) {
      this.sel = (this.sel - 1 + this.targets.length) % this.targets.length;
      c.sfx("move");
    }
    if (i.just("right")) {
      this.sel = (this.sel + 1) % this.targets.length;
      c.sfx("move");
    }
    if (i.pointer.downNow) {
      let best = -1,
        bd = 26;
      this.targets.forEach((tg, k) => {
        const d = Math.hypot(tg.x - i.pointer.x, tg.y - i.pointer.y);
        if (d < bd) {
          bd = d;
          best = k;
        }
      });
      if (best >= 0) {
        if (best === this.sel) this.go(c);
        else {
          this.sel = best;
          c.sfx("move");
        }
      }
    }
    if (i.just("fire") || i.just("action") || i.just("start")) this.go(c);
    if (i.just("pause")) {
      c.sfx("back");
      c.goto("menu");
    }
  }

  go(c: SceneCtx) {
    const tg = this.targets[this.sel];
    c.sfx("select");
    if (tg.id === "blackhole") c.goto("launch", {});
    else c.goto("flight", { target: tg.id });
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    ctx.fillStyle = "#06030d";
    ctx.fillRect(0, 0, 320, 180);
    ctx.globalAlpha = 0.6;
    ctx.drawImage(this.neb, 0, 0);
    ctx.globalAlpha = 1;
    this.stars.draw(ctx);
    // orbit lines
    ctx.fillStyle = "#1d1630";
    for (const tg of this.targets) {
      if (tg.id === "sun" || tg.id === "blackhole") continue;
      for (let a = 0; a < Math.PI * 2; a += 0.25) {
        const x = 8 + Math.cos(a) * (tg.x - 8);
        const y = 88 + Math.sin(a) * (tg.x - 8) * 0.35;
        if (x > 0 && x < 320 && y > 12 && y < 150) ctx.fillRect(x | 0, y | 0, 1, 1);
      }
    }
    for (const tg of this.targets) {
      if (tg.id === "blackhole") drawBlackHole(ctx, tg.x, tg.y, 7, this.t, 2, 0.28, 1);
      else if (tg.def) drawPlanet(ctx, tg.x, tg.y, tg.r, tg.def, this.t, 2);
      const ps = tg.def ? planetSave(tg.id) : null;
      if (ps?.home.built) drawSprite(ctx, SPRITES.flag, tg.x - 2, tg.y - tg.r - 9, 1, { R: "#6fc04a" });
    }
    const s = this.targets[this.sel];
    if (Math.floor(this.t * 3) % 2 === 0) {
      ctx.fillStyle = "#ffd23c";
      const r = s.r + 5;
      for (const [dx, dy] of [
        [-1, -1],
        [1, -1],
        [-1, 1],
        [1, 1],
      ]) {
        ctx.fillRect(s.x + dx * r - 1, s.y + dy * r - 1, 3, 1);
        ctx.fillRect(s.x + dx * r - 1, s.y + dy * r - 1, 1, 3);
      }
    }
    hud(ctx, c.save, undefined, undefined, "NAV CHART");
    panel(ctx, 4, 126, 312, 50);
    if (s.id === "blackhole") {
      drawText(ctx, "SAGITTARIUS A-JR", 10, 131, "#ffe9a8");
      drawText(ctx, "A HOLE IN EVERYTHING. THE MAIN EVENT.", 10, 142, "#c8bcd0");
      drawText(ctx, "MISSION: LAUNCH -> CRUISE -> HORIZON -> ???", 10, 152, "#9fe4ff");
      drawText(ctx, `ENTERED ${c.save.holes} TIMES`, 10, 163, "#ffd23c");
    } else if (s.def) {
      const ps = planetSave(s.id);
      drawText(ctx, s.def.name, 10, 131, "#ffe9a8");
      drawText(ctx, s.def.desc.slice(0, 44), 10, 142, "#c8bcd0");
      drawText(ctx, `HAZARD ${s.def.hazard}  GRAV ${s.def.gravity}G`, 10, 152, "#9fe4ff");
      drawText(ctx, ps.home.built ? `HOME: ${ps.home.name} LV${ps.home.level}` : "NO HOME BUILT", 10, 163, ps.home.built ? "#6fc04a" : "#8a7a96");
      drawText(ctx, `RISK ${"*".repeat(Math.min(10, s.def.dist))}`, 200, 163, "#ff9a8a");
    }
    prompt(ctx, "SELECT: < >   TRAVEL: FIRE   BACK: ESC", 118, true, this.t);
  }
}

// ============================== SPACE COMBAT / TRAVEL ==============================
interface Enemy {
  x: number;
  y: number;
  vx: number;
  vy: number;
  hp: number;
  max: number;
  kind: "ufo" | "fighter" | "rock" | "boss";
  r: number;
  cool: number;
  t: number;
  v: number;
  c: string;
  hit: number;
}
interface Pickup {
  x: number;
  y: number;
  vy: number;
  kind: "coin" | "gem" | "heart" | "shield";
}

export class FlightScene implements Scene {
  music = "flight" as string | null;
  ship!: PlayerShip;
  stars = new Starfield(130, 320, 180);
  neb!: HTMLCanvasElement;
  parts = new Particles();
  floats = new Floaters();
  enemies: Enemy[] = [];
  ebullets: Bullet[] = [];
  pickups: Pickup[] = [];
  t = 0;
  dist = 0;
  total = 100;
  spawn = 1;
  def!: PlanetDef;
  over = false;
  overT = 0;
  bossSpawned = false;
  earned = 0;

  init(c: SceneCtx) {
    this.def = PLANETS.find((p) => p.id === (c.payload?.target || "earth"))!;
    this.total = 60 + this.def.dist * 14;
    this.ship = new PlayerShip(160, 140);
    this.neb = makeNebula(320, 180, ["#1d1436", "#2e1a44", "#3a1f30"], 45);
  }

  diff(c: SceneCtx) {
    return 0.7 + c.save.settings.difficulty * 0.35 + this.def.dist * 0.08;
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.parts.update(dt);
    this.floats.update(dt);
    this.stars.update(dt, 0, 90, 320, 180);
    if (this.over) {
      this.overT += dt;
      if (this.overT > 2.2 && (c.input.just("fire") || c.input.just("start") || c.input.pointer.downNow)) c.goto("map");
      return;
    }
    if (c.input.just("pause")) {
      c.sfx("back");
      c.goto("map");
      return;
    }
    this.dist += dt * 3.4;
    this.ship.control(dt, c, { x0: 12, y0: 30, x1: 308, y1: 172 }, true, true);
    this.ship.updateBullets(dt);

    // spawn
    this.spawn -= dt;
    if (this.spawn <= 0 && this.dist < this.total - 8) {
      this.spawn = rnd(0.7, 1.5) / this.diff(c);
      const roll = Math.random();
      if (roll < 0.5) this.enemies.push(this.mkRock());
      else if (roll < 0.78) this.enemies.push(this.mkUfo());
      else this.enemies.push(this.mkFighter());
    }
    if (!this.bossSpawned && this.def.dist >= 5 && this.dist > this.total * 0.7) {
      this.bossSpawned = true;
      this.enemies.push({ x: 160, y: -30, vx: 24, vy: 10, hp: 220 + this.def.dist * 40, max: 220 + this.def.dist * 40, kind: "boss", r: 22, cool: 1, t: 0, v: 0, c: "#a35cb0", hit: 0 });
      c.sfx("alarm");
    }

    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      e.t += dt;
      e.hit = Math.max(0, e.hit - dt);
      if (e.kind === "ufo") {
        e.x += Math.sin(e.t * 2) * 40 * dt;
        e.y += e.vy * dt;
        e.cool -= dt;
        if (e.cool <= 0 && e.y > 10 && e.y < 150) {
          e.cool = rnd(1.2, 2.4) / this.diff(c);
          this.fireAt(e, 80, c);
        }
      } else if (e.kind === "fighter") {
        e.x += e.vx * dt;
        e.y += e.vy * dt;
        if (e.x < 14 || e.x > 306) e.vx *= -1;
        e.cool -= dt;
        if (e.cool <= 0 && e.y < 150) {
          e.cool = rnd(0.9, 1.8) / this.diff(c);
          this.fireAt(e, 110, c);
        }
      } else if (e.kind === "boss") {
        e.y += (Math.min(34, e.y + 1) - e.y) * dt * 2;
        e.x += e.vx * dt;
        if (e.x < 46 || e.x > 274) e.vx *= -1;
        e.cool -= dt;
        if (e.cool <= 0) {
          e.cool = 0.9 / this.diff(c);
          for (let k = -2; k <= 2; k++)
            this.ebullets.push({ x: e.x + k * 8, y: e.y + 14, vx: k * 22, vy: 90, dmg: 10, life: 4, c: "#ff9a8a", w: 3, h: 4, enemy: true });
          c.sfx("laser2");
        }
      } else {
        e.x += e.vx * dt;
        e.y += e.vy * dt;
      }
      if (e.y > 200 || e.x < -40 || e.x > 360) {
        this.enemies.splice(i, 1);
        continue;
      }
      // player bullets
      for (let j = this.ship.bullets.length - 1; j >= 0; j--) {
        const b = this.ship.bullets[j];
        if (Math.abs(b.x - e.x) < e.r + 2 && Math.abs(b.y - e.y) < e.r + 3) {
          e.hp -= b.dmg;
          e.hit = 0.1;
          this.ship.bullets.splice(j, 1);
          this.parts.burst(b.x, b.y, 3, ["#ffe9a8", "#ffd23c"], 40, 0.25, 1);
          if (e.hp <= 0) {
            this.kill(e, c);
            this.enemies.splice(i, 1);
          } else c.sfx("hit");
          break;
        }
      }
      if (Math.hypot(this.ship.x - e.x, this.ship.y - e.y) < e.r + 7) {
        this.ship.damage(e.kind === "boss" ? 22 : 10, c, this.parts);
        if (e.kind !== "boss") {
          e.hp -= 40;
          if (e.hp <= 0) {
            this.kill(e, c);
            this.enemies.splice(i, 1);
          }
        }
      }
    }
    // enemy bullets
    for (let i = this.ebullets.length - 1; i >= 0; i--) {
      const b = this.ebullets[i];
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.life -= dt;
      if (b.life <= 0 || b.y > 190 || b.y < -10) {
        this.ebullets.splice(i, 1);
        continue;
      }
      if (Math.abs(b.x - this.ship.x) < 6 && Math.abs(b.y - this.ship.y) < 9) {
        this.ship.damage(b.dmg, c, this.parts);
        this.ebullets.splice(i, 1);
      }
    }
    // pickups
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i];
      p.y += p.vy * dt;
      const d = Math.hypot(p.x - this.ship.x, p.y - this.ship.y);
      if (d < this.ship.stats.magnet) {
        p.x += ((this.ship.x - p.x) / d) * 120 * dt;
        p.y += ((this.ship.y - p.y) / d) * 120 * dt;
      }
      if (d < 9) {
        this.grab(p, c);
        this.pickups.splice(i, 1);
        continue;
      }
      if (p.y > 195) this.pickups.splice(i, 1);
    }
    if (this.ship.dead) {
      this.over = true;
      c.sfx("bigboom");
      c.shake(14);
      this.parts.burst(this.ship.x, this.ship.y, 40, ["#ffe9a8", "#ffae3b", "#d0402e", "#6a6a78"], 110, 1.1, 2);
      mutate((s) => {
        s.stats.deaths++;
        s.coins = Math.max(0, s.coins - 50);
      });
      return;
    }
    if (this.dist >= this.total) {
      c.sfx("land");
      mutate((s) => (s.stats.ly += this.def.dist));
      c.goto("planet", { target: this.def.id });
    }
  }

  mkRock(): Enemy {
    const r = rnd(5, 12);
    return { x: rnd(20, 300), y: -14, vx: rnd(-20, 20), vy: rnd(45, 85), hp: r * 3, max: r * 3, kind: "rock", r, cool: 0, t: 0, v: irnd(0, 7), c: ["#8a7a6a", "#a4502e", "#6f6f60"][irnd(0, 2)], hit: 0 };
  }
  mkUfo(): Enemy {
    return { x: rnd(30, 290), y: -12, vx: 0, vy: rnd(24, 40), hp: 26, max: 26, kind: "ufo", r: 7, cool: rnd(0.6, 1.4), t: rnd(0, 6), v: 0, c: "#6fc04a", hit: 0 };
  }
  mkFighter(): Enemy {
    return { x: rnd(30, 290), y: -12, vx: rnd(-60, 60), vy: rnd(30, 46), hp: 34, max: 34, kind: "fighter", r: 7, cool: rnd(0.5, 1.2), t: 0, v: 0, c: "#a35cb0", hit: 0 };
  }
  fireAt(e: Enemy, spd: number, c: SceneCtx) {
    const dx = this.ship.x - e.x,
      dy = this.ship.y - e.y;
    const d = Math.max(1, Math.hypot(dx, dy));
    this.ebullets.push({ x: e.x, y: e.y + 6, vx: (dx / d) * spd, vy: (dy / d) * spd, dmg: 8, life: 4, c: "#8fe04a", w: 3, h: 3, enemy: true });
    c.sfx("ufo");
  }
  kill(e: Enemy, c: SceneCtx) {
    this.parts.burst(e.x, e.y, e.kind === "boss" ? 50 : 14, [e.c, "#ffe9a8", "#ffae3b"], e.kind === "boss" ? 130 : 80, 0.7, 2);
    c.sfx(e.kind === "boss" ? "bigboom" : "explode");
    c.shake(e.kind === "boss" ? 12 : 4);
    const val = e.kind === "rock" ? Math.round(e.r * 3) : e.kind === "boss" ? 900 : 45;
    this.earned += val;
    mutate((s) => {
      s.coins += val;
      if (e.kind === "rock") s.stats.rocks++;
      else s.stats.kills++;
    });
    this.floats.add(e.x, e.y, `+${val}`, "#ffd23c");
    const roll = Math.random();
    if (e.kind === "boss") {
      for (let i = 0; i < 5; i++) this.pickups.push({ x: e.x + rnd(-20, 20), y: e.y, vy: 40, kind: "gem" });
    } else if (roll < 0.1) this.pickups.push({ x: e.x, y: e.y, vy: 40, kind: "heart" });
    else if (roll < 0.14) this.pickups.push({ x: e.x, y: e.y, vy: 40, kind: "gem" });
    else if (roll < 0.2 && this.ship.shieldMax > 0) this.pickups.push({ x: e.x, y: e.y, vy: 40, kind: "shield" });
    else if (roll < 0.55) this.pickups.push({ x: e.x, y: e.y, vy: 40, kind: "coin" });
  }
  grab(p: Pickup, c: SceneCtx) {
    if (p.kind === "coin") {
      mutate((s) => (s.coins += 25));
      this.floats.add(p.x, p.y, "+25", "#ffd23c");
      c.sfx("coin");
    } else if (p.kind === "gem") {
      mutate((s) => (s.gems += 1));
      this.floats.add(p.x, p.y, "+1 GEM", "#9fe4ff");
      c.sfx("gem");
    } else if (p.kind === "heart") {
      this.ship.hp = Math.min(this.ship.maxHp, this.ship.hp + 30);
      this.floats.add(p.x, p.y, "+30 HULL", "#6fc04a");
      c.sfx("levelup");
    } else {
      this.ship.shield = Math.min(this.ship.shieldMax, this.ship.shield + 1);
      this.floats.add(p.x, p.y, "SHIELD", "#7fd0e8");
      c.sfx("shield");
    }
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    ctx.fillStyle = "#06030e";
    ctx.fillRect(0, 0, 320, 180);
    ctx.globalAlpha = 0.55;
    const ny = (this.t * 14) % 180;
    ctx.drawImage(this.neb, 0, ny);
    ctx.drawImage(this.neb, 0, ny - 180);
    ctx.globalAlpha = 1;
    this.stars.draw(ctx);
    // destination growing ahead
    const near = clamp((this.dist / this.total - 0.55) / 0.45, 0, 1);
    if (near > 0) drawPlanet(ctx, 160, 34, 6 + near * 26, this.def, this.t, 2);

    for (const e of this.enemies) {
      if (e.hit > 0) ctx.globalAlpha = 0.65;
      if (e.kind === "rock") {
        const s = Math.max(4, Math.round(e.r * 2));
        ctx.drawImage(asteroidCanvas(e.v, 0, e.c), Math.round(e.x - s / 2), Math.round(e.y - s / 2), s, s);
      } else if (e.kind === "ufo") drawSprite(ctx, SPRITES.ufo, e.x - 6, e.y - 4, 1, {});
      else if (e.kind === "fighter") drawSprite(ctx, SPRITES.alien_drone, e.x - 8, e.y - 6, 2, { E: "#a35cb0" });
      else drawSprite(ctx, SPRITES.boss, e.x - 21, e.y - 12, 2, {});
      ctx.globalAlpha = 1;
    }
    this.parts.draw(ctx);
    for (const p of this.pickups) {
      const sp = p.kind === "coin" ? SPRITES.coin : p.kind === "gem" ? SPRITES.gem : p.kind === "heart" ? SPRITES.heart : SPRITES.shieldpk;
      drawSprite(ctx, sp, p.x - 2, p.y - 2, 1, {});
    }
    for (const b of this.ebullets) {
      ctx.fillStyle = b.c;
      ctx.fillRect((b.x - b.w / 2) | 0, (b.y - b.h / 2) | 0, b.w, b.h);
    }
    this.ship.drawBullets(ctx);
    if (!this.over) this.ship.draw(ctx, this.t);
    this.floats.draw(ctx);

    hud(ctx, c.save, this.ship.hp, this.ship.maxHp, `-> ${this.def.name}`);
    bar(ctx, 60, 172, 200, 4, this.dist / this.total, "#7fc2e8");
    drawText(ctx, "NAV", 40, 171, "#c8bcd0");
    drawText(ctx, `${Math.round((this.dist / this.total) * 100)}%`, 266, 171, "#9fe4ff");
    const boss = this.enemies.find((e) => e.kind === "boss");
    if (boss) {
      drawText(ctx, "ALIEN MOTHERSHIP", 100, 14, "#ff9a8a");
      bar(ctx, 60, 23, 200, 4, boss.hp / boss.max, "#d0402e");
    }
    if (this.over) {
      panel(ctx, 60, 60, 200, 60);
      drawTitleText(ctx, "WRECKED", 160 - textWidth("WRECKED", 2) / 2, 66, 2, ["#ffe9a8", "#ff9a1e", "#d0402e"]);
      drawTextCentered(ctx, "YOUR SHIP IS SCRAP.", 160, 88, "#c8bcd0");
      drawTextCentered(ctx, "-50 COINS  TOWED TO NAV CHART", 160, 98, "#8a7a96");
      if (this.overT > 2.2) prompt(ctx, "PRESS FIRE TO CONTINUE", 110, true, this.t);
    }
  }
}

export { drawShip, getSave };
