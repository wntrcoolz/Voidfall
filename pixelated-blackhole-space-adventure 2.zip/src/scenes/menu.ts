import type { SceneCtx } from "../game/engine";
import { drawText, drawTextCentered } from "../game/font";
import { panel } from "./common";

export interface MenuItem {
  label: string;
  sub?: string;
  disabled?: boolean;
  color?: string;
}

export class CanvasMenu {
  sel = 0;
  items: MenuItem[] = [];
  scroll = 0;
  rows: number;
  constructor(items: MenuItem[], rows = 5) {
    this.items = items;
    this.rows = rows;
  }
  set(items: MenuItem[]) {
    this.items = items;
    if (this.sel >= items.length) this.sel = Math.max(0, items.length - 1);
  }
  /** returns index when confirmed, -1 when cancelled, null otherwise */
  update(c: SceneCtx, x = 0, y = 0, w = 320, rowH = 12): number | null {
    const i = c.input;
    if (i.just("up")) {
      this.sel = (this.sel - 1 + this.items.length) % this.items.length;
      c.sfx("move");
    }
    if (i.just("down")) {
      this.sel = (this.sel + 1) % this.items.length;
      c.sfx("move");
    }
    if (this.sel < this.scroll) this.scroll = this.sel;
    if (this.sel >= this.scroll + this.rows) this.scroll = this.sel - this.rows + 1;
    if (i.pointer.downNow) {
      const px = i.pointer.x,
        py = i.pointer.y;
      if (px >= x && px <= x + w) {
        const row = Math.floor((py - y) / rowH);
        const idx = this.scroll + row;
        if (row >= 0 && row < this.rows && idx < this.items.length) {
          if (idx === this.sel) {
            c.sfx("select");
            return idx;
          }
          this.sel = idx;
          c.sfx("move");
          return null;
        }
      }
    }
    if (i.just("fire") || i.just("action") || i.just("start")) {
      c.sfx("select");
      return this.sel;
    }
    if (i.just("pause") || i.just("alt")) {
      c.sfx("back");
      return -1;
    }
    return null;
  }
  draw(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, rowH = 12, t = 0) {
    for (let r = 0; r < Math.min(this.rows, this.items.length); r++) {
      const idx = this.scroll + r;
      const it = this.items[idx];
      if (!it) break;
      const yy = y + r * rowH;
      const on = idx === this.sel;
      if (on) {
        ctx.fillStyle = "rgba(216,176,106,0.18)";
        ctx.fillRect(x, yy - 1, w, rowH);
        ctx.fillStyle = "#d8b06a";
        ctx.fillRect(x, yy - 1, 2, rowH);
        if (Math.floor(t * 3) % 2 === 0) drawText(ctx, ">", x + 4, yy + 2, "#ffd23c");
      }
      const col = it.disabled ? "#5f5070" : on ? "#fff6d8" : it.color || "#c8bcd0";
      drawText(ctx, it.label, x + 12, yy + 2, col, 1, "#160f1c");
      if (it.sub) drawText(ctx, it.sub, x + w - it.sub.length * 6 - 4, yy + 2, it.disabled ? "#5f5070" : on ? "#ffd23c" : "#8a7a96", 1, "#160f1c");
    }
    if (this.items.length > this.rows) {
      const sh = Math.max(4, (this.rows / this.items.length) * (this.rows * rowH));
      const sy = y + (this.scroll / this.items.length) * (this.rows * rowH);
      ctx.fillStyle = "#3d2b46";
      ctx.fillRect(x + w - 2, y, 2, this.rows * rowH);
      ctx.fillStyle = "#d8b06a";
      ctx.fillRect(x + w - 2, sy, 2, sh);
    }
  }
}

export function dialog(ctx: CanvasRenderingContext2D, title: string, lines: string[], y = 44) {
  const h = 22 + lines.length * 10;
  panel(ctx, 30, y, 260, h);
  drawTextCentered(ctx, title, 160, y + 6, "#ffe9a8");
  lines.forEach((l, i) => drawTextCentered(ctx, l, 160, y + 20 + i * 10, "#c8bcd0"));
}
