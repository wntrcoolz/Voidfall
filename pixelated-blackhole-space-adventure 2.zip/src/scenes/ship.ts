import type { SceneCtx } from "../game/engine";
import { drawShip } from "../game/sprites";
import { shipStats, getSave } from "../game/save";
import { clamp, Particles } from "./common";

export interface Bullet {
  x: number;
  y: number;
  vx: number;
  vy: number;
  dmg: number;
  life: number;
  c: string;
  w: number;
  h: number;
  enemy?: boolean;
}

export class PlayerShip {
  x: number;
  y: number;
  vx = 0;
  vy = 0;
  hp: number;
  maxHp: number;
  shield: number;
  shieldMax: number;
  shieldTimer = 0;
  cool = 0;
  inv = 0;
  thrust = 0;
  stats = shipStats();
  bullets: Bullet[] = [];
  alive = true;
  dead = false;

  constructor(x: number, y: number) {
    this.x = x;
    this.y = y;
    this.maxHp = this.stats.maxHp;
    this.hp = this.maxHp;
    this.shieldMax = this.stats.shield;
    this.shield = this.shieldMax;
  }

  control(dt: number, c: SceneCtx, bounds: { x0: number; y0: number; x1: number; y1: number }, canShoot = true, vertical = true) {
    const inp = c.input;
    const sp = this.stats.speed;
    let ax = inp.ax;
    let ay = vertical ? inp.ay : 0;
    if (inp.pointer.active) {
      const dx = inp.pointer.x - this.x;
      const dy = inp.pointer.y - this.y;
      if (Math.abs(dx) > 2) ax = clamp(dx / 22, -1, 1);
      if (vertical && Math.abs(dy) > 2) ay = clamp(dy / 22, -1, 1);
    }
    this.vx += ax * sp * 9 * dt;
    this.vy += ay * sp * 9 * dt;
    this.vx *= Math.pow(0.0009, dt);
    this.vy *= Math.pow(0.0009, dt);
    this.vx = clamp(this.vx, -sp, sp);
    this.vy = clamp(this.vy, -sp, sp);
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    this.x = clamp(this.x, bounds.x0, bounds.x1);
    this.y = clamp(this.y, bounds.y0, bounds.y1);
    this.thrust = clamp(0.35 + Math.abs(this.vy) / sp + Math.abs(ax) * 0.25, 0, 1.3);

    this.cool -= dt;
    this.inv -= dt;
    if (this.shieldMax > 0 && this.shield < this.shieldMax) {
      this.shieldTimer -= dt;
      if (this.shieldTimer <= 0) {
        this.shield++;
        this.shieldTimer = 6;
        c.sfx("shield");
      }
    }
    const firing = canShoot && (inp.down.fire || (getSave().settings.autofire && inp.pointer.active));
    if (firing && this.cool <= 0) this.shoot(c);
  }

  shoot(c: SceneCtx) {
    this.cool = this.stats.fireDelay;
    const n = this.stats.barrels;
    const dmg = this.stats.dmg;
    for (let i = 0; i < n; i++) {
      const off = n === 1 ? 0 : (i - (n - 1) / 2) * 4;
      const spread = n === 1 ? 0 : (i - (n - 1) / 2) * 34;
      this.bullets.push({
        x: this.x + off,
        y: this.y - 8,
        vx: spread,
        vy: -260,
        dmg,
        life: 1.4,
        c: "#ffe9a8",
        w: 2,
        h: 5,
      });
    }
    c.sfx(n > 2 ? "laser2" : "laser");
  }

  updateBullets(dt: number, H = 180) {
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.x += b.vx * dt;
      b.y += b.vy * dt;
      b.life -= dt;
      if (b.life <= 0 || b.y < -10 || b.y > H + 10 || b.x < -10 || b.x > 330) this.bullets.splice(i, 1);
    }
  }

  drawBullets(ctx: CanvasRenderingContext2D) {
    for (const b of this.bullets) {
      ctx.fillStyle = b.c;
      ctx.fillRect(Math.round(b.x - b.w / 2), Math.round(b.y - b.h / 2), b.w, b.h);
      ctx.fillStyle = "#fffdf0";
      ctx.fillRect(Math.round(b.x - b.w / 2), Math.round(b.y - b.h / 2), b.w, 1);
    }
  }

  damage(n: number, c: SceneCtx, parts?: Particles) {
    if (this.inv > 0) return false;
    if (this.shield > 0) {
      this.shield--;
      this.shieldTimer = 7;
      this.inv = 0.8;
      c.sfx("shield");
      c.shake(4);
      return false;
    }
    this.hp -= n;
    this.inv = 0.7;
    c.sfx("hit");
    c.shake(6);
    parts?.burst(this.x, this.y, 8, ["#ffae3b", "#d0402e", "#e8dcc0"], 70, 0.5, 2);
    if (this.hp <= 0) {
      this.hp = 0;
      this.dead = true;
    }
    return true;
  }

  draw(ctx: CanvasRenderingContext2D, t: number, scale = 1) {
    if (this.inv > 0 && Math.floor(t * 20) % 2 === 0) return;
    const s = getSave();
    drawShip(ctx, s.ship, this.x, this.y, scale, s.paint, s.decal, this.thrust, s.trail, t);
    if (this.shield > 0) {
      ctx.fillStyle = `rgba(150,220,255,${0.35 + Math.sin(t * 6) * 0.12})`;
      const r = 15 * scale;
      for (let a = 0; a < Math.PI * 2; a += 0.22) {
        ctx.fillRect(Math.round(this.x + Math.cos(a) * r), Math.round(this.y + Math.sin(a) * r * 0.95), 2, 2);
      }
    }
  }
}
