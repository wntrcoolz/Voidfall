import type { Scene, SceneCtx } from "../game/engine";
import { drawText, drawTextCentered, drawTitleText, textWidth, wrapText } from "../game/font";
import {
  Starfield,
  drawBlackHole,
  drawPlanet,
  drawSprite,
  SPRITES,
  asteroidCanvas,
  drawShip,
  makeNebula,
  shade,
  drawHuman,
} from "../game/sprites";
import { mutate, getSave } from "../game/save";
import { PLANETS, SKINS, SUITS, HAIRS, VISORS } from "../game/data";
import { PlayerShip } from "./ship";
import { Particles, Floaters, panel, bar, hud, clamp, rnd, irnd, mix, vgrad, fmtTime, prompt, lerp } from "./common";

const ROCK_COLS = ["#8a7a6a", "#a4502e", "#6f6f60", "#9a8b7c"];

interface Rock {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  hp: number;
  v: number;
  c: string;
  spin: number;
}

function newRock(x: number, y: number, r: number, vx = 0, vy = 40): Rock {
  return { x, y, vx, vy, r, hp: r * 2.2, v: irnd(0, 7), c: ROCK_COLS[irnd(0, 3)], spin: rnd(-2, 2) };
}
function drawRock(ctx: CanvasRenderingContext2D, k: Rock) {
  const cv = asteroidCanvas(k.v, 0, k.c);
  const s = Math.max(2, Math.round(k.r * 2));
  ctx.drawImage(cv, Math.round(k.x - s / 2), Math.round(k.y - s / 2), s, s);
}

// ============================== LAUNCH ==============================
export class LaunchScene implements Scene {
  music = "flight" as string | null;
  ship!: PlayerShip;
  stars = new Starfield(70, 320, 180);
  parts = new Particles();
  floats = new Floaters();
  phase: "pad" | "count" | "ascend" = "pad";
  t = 0;
  count = 3.99;
  alt = 0;
  speed = 0;
  obstacles: { x: number; y: number; vx: number; kind: number; hp: number; w: number; h: number }[] = [];
  pickups: { x: number; y: number; kind: "coin" | "gem" }[] = [];
  spawn = 0;
  groundY = 152;

  init(c: SceneCtx) {
    this.ship = new PlayerShip(160, 120);
    c.sfx("blip");
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.parts.update(dt);
    this.floats.update(dt);
    if (this.phase === "pad") {
      if (c.input.just("fire") || c.input.just("start") || c.input.just("action")) {
        this.phase = "count";
        c.sfx("select");
      }
      if (c.input.just("pause")) {
        c.sfx("back");
        c.goto("menu");
      }
      return;
    }
    if (this.phase === "count") {
      const prev = Math.ceil(this.count);
      this.count -= dt;
      if (Math.ceil(this.count) !== prev) c.sfx("alarm");
      this.groundY += 0;
      for (let i = 0; i < 4; i++)
        this.parts.add(160 + rnd(-8, 8), 130 + rnd(0, 8), rnd(-40, 40), rnd(20, 70), rnd(0.3, 0.8), ["#e8dcc0", "#9a9a9a", "#ffae3b"][irnd(0, 2)], 2);
      if (this.count <= 0) {
        this.phase = "ascend";
        c.sfx("launch");
        c.shake(10);
        mutate((s) => {
          s.stats.runs++;
        });
      }
      return;
    }

    // ascend
    this.speed = Math.min(1, this.speed + dt * 0.25);
    this.alt += this.speed * 42 * dt;
    this.groundY += this.speed * 90 * dt;
    this.ship.control(dt, c, { x0: 20, y0: 40, x1: 300, y1: 160 }, true, true);
    this.ship.updateBullets(dt);
    this.stars.update(dt, 0, 60 * this.speed, 320, 180);
    for (let i = 0; i < 3; i++)
      this.parts.add(this.ship.x + rnd(-3, 3), this.ship.y + 14, rnd(-20, 20), rnd(60, 130), rnd(0.2, 0.5), ["#ffe9a0", "#ffae3b", "#e0562a"][irnd(0, 2)], 2);

    this.spawn -= dt;
    if (this.spawn <= 0) {
      this.spawn = rnd(0.5, 1.1) / (0.6 + this.speed);
      const kind = this.alt < 20 ? 0 : this.alt < 55 ? 1 : this.alt < 85 ? 2 : 3;
      this.obstacles.push({ x: rnd(24, 296), y: -14, vx: rnd(-25, 25), kind, hp: 6 + kind * 4, w: 12 + kind * 3, h: 8 + kind });
      if (Math.random() < 0.55) this.pickups.push({ x: rnd(24, 296), y: -10, kind: Math.random() < 0.08 ? "gem" : "coin" });
    }
    const fall = 70 + this.speed * 120;
    for (let i = this.obstacles.length - 1; i >= 0; i--) {
      const o = this.obstacles[i];
      o.y += fall * dt;
      o.x += o.vx * dt;
      if (o.x < 14 || o.x > 306) o.vx *= -1;
      if (o.y > 200) {
        this.obstacles.splice(i, 1);
        continue;
      }
      for (let j = this.ship.bullets.length - 1; j >= 0; j--) {
        const b = this.ship.bullets[j];
        if (Math.abs(b.x - o.x) < o.w / 2 + 2 && Math.abs(b.y - o.y) < o.h / 2 + 3) {
          o.hp -= b.dmg;
          this.ship.bullets.splice(j, 1);
          this.parts.burst(b.x, b.y, 4, ["#ffe9a8", "#ffae3b"], 50, 0.3, 1);
          if (o.hp <= 0) {
            this.parts.burst(o.x, o.y, 12, ["#e8dcc0", "#ffae3b", "#d0402e"], 80, 0.6, 2);
            c.sfx("explode");
            this.obstacles.splice(i, 1);
            mutate((s) => {
              s.coins += 12;
              s.stats.kills++;
            });
            this.floats.add(o.x, o.y, "+12", "#ffd23c");
          }
          break;
        }
      }
      if (Math.abs(this.ship.x - o.x) < o.w / 2 + 6 && Math.abs(this.ship.y - o.y) < o.h / 2 + 8) {
        if (this.ship.damage(9, c, this.parts)) this.floats.add(this.ship.x, this.ship.y - 14, "-9 HULL", "#ff7a6a");
        this.obstacles.splice(i, 1);
      }
    }
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const p = this.pickups[i];
      p.y += fall * 0.85 * dt;
      const d = Math.hypot(p.x - this.ship.x, p.y - this.ship.y);
      if (d < this.ship.stats.magnet) {
        p.x += ((this.ship.x - p.x) / d) * 90 * dt;
        p.y += ((this.ship.y - p.y) / d) * 90 * dt;
      }
      if (d < 9) {
        if (p.kind === "coin") {
          mutate((s) => (s.coins += 20));
          this.floats.add(p.x, p.y, "+20", "#ffd23c");
          c.sfx("coin");
        } else {
          mutate((s) => (s.gems += 1));
          this.floats.add(p.x, p.y, "+1 GEM", "#9fe4ff");
          c.sfx("gem");
        }
        this.pickups.splice(i, 1);
        continue;
      }
      if (p.y > 200) this.pickups.splice(i, 1);
    }
    if (this.ship.dead) {
      this.ship.hp = 1;
      this.ship.dead = false;
      this.ship.inv = 2;
      mutate((s) => s.stats.deaths++);
    }
    if (this.alt >= 120) {
      c.sfx("warp");
      c.flash(1, "#ffffff");
      c.goto("cruise", {});
    }
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    const a = clamp(this.alt / 110, 0, 1);
    vgrad(ctx, 0, 0, 320, 180, mix("#3f7fc4", "#05030d", a), mix("#a9d4ef", "#170d2a", a), 14);
    if (a > 0.25) {
      ctx.globalAlpha = clamp((a - 0.25) / 0.5, 0, 1);
      this.stars.draw(ctx);
      ctx.globalAlpha = 1;
    }
    // clouds
    if (a < 0.7) {
      ctx.globalAlpha = 1 - a / 0.7;
      for (let i = 0; i < 7; i++) {
        const cy = ((i * 37 + this.groundY * 0.5) % 260) - 40;
        const cx = (i * 71 + Math.sin(i) * 40) % 320;
        ctx.fillStyle = i % 2 ? "#eef4ff" : "#d6e2f2";
        for (let k = 0; k < 5; k++) ctx.fillRect(cx + k * 8 - 16, cy + (k % 2) * 4, 14, 6);
      }
      ctx.globalAlpha = 1;
    }
    // ground / launch site
    if (this.groundY < 200) {
      const gy = this.groundY;
      ctx.fillStyle = "#4a8a3c";
      ctx.fillRect(0, gy, 320, 200);
      ctx.fillStyle = "#2d5a26";
      ctx.fillRect(0, gy + 6, 320, 200);
      ctx.fillStyle = "#6f6f60";
      ctx.fillRect(120, gy - 4, 80, 8);
      ctx.fillStyle = "#565648";
      for (let i = 0; i < 6; i++) ctx.fillRect(124 + i * 12, gy + 2, 6, 6);
      // tower
      ctx.fillStyle = "#9aa3ad";
      ctx.fillRect(196, gy - 60, 5, 60);
      ctx.fillStyle = "#6a6a78";
      for (let i = 0; i < 6; i++) ctx.fillRect(196, gy - 56 + i * 10, 14, 2);
      // buildings
      ctx.fillStyle = "#3a3a46";
      ctx.fillRect(10, gy - 18, 16, 18);
      ctx.fillRect(34, gy - 12, 12, 12);
      ctx.fillRect(272, gy - 22, 20, 22);
      ctx.fillStyle = "#ffd23c";
      ctx.fillRect(14, gy - 14, 3, 3);
      ctx.fillRect(20, gy - 9, 3, 3);
      ctx.fillRect(278, gy - 17, 3, 3);
    }
    this.parts.draw(ctx);
    for (const o of this.obstacles) drawObstacle(ctx, o, this.t);
    for (const p of this.pickups) drawSprite(ctx, p.kind === "coin" ? SPRITES.coin : SPRITES.gem, p.x - 2, p.y - 2, 1, {});
    this.ship.drawBullets(ctx);
    if (this.phase === "pad" || this.phase === "count") {
      const s = getSave();
      drawShip(ctx, s.ship, 160, 120, 1, s.paint, s.decal, this.phase === "count" ? 0.4 : 0, s.trail, this.t);
    } else this.ship.draw(ctx, this.t);
    this.floats.draw(ctx);

    hud(ctx, c.save, this.ship.hp, this.ship.maxHp, `ALT ${Math.floor(this.alt)}KM`);
    if (this.phase === "pad") {
      panel(ctx, 54, 118, 212, 40);
      drawTextCentered(ctx, "MISSION 001: THE LONG FALL", 160, 124, "#ffe9a8");
      drawTextCentered(ctx, "TARGET: SAGITTARIUS A-JR", 160, 134, "#c8bcd0");
      prompt(ctx, "PRESS FIRE / TAP TO LAUNCH", 146, true, this.t);
    } else if (this.phase === "count") {
      const n = Math.ceil(this.count);
      drawTitleText(ctx, n > 0 ? String(n) : "GO", 160 - 15, 60, 5, ["#fff6d8", "#ffd23c", "#ff9a1e", "#e0562a"]);
    } else {
      bar(ctx, 100, 172, 120, 4, this.alt / 120, "#7fc2e8");
      drawText(ctx, "ORBIT", 74, 171, "#c8bcd0");
    }
  }
}

function drawObstacle(ctx: CanvasRenderingContext2D, o: { x: number; y: number; kind: number; w: number; h: number }, t: number) {
  const x = Math.round(o.x),
    y = Math.round(o.y);
  if (o.kind === 0) {
    ctx.fillStyle = "#2a2430";
    const f = Math.sin(t * 12) > 0 ? 1 : -1;
    ctx.fillRect(x - 6, y, 5, 2);
    ctx.fillRect(x + 1, y, 5, 2);
    ctx.fillRect(x - 8, y - 2 * f, 3, 2);
    ctx.fillRect(x + 5, y - 2 * f, 3, 2);
    ctx.fillRect(x - 1, y, 2, 3);
  } else if (o.kind === 1) {
    ctx.fillStyle = "#d8d8e0";
    ctx.fillRect(x - 8, y - 2, 16, 4);
    ctx.fillStyle = "#9aa3ad";
    ctx.fillRect(x - 3, y - 5, 6, 10);
    ctx.fillStyle = "#d0402e";
    ctx.fillRect(x + 6, y - 4, 2, 3);
  } else if (o.kind === 2) {
    ctx.fillStyle = "#c2c8cf";
    ctx.fillRect(x - 4, y - 4, 8, 8);
    ctx.fillStyle = "#3a6ea8";
    ctx.fillRect(x - 10, y - 2, 6, 4);
    ctx.fillRect(x + 4, y - 2, 6, 4);
    ctx.fillStyle = "#ffd23c";
    ctx.fillRect(x - 1, y - 1, 2, 2);
  } else {
    drawSprite(ctx, SPRITES.ufo, x - 6, y - 4, 1, {});
  }
}

// ============================== CRUISE (2 MIN WAIT) ==============================
const RADIO = [
  "GROUND: YOU SURE ABOUT THIS?",
  "PILOT: NOPE.",
  "GROUND: TELEMETRY LOOKS... FINE.",
  "AUTO-CHEF: LUNCH IS SERVED. IT IS PASTE.",
  "SHIP AI: I HAVE READ THE MANUAL. TWICE.",
  "GROUND: YOUR MOM SAYS HI.",
  "SHIP AI: GRAVITY WELL DETECTED. IT IS BIG.",
  "GROUND: SCIENTISTS ARE ARGUING AGAIN.",
  "PILOT: SPACE IS REALLY BORING ACTUALLY.",
  "SHIP AI: 1 HOUR OF FUEL. PLENTY.",
  "GROUND: DO NOT TOUCH THE BIG BLACK CIRCLE.",
  "PILOT: TOO LATE FOR THAT.",
  "SHIP AI: PLAYING HOLD MUSIC.",
  "GROUND: WE ARE VERY PROUD. AND CONFUSED.",
];

export class CruiseScene implements Scene {
  music = "void" as string | null;
  ship!: PlayerShip;
  stars = new Starfield(120, 320, 180);
  neb!: HTMLCanvasElement;
  parts = new Particles();
  floats = new Floaters();
  timer = 120;
  t = 0;
  rocks: Rock[] = [];
  spawn = 0;
  msg = "";
  msgT = 0;
  msgI = 0;
  skipHold = 0;

  init(c: SceneCtx) {
    this.ship = new PlayerShip(160, 130);
    this.neb = makeNebula(320, 180, ["#2a1b3d", "#3d2450", "#4a2a3a", "#1d1430"], 60);
    c.sfx("thrust");
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.timer -= dt;
    this.parts.update(dt);
    this.floats.update(dt);
    this.stars.update(dt, 0, 22, 320, 180);
    this.msgT -= dt;
    if (this.msgT <= 0) {
      this.msg = RADIO[this.msgI % RADIO.length];
      this.msgI++;
      this.msgT = 7;
      c.sfx("blip");
    }
    this.ship.control(dt, c, { x0: 16, y0: 60, x1: 304, y1: 168 }, true, true);
    this.ship.updateBullets(dt);
    this.spawn -= dt;
    if (this.spawn <= 0) {
      this.spawn = rnd(1.4, 2.6);
      this.rocks.push(newRock(rnd(20, 300), -12, rnd(4, 9), rnd(-14, 14), rnd(26, 52)));
    }
    for (let i = this.rocks.length - 1; i >= 0; i--) {
      const k = this.rocks[i];
      k.x += k.vx * dt;
      k.y += k.vy * dt;
      if (k.y > 196) {
        this.rocks.splice(i, 1);
        continue;
      }
      for (let j = this.ship.bullets.length - 1; j >= 0; j--) {
        const b = this.ship.bullets[j];
        if (Math.hypot(b.x - k.x, b.y - k.y) < k.r + 3) {
          k.hp -= b.dmg;
          this.ship.bullets.splice(j, 1);
          if (k.hp <= 0) {
            this.parts.burst(k.x, k.y, 10, [k.c, "#e8dcc0", "#ffae3b"], 60, 0.5, 2);
            c.sfx("explode");
            const g = Math.round(k.r * 3);
            mutate((s) => {
              s.coins += g;
              s.stats.rocks++;
            });
            this.floats.add(k.x, k.y, `+${g}`, "#ffd23c");
            this.rocks.splice(i, 1);
          } else c.sfx("hit");
          break;
        }
      }
      if (Math.hypot(this.ship.x - k.x, this.ship.y - k.y) < k.r + 7) {
        this.ship.damage(6, c, this.parts);
        this.rocks.splice(i, 1);
      }
    }
    if (this.ship.hp <= 0) this.ship.hp = 1;

    const skipping = c.input.down.action || c.input.down.alt;
    if (skipping) {
      this.skipHold += dt;
      if (this.skipHold > 0.45) {
        c.sfx("warp");
        c.flash(0.8, "#e8dcc0");
        c.goto("approach", {});
      }
    } else this.skipHold = Math.max(0, this.skipHold - dt * 2);
    if (this.timer <= 0) {
      c.sfx("alarm");
      c.goto("approach", {});
    }
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    ctx.fillStyle = "#07040f";
    ctx.fillRect(0, 0, 320, 180);
    ctx.globalAlpha = 0.5;
    ctx.drawImage(this.neb, 0, (this.t * 6) % 180);
    ctx.drawImage(this.neb, 0, ((this.t * 6) % 180) - 180);
    ctx.globalAlpha = 1;
    this.stars.draw(ctx);
    const grow = 1 - this.timer / 120;
    drawBlackHole(ctx, 160, 48, 6 + grow * 10, this.t, 2, 0.3, 0.7);
    for (const k of this.rocks) drawRock(ctx, k);
    this.parts.draw(ctx);
    this.ship.drawBullets(ctx);
    this.ship.draw(ctx, this.t);
    this.floats.draw(ctx);
    this.floats.draw(ctx);

    hud(ctx, c.save, this.ship.hp, this.ship.maxHp, "CRUISE");
    panel(ctx, 96, 16, 128, 30);
    drawTextCentered(ctx, "TIME TO INTERCEPT", 160, 20, "#c8bcd0");
    drawTitleText(ctx, fmtTime(Math.max(0, this.timer)), 160 - textWidth(fmtTime(Math.max(0, this.timer)), 2) / 2, 28, 2, ["#fff6d8", "#ffd23c", "#ff9a1e"]);
    panel(ctx, 8, 150, 304, 14, "rgba(10,6,18,0.8)", "#4a3a56");
    drawText(ctx, this.msg, 12, 154, "#9fe4ff");
    if (this.skipHold > 0) {
      panel(ctx, 100, 100, 120, 20);
      drawTextCentered(ctx, "SKIPPING...", 160, 104, "#ffe9a8");
      bar(ctx, 106, 113, 108, 3, this.skipHold / 0.45, "#ffd23c");
    } else {
      prompt(ctx, "HOLD [E] / SKIP BUTTON TO SKIP THE WAIT", 168, true, this.t);
    }
  }
}

// ============================== APPROACH ==============================
export class ApproachScene implements Scene {
  music = "void" as string | null;
  ship!: PlayerShip;
  stars = new Starfield(140, 320, 180);
  parts = new Particles();
  floats = new Floaters();
  t = 0;
  dur = 34;
  rocks: Rock[] = [];
  spawn = 0;
  warn = 0;

  init() {
    this.ship = new PlayerShip(160, 140);
  }

  get prog() {
    return clamp(this.t / this.dur, 0, 1);
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.parts.update(dt);
    this.floats.update(dt);
    this.stars.update(dt, 0, 40 + this.prog * 120, 320, 180);
    const pull = 12 + this.prog * 80;
    this.ship.control(dt, c, { x0: 12, y0: 26, x1: 308, y1: 172 }, true, true);
    // gravity drags the ship toward the hole
    const cx = 160,
      cy = 46;
    const dx = cx - this.ship.x,
      dy = cy - this.ship.y;
    const d = Math.max(1, Math.hypot(dx, dy));
    this.ship.x += (dx / d) * pull * dt;
    this.ship.y += (dy / d) * pull * dt;
    this.ship.updateBullets(dt);

    this.spawn -= dt;
    if (this.spawn <= 0) {
      this.spawn = rnd(0.35, 0.9) / (0.6 + this.prog);
      const side = Math.random() < 0.5 ? -14 : 334;
      this.rocks.push(newRock(side, rnd(40, 180), rnd(4, 11), side < 0 ? rnd(20, 60) : rnd(-60, -20), rnd(-30, 20)));
    }
    for (let i = this.rocks.length - 1; i >= 0; i--) {
      const k = this.rocks[i];
      const rdx = cx - k.x,
        rdy = cy - k.y;
      const rd = Math.max(1, Math.hypot(rdx, rdy));
      k.vx += ((rdx / rd) * 60 - (rdy / rd) * 40) * dt;
      k.vy += ((rdy / rd) * 60 + (rdx / rd) * 40) * dt;
      k.x += k.vx * dt;
      k.y += k.vy * dt;
      if (rd < 16 || k.y > 220 || k.x < -40 || k.x > 360) {
        this.rocks.splice(i, 1);
        continue;
      }
      for (let j = this.ship.bullets.length - 1; j >= 0; j--) {
        const b = this.ship.bullets[j];
        if (Math.hypot(b.x - k.x, b.y - k.y) < k.r + 3) {
          k.hp -= b.dmg;
          this.ship.bullets.splice(j, 1);
          if (k.hp <= 0) {
            this.parts.burst(k.x, k.y, 10, [k.c, "#ffae3b"], 70, 0.5, 2);
            c.sfx("explode");
            const g = Math.round(k.r * 4);
            mutate((s) => {
              s.coins += g;
              s.stats.rocks++;
            });
            this.floats.add(k.x, k.y, `+${g}`, "#ffd23c");
            this.rocks.splice(i, 1);
          }
          break;
        }
      }
      if (Math.hypot(this.ship.x - k.x, this.ship.y - k.y) < k.r + 7) {
        this.ship.damage(8, c, this.parts);
        this.rocks.splice(i, 1);
      }
    }
    if (this.ship.hp <= 0) {
      this.ship.hp = 1;
      this.ship.inv = 2;
    }
    this.warn -= dt;
    if (this.prog > 0.55 && this.warn <= 0) {
      this.warn = 1.6;
      c.sfx("alarm");
    }
    if (this.prog >= 1 || Math.hypot(this.ship.x - cx, this.ship.y - cy) < 30) {
      c.sfx("warp");
      c.flash(1, "#ffd9a0");
      c.goto("horizon", {});
    }
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    ctx.fillStyle = "#08040e";
    ctx.fillRect(0, 0, 320, 180);
    this.stars.draw(ctx);
    drawBlackHole(ctx, 160, 46, 16 + this.prog * 30, this.t, 2, 0.3, 1);
    for (const k of this.rocks) drawRock(ctx, k);
    this.parts.draw(ctx);
    this.ship.drawBullets(ctx);
    this.ship.draw(ctx, this.t);
    this.floats.draw(ctx);
    hud(ctx, c.save, this.ship.hp, this.ship.maxHp, `PULL ${Math.round(this.prog * 100)}%`);
    if (this.prog > 0.5 && Math.floor(this.t * 3) % 2 === 0) {
      panel(ctx, 86, 150, 148, 14, "rgba(60,10,10,0.8)", "#d0402e");
      drawTextCentered(ctx, "POINT OF NO RETURN", 160, 154, "#ff9a8a");
    } else {
      drawTextCentered(ctx, "GRAVITY WELL: CRITICAL", 160, 154, "#c8bcd0", 1, "#160f1c");
    }
    drawTextCentered(ctx, "ESCAPE VELOCITY REQUIRED: 299,999 KM/S", 160, 166, "#7a6a86");
  }
}

// ============================== EVENT HORIZON ==============================
const HORIZON_EVENTS: { t: number; msg: string; sfx?: string }[] = [
  { t: 0.2, msg: "EVENT HORIZON CROSSED", sfx: "horizon" },
  { t: 3, msg: "LIGHT CANNOT LEAVE. NEITHER CAN YOU." },
  { t: 6, msg: "TIME DILATION: 1 SEC = 4.2 YEARS", sfx: "alarm" },
  { t: 9, msg: "YOU SEE THE BACK OF YOUR OWN SHIP" },
  { t: 12, msg: "TIDAL FORCES DETECTED", sfx: "stretch" },
  { t: 15, msg: "SPAGHETTIFICATION IN PROGRESS" },
  { t: 18, msg: "EARTH IS NOW 11,402 YEARS OLDER" },
  { t: 21, msg: "YOUR RADIO STILL PLAYS. NOBODY HEARS IT." },
  { t: 24, msg: "SINGULARITY IN RANGE", sfx: "alarm" },
];

export class HorizonScene implements Scene {
  music = null as string | null;
  t = 0;
  msg = "";
  msgTime = 0;
  ei = 0;
  stretch = 0;
  resist = 100;
  mash = 0;
  parts = new Particles();
  shipY = 120;
  ghost: { x: number; y: number }[] = [];
  counted = false;

  init(c: SceneCtx) {
    c.sfx("horizon");
    mutate((s) => {
      s.holes++;
    });
    this.counted = true;
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.parts.update(dt);
    const ev = HORIZON_EVENTS[this.ei];
    if (ev && this.t >= ev.t) {
      this.msg = ev.msg;
      this.msgTime = 3;
      if (ev.sfx) c.sfx(ev.sfx);
      this.ei++;
      c.shake(5);
    }
    this.msgTime -= dt;
    if (this.t > 12) this.stretch = Math.min(6, this.stretch + dt * 0.35);
    this.shipY = 120 - Math.min(40, this.t * 1.6);
    if (c.input.just("fire")) {
      this.mash += 1;
      c.sfx("blip");
    }
    this.resist = Math.max(0, 100 - this.t * 4 + this.mash * 0.35);
    if (Math.random() < dt * 22)
      this.parts.add(rnd(0, 320), rnd(0, 180), rnd(-40, 40), rnd(-160, -40), rnd(0.3, 1), ["#ffe9a8", "#ff9a1e", "#d0402e", "#a35cb0"][irnd(0, 3)], 2);
    if (this.t > 27) {
      c.sfx("singularity");
      c.flash(1.4, "#ffffff");
      c.goto("inside", { resist: Math.round(this.resist) });
    }
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    const warp = clamp((this.t - 2) / 22, 0, 1);
    ctx.fillStyle = "#050208";
    ctx.fillRect(0, 0, 320, 180);
    // rushing rings of light
    for (let i = 0; i < 14; i++) {
      const p = ((this.t * 0.55 + i / 14) % 1);
      const r = p * 240;
      const col = ["#fff6d8", "#ffd23c", "#ff9a1e", "#d4561f", "#8a2f4a", "#3a1230"][Math.floor(p * 6)];
      ctx.fillStyle = col;
      for (let a = 0; a < Math.PI * 2; a += 0.06 / (0.4 + p)) {
        const x = 160 + Math.cos(a) * r;
        const y = 70 + Math.sin(a) * r * 0.62;
        if (x < -4 || x > 324 || y < -4 || y > 184) continue;
        ctx.fillRect((x | 0) - ((x | 0) % 2), (y | 0) - ((y | 0) % 2), 2, 2);
      }
    }
    // the dark core swallowing the screen
    const coreR = 26 + warp * 70;
    ctx.fillStyle = "#000000";
    for (let y = 0; y < 180; y += 2)
      for (let x = 0; x < 320; x += 2) {
        const d = Math.hypot(x - 160, (y - 70) / 0.9);
        if (d < coreR) ctx.fillRect(x, y, 2, 2);
      }
    ctx.fillStyle = "#ffeeba";
    for (let a = 0; a < Math.PI * 2; a += 0.03) {
      const x = 160 + Math.cos(a) * coreR;
      const y = 70 + Math.sin(a) * coreR * 0.9;
      ctx.fillRect((x | 0) - ((x | 0) % 2), (y | 0) - ((y | 0) % 2), 2, 2);
    }
    this.parts.draw(ctx);
    // ghost copy of your own ship (light wrapping around)
    if (this.t > 9) {
      ctx.globalAlpha = 0.45;
      const s = getSave();
      drawShip(ctx, s.ship, 160 + Math.sin(this.t) * 30, 40, 1, s.paint, s.decal, 0.4, s.trail, this.t);
      ctx.globalAlpha = 1;
    }
    // the player ship, stretched by tidal forces
    const s = getSave();
    ctx.save();
    ctx.translate(160, this.shipY);
    ctx.scale(Math.max(0.2, 1 - this.stretch * 0.12), 1 + this.stretch);
    drawShip(ctx, s.ship, 0, 0, 1, s.paint, s.decal, 1, s.trail, this.t);
    ctx.restore();

    if (this.msgTime > 0) {
      const lines = wrapText(this.msg, 34);
      panel(ctx, 30, 140, 260, 12 + lines.length * 9, "rgba(8,4,14,0.88)", "#d8b06a");
      lines.forEach((l, i) => drawTextCentered(ctx, l, 160, 146 + i * 9, "#ffe9a8"));
    }
    drawText(ctx, `RESISTANCE ${Math.round(this.resist)}%`, 6, 6, "#c8bcd0", 1, "#160f1c");
    bar(ctx, 6, 16, 80, 4, this.resist / 100, this.resist > 30 ? "#6fc04a" : "#d0402e");
    drawText(ctx, `BLACK HOLES ENTERED ${c.save.holes}`, 184, 6, "#9fe4ff", 1, "#160f1c");
    if (Math.floor(this.t * 2) % 2 === 0) drawTextCentered(ctx, "MASH FIRE TO RESIST (IT WONT WORK)", 160, 172, "#7a6a86");
  }
}

// ============================== INSIDE THE BLACK HOLE ==============================
const WHISPERS = [
  "WHERE ARE YOU",
  "THE MATH SAID NO",
  "DOWN IS A DIRECTION IN TIME",
  "HELLO AGAIN",
  "YOU ARE 400 YEARS OLD",
  "EVERY MOMENT AT ONCE",
  "THE DOOR WAS ALWAYS OPEN",
  "SPACE IS THE NEW FUTURE",
];
const DOORS = [
  { id: "deeper", name: "GO DEEPER", col: "#a35cb0" },
  { id: "earth", name: "REMEMBER EARTH", col: "#4a8a3c" },
  { id: "other", name: "THE OTHER SIDE", col: "#ffd23c" },
];

export class InsideScene implements Scene {
  music = null as string | null;
  t = 0;
  parts = new Particles();
  sel = 1;
  chosen = false;
  whisper = "";
  wt = 0;
  shards: { x: number; y: number; vx: number; vy: number; r: number }[] = [];

  init(c: SceneCtx) {
    c.sfx("warp");
    for (let i = 0; i < 26; i++)
      this.shards.push({ x: rnd(0, 320), y: rnd(0, 180), vx: rnd(-20, 20), vy: rnd(-20, 20), r: rnd(1, 4) });
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.parts.update(dt);
    this.wt -= dt;
    if (this.wt <= 0) {
      this.whisper = WHISPERS[irnd(0, WHISPERS.length - 1)];
      this.wt = 2.6;
    }
    for (const s of this.shards) {
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      if (s.x < -6) s.x = 326;
      if (s.x > 326) s.x = -6;
      if (s.y < -6) s.y = 186;
      if (s.y > 186) s.y = -6;
    }
    if (Math.random() < dt * 12) this.parts.add(rnd(0, 320), 190, rnd(-10, 10), rnd(-60, -20), rnd(1, 2), ["#c7a8ff", "#ffe9a8", "#7fd0e8"][irnd(0, 2)], 2);
    if (this.t > 11 && !this.chosen) {
      if (c.input.just("left")) {
        this.sel = (this.sel + 2) % 3;
        c.sfx("move");
      }
      if (c.input.just("right")) {
        this.sel = (this.sel + 1) % 3;
        c.sfx("move");
      }
      if (c.input.pointer.downNow) {
        const i = Math.floor(c.input.pointer.x / 107);
        this.sel = clamp(i, 0, 2);
        c.sfx("move");
      }
      if (c.input.just("fire") || c.input.just("action") || c.input.just("start")) {
        this.chosen = true;
        c.sfx("buy");
        c.flash(1.2, DOORS[this.sel].col);
        const gems = this.sel === 0 ? 8 : this.sel === 2 ? 5 : 3;
        const coins = 800 + (c.payload?.resist ?? 0) * 12;
        mutate((s) => {
          s.gems += gems;
          s.coins += coins;
        });
        setTimeout(() => c.goto("theend", { ending: DOORS[this.sel].id, gems, coins }), 700);
      }
    }
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    ctx.fillStyle = "#08030f";
    ctx.fillRect(0, 0, 320, 180);
    // impossible geometry tunnel
    for (let i = 10; i >= 0; i--) {
      const p = ((this.t * 0.35 + i / 11) % 1);
      const sz = p * 320;
      const rot = this.t * 0.3 + i;
      const col = ["#1b0f28", "#2c1740", "#432159", "#5b2a63", "#7d3a74", "#a35cb0"][Math.floor(p * 6)];
      ctx.strokeStyle = col;
      ctx.lineWidth = 2;
      ctx.save();
      ctx.translate(160, 84);
      ctx.rotate(rot);
      ctx.beginPath();
      ctx.rect(-sz / 2, (-sz / 2) * 0.6, sz, sz * 0.6);
      ctx.stroke();
      ctx.restore();
    }
    for (const s of this.shards) {
      ctx.fillStyle = "#e0d0ff";
      ctx.fillRect(s.x | 0, s.y | 0, s.r * 2, s.r * 2);
      ctx.fillStyle = "#3b2260";
      ctx.fillRect((s.x | 0) + 1, (s.y | 0) + 1, s.r, s.r);
    }
    this.parts.draw(ctx);
    // floating memories
    const mem = Math.floor(this.t / 3) % 3;
    ctx.globalAlpha = 0.8;
    if (mem === 0) drawPlanet(ctx, 62, 50 + Math.sin(this.t) * 6, 14, PLANETS[2], this.t, 2);
    if (mem === 1) {
      const s = getSave();
      drawShip(ctx, s.ship, 258, 60 + Math.sin(this.t * 1.3) * 6, 1, s.paint, s.decal, 0, s.trail, this.t);
    }
    if (mem === 2) {
      const sv = getSave().char;
      drawHuman(ctx, 250, 46 + Math.sin(this.t) * 5, 2, { skin: SKINS[sv.skin], suit: SUITS[sv.suit], hair: HAIRS[sv.hair], visor: VISORS[sv.visor] }, 0);
    }
    ctx.globalAlpha = 1;

    if (this.whisper && Math.floor(this.t * 4) % 5 !== 0)
      drawTextCentered(ctx, this.whisper, 160, 24 + Math.sin(this.t * 2) * 3, "#c7a8ff", 1, "#150a1c");

    if (this.t <= 11) {
      panel(ctx, 40, 148, 240, 22);
      drawTextCentered(ctx, "YOU ARE INSIDE.", 160, 152, "#ffe9a8");
      drawTextCentered(ctx, "NOTHING HURTS. THAT IS THE WORRYING PART.", 160, 161, "#9fe4ff");
    } else {
      drawTextCentered(ctx, "CHOOSE YOUR FATE", 160, 118, "#e8dcc0", 1, "#160f1c");
      for (let i = 0; i < 3; i++) {
        const x = 12 + i * 102;
        const on = i === this.sel;
        panel(ctx, x, 130, 96, 36, on ? "rgba(40,20,60,0.95)" : "rgba(12,6,20,0.8)", on ? DOORS[i].col : "#4a3a56");
        drawTextCentered(ctx, DOORS[i].name, x + 48, 140, on ? "#fff6d8" : "#8a7a96");
        drawTextCentered(ctx, ["+8 GEMS", "+3 GEMS", "+5 GEMS"][i], x + 48, 152, on ? DOORS[i].col : "#5f5070");
        if (on && Math.floor(this.t * 3) % 2 === 0) drawTextCentered(ctx, ">", x + 6, 146, "#ffd23c");
      }
    }
    drawText(ctx, `HOLES ENTERED: ${c.save.holes}`, 6, 170, "#5f5070");
  }
}

// ============================== THE END ==============================
const ENDINGS: Record<string, string[]> = {
  deeper: [
    "YOU FELL PAST THE PLACE WHERE FALLING ENDS.",
    "THE SINGULARITY MADE ROOM FOR YOU.",
    "SOMEWHERE, A NEW STAR SWITCHED ON.",
  ],
  earth: [
    "YOU THOUGHT OF A BLUE DOT AND A SMALL KITCHEN.",
    "THE HOLE GAVE IT BACK TO YOU. SORT OF.",
    "YOU WAKE UP IN ORBIT, CRYING, RICHER.",
  ],
  other: [
    "THE OTHER SIDE WAS NOT A PLACE. IT WAS A TIME.",
    "A WHITE HOLE SPAT YOU OUT INTO A YOUNG UNIVERSE.",
    "YOU ARE THE OLDEST THING HERE NOW.",
  ],
};

export class TheEndScene implements Scene {
  music = null as string | null;
  t = 0;
  typed = 0;
  lines: string[] = [];
  parts = new Particles();
  played = false;

  init(c: SceneCtx) {
    this.lines = ENDINGS[c.payload?.ending] || ENDINGS.other;
    c.sfx("theend");
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.typed += dt * 26;
    this.parts.update(dt);
    if (Math.random() < dt * 6) this.parts.add(rnd(0, 320), 186, rnd(-8, 8), rnd(-30, -10), rnd(2, 4), ["#ffe9a8", "#a35cb0", "#7fd0e8"][irnd(0, 2)], 2);
    if (this.t > 4.5 && !this.played) {
      this.played = true;
    }
    if (this.t > 3 && (c.input.just("fire") || c.input.just("start") || c.input.just("action") || c.input.pointer.downNow)) {
      c.sfx("select");
      c.goto("menu");
    }
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    ctx.fillStyle = "#04020a";
    ctx.fillRect(0, 0, 320, 180);
    this.parts.draw(ctx);
    const pulse = 3 + Math.floor(Math.sin(this.t * 2) * 0 + 0);
    drawTitleText(ctx, "THE END", 160 - textWidth("THE END", pulse) / 2, 30, pulse, ["#fff6d8", "#ffe9a8", "#ffc457", "#f2892a", "#d4561f", "#a12f1d", "#6b1c2c"]);
    const full = this.lines.join(" | ");
    let shown = Math.floor(this.typed);
    let yy = 74;
    let used = 0;
    for (const l of this.lines) {
      const part = l.slice(0, clamp(shown - used, 0, l.length));
      drawTextCentered(ctx, part, 160, yy, "#c8bcd0");
      used += l.length;
      yy += 11;
    }
    void full;
    if (this.t > 2.5) {
      panel(ctx, 66, 116, 188, 40);
      drawTextCentered(ctx, "RUN REWARDS", 160, 120, "#ffe9a8");
      drawTextCentered(ctx, `+${c.payload?.coins ?? 0} COINS   +${c.payload?.gems ?? 0} GEMS`, 160, 132, "#ffd23c");
      drawTextCentered(ctx, `BLACK HOLES ENTERED: ${c.save.holes}`, 160, 144, "#9fe4ff");
    }
    if (this.t > 3) prompt(ctx, "PRESS FIRE / TAP TO RETURN", 168, true, this.t);
  }
}

export { lerp, shade, drawSprite, SPRITES };
