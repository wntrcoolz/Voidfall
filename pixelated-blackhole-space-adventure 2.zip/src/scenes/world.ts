import type { Scene, SceneCtx } from "../game/engine";
import { drawText, drawTextCentered, textWidth } from "../game/font";
import { drawHuman, drawSprite, SPRITES, shade, drawShip, Starfield, drawPlanet } from "../game/sprites";
import { PLANETS, SKINS, SUITS, HAIRS, VISORS, HOME_STYLES, FURNITURE, type PlanetDef } from "../game/data";
import { getSave, mutate, planetSave } from "../game/save";
import { Particles, Floaters, panel, bar, clamp, rnd, irnd, mix, vgrad, prompt } from "./common";
import { CanvasMenu } from "./menu";

const WORLD_W = 1400;
const BASE_Y = 142;

export const WALLS = ["#5c4f6a", "#7a5a4a", "#3f5a6a", "#6a6a5a", "#4a3f66", "#8a7a5c", "#2f3a4a"];
export const FLOORS = ["#3a2f44", "#4a3a2a", "#2a3a44", "#42422f", "#2a2438", "#5a4a36", "#1f2630"];

function terrain(x: number) {
  return BASE_Y - (Math.sin(x * 0.008) * 7 + Math.sin(x * 0.021 + 1.3) * 4 + Math.sin(x * 0.005) * 5);
}

function charCfg() {
  const ch = getSave().char;
  return { skin: SKINS[ch.skin], suit: SUITS[ch.suit], hair: HAIRS[ch.hair], visor: VISORS[ch.visor] };
}

interface Alien {
  x: number;
  y: number;
  vy: number;
  hp: number;
  max: number;
  dir: number;
  t: number;
  cool: number;
  fly: boolean;
  hit: number;
}
interface Prop {
  x: number;
  kind: number;
  hp: number;
  dead: boolean;
}
interface Shot {
  x: number;
  y: number;
  vx: number;
  vy: number;
  dmg: number;
  life: number;
  enemy: boolean;
}

// ============================== PLANET SURFACE ==============================
export class PlanetScene implements Scene {
  music = "planet" as string | null;
  def!: PlanetDef;
  t = 0;
  px = 220;
  py = 0;
  vy = 0;
  vx = 0;
  onGround = true;
  face = 1;
  frame = 0;
  walkT = 0;
  hp = 100;
  maxHp = 100;
  cool = 0;
  inv = 0;
  cam = 0;
  parts = new Particles();
  floats = new Floaters();
  aliens: Alien[] = [];
  shots: Shot[] = [];
  props: Prop[] = [];
  spawn = 2;
  stars = new Starfield(60, 320, 120);
  mode: "play" | "build" | "ship" = "play";
  menu = new CanvasMenu([], 5);
  hint = "";
  hazT = 6;
  shipX = 120;
  padX = 700;
  peaceful = false;

  init(c: SceneCtx) {
    this.def = PLANETS.find((p) => p.id === (c.payload?.target || "earth"))!;
    this.py = terrain(this.px) - 14;
    const ps = planetSave(this.def.id);
    if (!ps.visited) {
      mutate((s) => {
        planetSave(this.def.id).visited = true;
        s.coins += this.def.reward;
      });
      this.floats.add(160, 60, `FIRST LANDING +${this.def.reward}`, "#ffd23c");
      c.sfx("levelup");
    }
    for (let i = 0; i < 26; i++) {
      const x = 260 + i * 44 + rnd(-12, 12);
      if (Math.abs(x - this.padX) < 60 || Math.abs(x - this.shipX) < 50) continue;
      this.props.push({ x, kind: irnd(0, 2), hp: 14, dead: false });
    }
    c.sfx("land");
  }

  groundAt(x: number) {
    return terrain(x);
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.parts.update(dt);
    this.floats.update(dt);
    if (this.mode !== "play") {
      this.updateMenu(c);
      return;
    }
    const i = c.input;
    const ps = planetSave(this.def.id);
    const grav = 240 * clamp(this.def.gravity, 0.15, 2.2);
    let ax = i.ax;
    if (i.pointer.active && !i.down.left && !i.down.right) {
      const worldPx = i.pointer.x + this.cam;
      if (Math.abs(worldPx - this.px) > 6) ax = clamp((worldPx - this.px) / 30, -1, 1);
    }
    const speed = 68;
    this.vx = ax * speed;
    this.px = clamp(this.px + this.vx * dt, 20, WORLD_W - 20);
    if (ax !== 0) {
      this.face = ax > 0 ? 1 : -1;
      this.walkT += dt * Math.abs(ax) * 9;
      if (Math.floor(this.walkT) % 2 === 1 && this.onGround && Math.random() < dt * 8) c.sfx("step");
      this.frame = Math.floor(this.walkT) % 4;
    } else this.frame = 0;

    const gy = this.groundAt(this.px) - 14;
    if (this.onGround) {
      this.py = gy;
      if (i.just("up")) {
        this.vy = -128 * clamp(1.2 - this.def.gravity * 0.22, 0.6, 1.4);
        this.onGround = false;
        c.sfx("jump");
      }
    } else {
      this.vy += grav * dt;
      this.py += this.vy * dt;
      if (this.py >= gy) {
        this.py = gy;
        this.vy = 0;
        this.onGround = true;
        this.parts.burst(this.px + 4, this.py + 14, 4, ["#c8bcd0", this.def.ground], 30, 0.3, 1);
      }
    }
    this.cam = clamp(this.px - 160, 0, WORLD_W - 320);

    // shooting
    this.cool -= dt;
    this.inv -= dt;
    if (i.down.fire && this.cool <= 0) {
      this.cool = 0.22;
      this.shots.push({ x: this.px + 4 + this.face * 6, y: this.py + 7, vx: this.face * 230, vy: 0, dmg: 14, life: 1.4, enemy: false });
      c.sfx("laser");
      this.parts.add(this.px + 4 + this.face * 8, this.py + 7, this.face * 30, 0, 0.16, "#ffe9a8", 1);
    }

    // interactions
    this.hint = "";
    if (Math.abs(this.px - this.shipX) < 22) {
      this.hint = "PRESS [E] : BOARD SHIP";
      if (i.just("action")) {
        this.openShipMenu(c);
        return;
      }
    } else if (!ps.home.built && Math.abs(this.px - this.padX) < 26) {
      this.hint = "PRESS [E] : BUILD A HOME HERE";
      if (i.just("action")) {
        this.openBuild(c);
        return;
      }
    } else if (ps.home.built && Math.abs(this.px - (this.padX + 4)) < 22) {
      this.hint = `PRESS [E] : ENTER ${ps.home.name}`;
      if (i.just("action")) {
        c.sfx("select");
        c.goto("home", { target: this.def.id });
        return;
      }
    }
    if (i.just("pause")) {
      c.sfx("back");
      c.goto("map");
      return;
    }

    // props
    for (const p of this.props) {
      if (p.dead) continue;
      for (let k = this.shots.length - 1; k >= 0; k--) {
        const s = this.shots[k];
        if (s.enemy) continue;
        if (Math.abs(s.x - p.x) < 8 && Math.abs(s.y - (this.groundAt(p.x) - 6)) < 10) {
          p.hp -= s.dmg;
          this.shots.splice(k, 1);
          this.parts.burst(p.x, this.groundAt(p.x) - 6, 5, [this.def.rock, "#e8dcc0"], 50, 0.35, 1);
          if (p.hp <= 0) {
            p.dead = true;
            c.sfx("wreck");
            c.shake(3);
            this.parts.burst(p.x, this.groundAt(p.x) - 6, 14, [this.def.rock, this.def.ground2, "#e8dcc0"], 70, 0.6, 2);
            const g = irnd(8, 24);
            mutate((s2) => {
              s2.coins += g;
              planetSave(this.def.id).wrecked++;
            });
            this.floats.add(p.x - this.cam, this.groundAt(p.x) - 20, `+${g}`, "#ffd23c");
          }
        }
      }
    }

    // aliens
    this.spawn -= dt;
    const cap = 3 + c.save.settings.difficulty * 2;
    if (this.spawn <= 0 && this.aliens.length < cap && !this.peaceful) {
      this.spawn = rnd(2.4, 5) / (0.8 + c.save.settings.difficulty * 0.3);
      const side = Math.random() < 0.5 ? -1 : 1;
      const x = clamp(this.px + side * rnd(180, 300), 20, WORLD_W - 20);
      const fly = this.def.alien === "floater" || this.def.alien === "drone" || this.def.alien === "flare";
      const hpv = 22 + this.def.dist * 5;
      this.aliens.push({ x, y: fly ? this.groundAt(x) - 44 : this.groundAt(x) - 10, vy: 0, hp: hpv, max: hpv, dir: 1, t: rnd(0, 6), cool: rnd(1, 3), fly, hit: 0 });
    }
    for (let a = this.aliens.length - 1; a >= 0; a--) {
      const al = this.aliens[a];
      al.t += dt;
      al.hit = Math.max(0, al.hit - dt);
      const dx = this.px - al.x;
      al.dir = dx > 0 ? 1 : -1;
      al.x += al.dir * (al.fly ? 34 : 26) * dt;
      if (al.fly) al.y = this.groundAt(al.x) - 40 + Math.sin(al.t * 2.2) * 8;
      else al.y = this.groundAt(al.x) - 10;
      if (al.fly) {
        al.cool -= dt;
        if (al.cool <= 0 && Math.abs(dx) < 140) {
          al.cool = rnd(1.4, 2.6);
          const dy = this.py + 6 - al.y;
          const d = Math.max(1, Math.hypot(dx, dy));
          this.shots.push({ x: al.x, y: al.y + 4, vx: (dx / d) * 110, vy: (dy / d) * 110, dmg: 9, life: 3, enemy: true });
          c.sfx("ufo");
        }
      }
      for (let k = this.shots.length - 1; k >= 0; k--) {
        const s = this.shots[k];
        if (s.enemy) continue;
        if (Math.abs(s.x - al.x) < 8 && Math.abs(s.y - (al.y + 4)) < 9) {
          al.hp -= s.dmg;
          al.hit = 0.12;
          this.shots.splice(k, 1);
          c.sfx("alienhurt");
          this.parts.burst(al.x, al.y + 4, 4, ["#8fd13f", "#e8ff9f"], 50, 0.3, 1);
          if (al.hp <= 0) {
            this.aliens.splice(a, 1);
            c.sfx("explode");
            this.parts.burst(al.x, al.y + 4, 14, ["#8fd13f", "#3c6b1e", "#e8dcc0"], 80, 0.6, 2);
            const g = 18 + this.def.dist * 4;
            mutate((s2) => {
              s2.coins += g;
              s2.stats.kills++;
              planetSave(this.def.id).kills++;
            });
            this.floats.add(al.x - this.cam, al.y - 8, `+${g}`, "#ffd23c");
            if (Math.random() < 0.12) {
              mutate((s2) => (s2.gems += 1));
              this.floats.add(al.x - this.cam, al.y - 20, "+1 GEM", "#9fe4ff");
              c.sfx("gem");
            }
          }
          break;
        }
      }
      if (Math.abs(al.x - (this.px + 4)) < 10 && Math.abs(al.y - this.py) < 16 && this.inv <= 0) this.hurt(12, c);
    }
    // shots
    for (let k = this.shots.length - 1; k >= 0; k--) {
      const s = this.shots[k];
      s.x += s.vx * dt;
      s.y += s.vy * dt;
      s.life -= dt;
      if (s.life <= 0 || s.y > this.groundAt(s.x)) {
        this.shots.splice(k, 1);
        continue;
      }
      if (s.enemy && Math.abs(s.x - (this.px + 4)) < 7 && Math.abs(s.y - (this.py + 7)) < 9) {
        this.hurt(s.dmg, c);
        this.shots.splice(k, 1);
      }
    }
    // hazard weather
    this.hazT -= dt;
    if (this.hazT <= 0) {
      this.hazT = rnd(14, 26);
      this.floats.add(160, 40, this.def.hazard, "#ff9a8a");
      c.sfx("alarm");
      if (!planetSave(this.def.id).home.built) this.hurt(6, c);
    }
    if (this.hp <= 0) {
      this.hp = this.maxHp;
      mutate((s) => {
        s.stats.deaths++;
        s.coins = Math.max(0, s.coins - 30);
      });
      this.floats.add(160, 60, "YOU BLACKED OUT. -30 COINS", "#ff7a6a");
      this.px = this.shipX;
      this.aliens = [];
      c.flash(0.9, "#d0402e");
    }
  }

  hurt(n: number, c: SceneCtx) {
    if (this.inv > 0) return;
    this.hp -= n;
    this.inv = 0.8;
    c.sfx("hurt");
    c.shake(5);
    this.parts.burst(this.px + 4, this.py + 7, 6, ["#d0402e", "#ffae3b"], 60, 0.4, 1);
  }

  openShipMenu(c: SceneCtx) {
    this.mode = "ship";
    c.sfx("select");
    this.menu = new CanvasMenu(
      [
        { label: "TAKE OFF -> NAV CHART" },
        { label: "FLY INTO THE BLACK HOLE", color: "#ffd23c" },
        { label: "REPAIR SUIT (60 COINS)", sub: `${c.save.coins}` },
        { label: "BACK" },
      ],
      4,
    );
  }
  openBuild(c: SceneCtx) {
    this.mode = "build";
    c.sfx("select");
    this.menu = new CanvasMenu(
      HOME_STYLES.map((h) => ({
        label: h.name,
        sub: h.id === "citadel" ? `${h.cost} GEM` : `${h.cost}C`,
        disabled: h.id === "citadel" ? c.save.gems < h.cost : c.save.coins < h.cost,
      })).concat([{ label: "CANCEL", sub: "", disabled: false }]),
      6,
    );
  }

  updateMenu(c: SceneCtx) {
    const r = this.menu.update(c, 40, 54, 240, 13);
    if (r === null) return;
    if (this.mode === "ship") {
      if (r === 0 || r === -1) {
        if (r === 0) {
          c.sfx("launch");
          c.goto("map");
          return;
        }
        this.mode = "play";
        return;
      }
      if (r === 1) {
        c.sfx("launch");
        c.goto("launch", {});
        return;
      }
      if (r === 2) {
        if (c.save.coins >= 60) {
          mutate((s) => (s.coins -= 60));
          this.hp = this.maxHp;
          c.sfx("buy");
          this.floats.add(160, 70, "SUIT REPAIRED", "#6fc04a");
        } else c.sfx("deny");
        this.mode = "play";
        return;
      }
      this.mode = "play";
      c.sfx("back");
      return;
    }
    if (this.mode === "build") {
      if (r === -1 || r >= HOME_STYLES.length) {
        this.mode = "play";
        c.sfx("back");
        return;
      }
      const st = HOME_STYLES[r];
      const gem = st.id === "citadel";
      const afford = gem ? c.save.gems >= st.cost : c.save.coins >= st.cost;
      if (!afford) {
        c.sfx("deny");
        return;
      }
      mutate((s) => {
        if (gem) s.gems -= st.cost;
        else s.coins -= st.cost;
        const ps = planetSave(this.def.id);
        ps.home.built = true;
        ps.home.style = st.id;
        ps.home.level = 1;
        ps.home.name = `${this.def.name} BASE`;
        s.stats.built++;
      });
      c.sfx("build");
      c.flash(0.5, "#ffe9a8");
      this.floats.add(160, 70, "HOME BUILT!", "#6fc04a");
      this.mode = "play";
    }
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    const d = this.def;
    vgrad(ctx, 0, 0, 320, 180, d.sky[0], d.sky[1], 12);
    ctx.globalAlpha = 0.7;
    this.stars.draw(ctx);
    ctx.globalAlpha = 1;
    // distant sibling planet + sun
    drawPlanet(ctx, 250 - this.cam * 0.04, 34, 12, d, this.t * 0.2, 2);
    ctx.fillStyle = "#fff6d8";
    ctx.fillRect(40 - this.cam * 0.02, 20, 6, 6);
    // far mountains
    for (let layer = 0; layer < 2; layer++) {
      const par = 0.25 + layer * 0.25;
      const col = layer === 0 ? shade(d.ground2, -0.35) : shade(d.ground2, -0.15);
      ctx.fillStyle = col;
      for (let x = 0; x < 324; x += 4) {
        const wx = x + this.cam * par;
        const h = 36 + Math.sin(wx * 0.013 + layer) * 14 + Math.sin(wx * 0.005) * 10;
        ctx.fillRect(x, 150 - h - layer * 8, 4, h + 40);
      }
    }
    // ground
    for (let x = 0; x < 324; x += 2) {
      const wx = x + this.cam;
      const gy = terrain(wx);
      ctx.fillStyle = d.ground;
      ctx.fillRect(x, gy, 2, 4);
      ctx.fillStyle = d.ground2;
      ctx.fillRect(x, gy + 4, 2, 180 - gy);
      if ((wx | 0) % 16 < 2) {
        ctx.fillStyle = shade(d.ground2, -0.25);
        ctx.fillRect(x, gy + 8, 2, 6);
      }
    }
    // props
    for (const p of this.props) {
      if (p.dead) continue;
      const x = p.x - this.cam;
      if (x < -20 || x > 340) continue;
      const gy = terrain(p.x);
      if (p.kind === 0) {
        ctx.fillStyle = d.rock;
        ctx.fillRect(x - 5, gy - 8, 10, 8);
        ctx.fillRect(x - 3, gy - 11, 6, 3);
        ctx.fillStyle = shade(d.rock, -0.3);
        ctx.fillRect(x - 5, gy - 3, 10, 3);
      } else if (p.kind === 1) {
        drawSprite(ctx, SPRITES.crate, x - 8, gy - 12, 2, { A: "#9a7a4a", B: "#6a4f2a" });
      } else {
        ctx.fillStyle = "#8fd13f";
        ctx.fillRect(x - 4, gy - 10, 8, 10);
        ctx.fillRect(x - 3, gy - 13, 6, 3);
        ctx.fillStyle = "#3c6b1e";
        ctx.fillRect(x - 2, gy - 8, 4, 5);
      }
    }
    // parked ship
    const sx = this.shipX - this.cam;
    if (sx > -40 && sx < 360) {
      const s = getSave();
      drawShip(ctx, s.ship, sx, terrain(this.shipX) - 12, 1, s.paint, s.decal, 0, s.trail, this.t);
      ctx.fillStyle = shade(d.ground2, -0.4);
      ctx.fillRect(sx - 12, terrain(this.shipX) - 1, 24, 2);
    }
    // home / build pad
    const ps = planetSave(d.id);
    const hx = this.padX - this.cam;
    if (hx > -80 && hx < 400) {
      const gy = terrain(this.padX);
      if (!ps.home.built) {
        ctx.fillStyle = Math.floor(this.t * 2) % 2 ? "#4a8a9a" : "#3a6a7a";
        for (let i = 0; i < 5; i++) ctx.fillRect(hx - 24 + i * 12, gy - 2, 8, 2);
        ctx.fillStyle = "rgba(120,200,220,0.35)";
        ctx.fillRect(hx - 22, gy - 26, 44, 24);
        drawTextCentered(ctx, "BUILD PAD", hx, gy - 36, "#9fe4ff", 1, "#160f1c");
      } else {
        drawHome(ctx, hx, gy, ps.home.style, ps.home.level, this.t);
        drawTextCentered(ctx, ps.home.name, hx, gy - 52 - ps.home.level * 2, "#ffe9a8", 1, "#160f1c");
      }
    }
    // aliens
    for (const al of this.aliens) {
      const x = al.x - this.cam;
      if (x < -20 || x > 340) continue;
      if (al.hit > 0) ctx.globalAlpha = 0.6;
      const key = `alien_${d.alien}`;
      const spr = SPRITES[key] || SPRITES.alien_crawler;
      drawSprite(ctx, spr, x - 8, al.y - 6, 2, {}, al.dir < 0);
      ctx.globalAlpha = 1;
      if (al.hp < al.max) bar(ctx, x - 8, al.y - 12, 16, 2, al.hp / al.max, "#d0402e");
    }
    // shots
    for (const s of this.shots) {
      ctx.fillStyle = s.enemy ? "#8fe04a" : "#ffe9a8";
      ctx.fillRect((s.x - this.cam) | 0, s.y | 0, s.enemy ? 3 : 5, 2);
    }
    this.parts.draw(ctx);
    // player
    if (!(this.inv > 0 && Math.floor(this.t * 20) % 2 === 0))
      drawHuman(ctx, this.px - this.cam, this.py, 1, charCfg(), this.onGround ? this.frame : 1, this.face < 0);
    this.floats.draw(ctx);

    // weather
    if (d.id === "pluto" || d.id === "uranus" || d.id === "neptune") {
      ctx.fillStyle = "#dff4ff";
      for (let i = 0; i < 40; i++) {
        const x = (i * 97 + this.t * 20) % 320;
        const y = (i * 53 + this.t * 40) % 180;
        ctx.fillRect(x | 0, y | 0, 1, 2);
      }
    } else if (d.id === "sun" || d.id === "venus" || d.id === "mercury") {
      ctx.fillStyle = "#ffd08a";
      for (let i = 0; i < 26; i++) {
        const x = (i * 131 - this.t * 60) % 320;
        const y = (i * 67 - this.t * 30) % 180;
        ctx.fillRect(((x + 320) % 320) | 0, ((y + 180) % 180) | 0, 2, 1);
      }
    } else if (d.id === "mars") {
      ctx.globalAlpha = 0.25;
      ctx.fillStyle = "#c9704a";
      for (let i = 0; i < 18; i++) ctx.fillRect(((i * 71 - this.t * 90) % 340) | 0, 100 + ((i * 29) % 70), 20, 2);
      ctx.globalAlpha = 1;
    }

    // HUD
    ctx.fillStyle = "rgba(10,6,16,0.72)";
    ctx.fillRect(0, 0, 320, 11);
    drawText(ctx, d.name, 4, 3, "#ffe9a8", 1, "#160f1c");
    drawSprite(ctx, SPRITES.coin, 92, 3, 1, {});
    drawText(ctx, String(c.save.coins), 99, 3, "#ffd23c");
    drawSprite(ctx, SPRITES.gem, 140, 3, 1, {});
    drawText(ctx, String(c.save.gems), 147, 3, "#9fe4ff");
    drawText(ctx, "SUIT", 186, 3, "#c8bcd0");
    bar(ctx, 210, 3, 48, 5, this.hp / this.maxHp, this.hp > 35 ? "#6fc04a" : "#d0402e");
    drawText(ctx, `K${planetSave(d.id).kills}`, 266, 3, "#ff9a8a");
    drawText(ctx, `W${planetSave(d.id).wrecked}`, 292, 3, "#9fe4ff");

    if (this.mode === "play") {
      if (this.hint) {
        panel(ctx, 160 - (this.hint.length * 6) / 2 - 6, 154, this.hint.length * 6 + 12, 13);
        drawTextCentered(ctx, this.hint, 160, 158, "#ffe9a8");
      } else prompt(ctx, "MOVE < >   JUMP ^   SHOOT FIRE   ESC MAP", 170, true, this.t);
    } else {
      const title = this.mode === "build" ? "BUILD YOUR HOME" : "SHIP TERMINAL";
      panel(ctx, 36, 40, 248, 14 + Math.min(6, this.menu.items.length) * 13 + 6);
      drawTextCentered(ctx, title, 160, 45, "#ffe9a8");
      this.menu.draw(ctx, 40, 58, 240, 13, this.t);
    }
  }
}

export function drawHome(ctx: CanvasRenderingContext2D, x: number, gy: number, styleId: string, level: number, t: number) {
  const st = HOME_STYLES.find((h) => h.id === styleId) || HOME_STYLES[0];
  const w = 44 + level * 4;
  const h = 30 + level * 3;
  const x0 = Math.round(x - w / 2);
  const y0 = Math.round(gy - h);
  ctx.fillStyle = "#160f1c";
  ctx.fillRect(x0 - 1, y0 - 1, w + 2, h + 2);
  ctx.fillStyle = st.wall;
  ctx.fillRect(x0, y0, w, h);
  ctx.fillStyle = st.wall2;
  ctx.fillRect(x0, y0 + h - 6, w, 6);
  for (let i = 0; i < w; i += 8) {
    ctx.fillStyle = i % 16 === 0 ? shade(st.wall, -0.12) : shade(st.wall, 0.06);
    ctx.fillRect(x0 + i, y0 + 4, 7, 4);
  }
  // roof
  ctx.fillStyle = st.roof;
  for (let i = 0; i < 8; i++) ctx.fillRect(x0 - 3 + i * 2, y0 - 8 + i, w + 6 - i * 4, 2);
  ctx.fillStyle = st.roof2;
  ctx.fillRect(x0 - 3, y0 - 2, w + 6, 3);
  // windows
  ctx.fillStyle = Math.floor(t) % 4 === 0 ? "#ffe9a8" : "#7fd0e8";
  ctx.fillRect(x0 + 6, y0 + 12, 9, 8);
  ctx.fillRect(x0 + w - 15, y0 + 12, 9, 8);
  ctx.fillStyle = "#160f1c";
  ctx.fillRect(x0 + 10, y0 + 12, 1, 8);
  ctx.fillRect(x0 + w - 11, y0 + 12, 1, 8);
  // door
  const dw = 10;
  ctx.fillStyle = shade(st.wall2, -0.3);
  ctx.fillRect(x0 + w / 2 - dw / 2, gy - 16, dw, 16);
  ctx.fillStyle = "#ffd23c";
  ctx.fillRect(x0 + w / 2 + 2, gy - 9, 2, 2);
  // antenna per level
  for (let i = 0; i < level; i++) {
    ctx.fillStyle = "#9aa3ad";
    ctx.fillRect(x0 + 6 + i * 10, y0 - 16, 2, 10);
    ctx.fillStyle = Math.floor(t * 2 + i) % 2 ? "#d0402e" : "#6a2a2a";
    ctx.fillRect(x0 + 6 + i * 10, y0 - 18, 2, 2);
  }
}

// ============================== HOME INTERIOR ==============================
export class HomeScene implements Scene {
  music = "planet" as string | null;
  def!: PlanetDef;
  t = 0;
  px = 60;
  face = 1;
  frame = 0;
  walkT = 0;
  cam = 0;
  mode: "play" | "catalog" | "style" = "play";
  menu = new CanvasMenu([], 6);
  parts = new Particles();
  floats = new Floaters();
  hint = "";
  ROOM_W = 420;

  init(c: SceneCtx) {
    this.def = PLANETS.find((p) => p.id === (c.payload?.target || "earth"))!;
    c.sfx("select");
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.parts.update(dt);
    this.floats.update(dt);
    if (this.mode !== "play") {
      this.updateMenu(c);
      return;
    }
    const i = c.input;
    let ax = i.ax;
    if (i.pointer.active && !i.down.left && !i.down.right) {
      const wp = i.pointer.x + this.cam;
      if (Math.abs(wp - this.px) > 6) ax = clamp((wp - this.px) / 30, -1, 1);
    }
    this.px = clamp(this.px + ax * 62 * dt, 16, this.ROOM_W - 20);
    if (ax !== 0) {
      this.face = ax > 0 ? 1 : -1;
      this.walkT += dt * 9;
      this.frame = Math.floor(this.walkT) % 4;
      if (Math.random() < dt * 5) c.sfx("step");
    } else this.frame = 0;
    this.cam = clamp(this.px - 160, 0, this.ROOM_W - 320);

    this.hint = "";
    if (this.px < 34) {
      this.hint = "PRESS [E] : GO OUTSIDE";
      if (i.just("action")) {
        c.sfx("back");
        c.goto("planet", { target: this.def.id });
        return;
      }
    } else if (Math.abs(this.px - (this.ROOM_W - 60)) < 26) {
      this.hint = "PRESS [E] : HOME CATALOG";
      if (i.just("action")) {
        this.openCatalog(c);
        return;
      }
    }
    if (i.just("pause")) {
      c.sfx("back");
      c.goto("planet", { target: this.def.id });
    }
  }

  openCatalog(c: SceneCtx) {
    this.mode = "catalog";
    c.sfx("select");
    const ps = planetSave(this.def.id);
    const up = 800 * ps.home.level;
    this.menu = new CanvasMenu(
      [
        { label: "LIVE HERE (REST + COLLECT)", sub: `+${this.incomeReady()}C`, color: "#6fc04a" },
        { label: `UPGRADE HOME TO LV${ps.home.level + 1}`, sub: `${up}C`, disabled: c.save.coins < up || ps.home.level >= 9, color: "#ffd23c" },
        { label: "CHANGE WALL COLOR", sub: "FREE" },
        { label: "CHANGE FLOOR COLOR", sub: "FREE" },
        { label: "REBUILD STYLE", sub: ">" },
        ...FURNITURE.map((f) => ({ label: `BUY ${f.name}`, sub: `${f.cost}C`, disabled: c.save.coins < f.cost })),
        { label: "CLEAR FURNITURE", sub: "" },
        { label: "CLOSE", sub: "" },
      ],
      6,
    );
  }

  updateMenu(c: SceneCtx) {
    const r = this.menu.update(c, 30, 44, 260, 13);
    if (r === null) return;
    const ps = planetSave(this.def.id);
    if (this.mode === "style") {
      if (r === -1 || r >= HOME_STYLES.length) {
        this.openCatalog(c);
        return;
      }
      const st = HOME_STYLES[r];
      const gem = st.id === "citadel";
      const afford = gem ? c.save.gems >= st.cost : c.save.coins >= st.cost;
      if (!afford) {
        c.sfx("deny");
        return;
      }
      mutate((s) => {
        if (gem) s.gems -= st.cost;
        else s.coins -= st.cost;
        planetSave(this.def.id).home.style = st.id;
      });
      c.sfx("build");
      this.floats.add(160, 60, "STYLE CHANGED", "#6fc04a");
      this.mode = "play";
      return;
    }
    if (r === -1) {
      this.mode = "play";
      return;
    }
    const nFurn = FURNITURE.length;
    if (r === 0) {
      const gain = this.incomeReady();
      if (gain > 0) {
        mutate((s) => {
          s.coins += gain;
          const h = planetSave(this.def.id).home;
          h.lastRest = Date.now();
          h.days = (h.days || 0) + 1;
        });
        c.sfx("levelup");
        c.flash(0.7, "#1a1030");
        this.floats.add(160, 60, `A DAY PASSES... +${gain}C`, "#6fc04a");
        this.mode = "play";
      } else {
        c.sfx("deny");
        this.floats.add(160, 60, "NOTHING TO COLLECT YET", "#ff9a8a");
      }
      return;
    }
    if (r === 1) {
      const up = 800 * ps.home.level;
      if (c.save.coins >= up && ps.home.level < 9) {
        mutate((s) => {
          s.coins -= up;
          planetSave(this.def.id).home.level++;
        });
        c.sfx("levelup");
        this.floats.add(160, 60, `HOME LV${planetSave(this.def.id).home.level}!`, "#ffd23c");
        this.openCatalog(c);
      } else c.sfx("deny");
    } else if (r === 2) {
      mutate(() => {
        const h = planetSave(this.def.id).home;
        h.wall = (h.wall + 1) % WALLS.length;
      });
      c.sfx("blip");
    } else if (r === 3) {
      mutate(() => {
        const h = planetSave(this.def.id).home;
        h.floor = (h.floor + 1) % FLOORS.length;
      });
      c.sfx("blip");
    } else if (r === 4) {
      this.mode = "style";
      this.menu = new CanvasMenu(
        HOME_STYLES.map((h) => ({ label: h.name, sub: h.id === "citadel" ? `${h.cost} GEM` : `${h.cost}C` })).concat([{ label: "BACK", sub: "" }]),
        6,
      );
      c.sfx("select");
    } else if (r >= 5 && r < 5 + nFurn) {
      const f = FURNITURE[r - 5];
      if (c.save.coins >= f.cost) {
        mutate((s) => {
          s.coins -= f.cost;
          const h = planetSave(this.def.id).home;
          h.furniture.push({ id: f.id, x: 50 + h.furniture.length * 42 });
        });
        c.sfx("buy");
        this.floats.add(160, 60, `${f.name} PLACED`, "#6fc04a");
        this.openCatalog(c);
      } else c.sfx("deny");
    } else if (r === 5 + nFurn) {
      mutate(() => (planetSave(this.def.id).home.furniture = []));
      c.sfx("wreck");
    } else {
      this.mode = "play";
      c.sfx("back");
    }
  }

  /** Passive residence income: accrues over real time, capped by home level. */
  incomeReady(): number {
    const h = planetSave(this.def.id).home;
    const last = h.lastRest || 0;
    const mins = (Date.now() - last) / 60000;
    const rate = 30 * h.level + this.def.dist * 10;
    return Math.min(Math.round(rate * 12), Math.round(Math.min(mins, 240) * rate));
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    const ps = planetSave(this.def.id);
    const h = ps.home;
    const wall = WALLS[h.wall % WALLS.length];
    const floor = FLOORS[h.floor % FLOORS.length];
    const fy = 140;
    ctx.fillStyle = wall;
    ctx.fillRect(0, 0, 320, fy);
    // wall panels
    for (let x = -(this.cam % 32); x < 320; x += 32) {
      ctx.fillStyle = shade(wall, -0.12);
      ctx.fillRect(x, 0, 2, fy);
    }
    ctx.fillStyle = shade(wall, 0.08);
    ctx.fillRect(0, 12, 320, 2);
    ctx.fillStyle = floor;
    ctx.fillRect(0, fy, 320, 40);
    ctx.fillStyle = shade(floor, -0.2);
    for (let x = -(this.cam % 16); x < 320; x += 16) ctx.fillRect(x, fy, 1, 40);
    ctx.fillStyle = shade(floor, 0.12);
    ctx.fillRect(0, fy, 320, 2);

    // window with planet view
    const wx = 150 - this.cam;
    ctx.fillStyle = "#160f1c";
    ctx.fillRect(wx - 2, 32, 64, 44);
    ctx.fillStyle = "#0a0716";
    ctx.fillRect(wx, 34, 60, 40);
    ctx.save();
    ctx.beginPath();
    ctx.rect(wx, 34, 60, 40);
    ctx.clip();
    drawPlanet(ctx, wx + 42, 66, 14, this.def, this.t * 0.3, 2);
    ctx.fillStyle = "#ffffff";
    for (let i = 0; i < 14; i++) ctx.fillRect(wx + ((i * 37) % 60), 36 + ((i * 17) % 36), 1, 1);
    ctx.restore();
    ctx.fillStyle = shade(wall, -0.3);
    ctx.fillRect(wx + 28, 34, 2, 40);

    // door
    const dx = 10 - this.cam;
    drawSprite(ctx, SPRITES.door, dx, fy - 32, 4, { B: "#6a5a4a", W: "#c2c8cf" });
    drawTextCentered(ctx, "EXIT", dx + 16, fy - 40, "#c8bcd0", 1, "#160f1c");

    // terminal
    const tx = this.ROOM_W - 60 - this.cam;
    ctx.fillStyle = "#3a3a46";
    ctx.fillRect(tx - 10, fy - 26, 20, 26);
    ctx.fillStyle = Math.floor(this.t * 2) % 2 ? "#6fc04a" : "#2a6a2a";
    ctx.fillRect(tx - 7, fy - 22, 14, 10);
    ctx.fillStyle = "#9aa3ad";
    ctx.fillRect(tx - 8, fy - 8, 16, 3);
    drawTextCentered(ctx, "CATALOG", tx, fy - 34, "#9fe4ff", 1, "#160f1c");

    // furniture
    for (const f of h.furniture) drawFurniture(ctx, f.id, f.x - this.cam, fy, this.t);

    this.parts.draw(ctx);
    drawHuman(ctx, this.px - this.cam, fy - 14, 1, charCfg(), this.frame, this.face < 0);
    this.floats.draw(ctx);

    ctx.fillStyle = "rgba(10,6,16,0.72)";
    ctx.fillRect(0, 0, 320, 11);
    drawText(ctx, `${h.name} LV${h.level}`, 4, 3, "#ffe9a8", 1, "#160f1c");
    drawText(ctx, `${this.def.name}  DAY ${h.days || 0}`, 118, 3, "#9fe4ff");
    drawSprite(ctx, SPRITES.coin, 232, 3, 1, {});
    drawText(ctx, String(c.save.coins), 239, 3, "#ffd23c");
    drawSprite(ctx, SPRITES.gem, 284, 3, 1, {});
    drawText(ctx, String(c.save.gems), 291, 3, "#9fe4ff");

    if (this.mode === "play") {
      if (this.hint) {
        panel(ctx, 160 - (this.hint.length * 6) / 2 - 6, 160, this.hint.length * 6 + 12, 13);
        drawTextCentered(ctx, this.hint, 160, 164, "#ffe9a8");
      } else prompt(ctx, "WALK < >    [E] INTERACT    ESC LEAVE", 168, true, this.t);
    } else {
      panel(ctx, 26, 30, 268, 100);
      drawTextCentered(ctx, this.mode === "style" ? "CHOOSE A STYLE" : "HOME CATALOG", 160, 35, "#ffe9a8");
      this.menu.draw(ctx, 30, 48, 260, 13, this.t);
      drawTextCentered(ctx, "ESC / BACK TO CLOSE", 160, 122, "#5f5070");
    }
  }
}

export function drawFurniture(ctx: CanvasRenderingContext2D, id: string, x: number, fy: number, t: number) {
  if (x < -50 || x > 360) return;
  const X = Math.round(x);
  switch (id) {
    case "bed":
      ctx.fillStyle = "#6a4f2a";
      ctx.fillRect(X - 13, fy - 10, 26, 10);
      ctx.fillStyle = "#c04a3a";
      ctx.fillRect(X - 13, fy - 14, 26, 5);
      ctx.fillStyle = "#e8dcc0";
      ctx.fillRect(X - 12, fy - 17, 8, 5);
      ctx.fillStyle = "#160f1c";
      ctx.fillRect(X - 14, fy - 18, 2, 18);
      break;
    case "lamp":
      ctx.fillStyle = "#6a6a78";
      ctx.fillRect(X - 1, fy - 18, 2, 18);
      ctx.fillStyle = Math.floor(t * 3) % 8 === 0 ? "#ffe9a8" : "#ffd23c";
      ctx.fillRect(X - 4, fy - 24, 8, 6);
      ctx.globalAlpha = 0.18;
      ctx.fillStyle = "#ffe9a8";
      ctx.fillRect(X - 10, fy - 22, 20, 22);
      ctx.globalAlpha = 1;
      break;
    case "console":
      ctx.fillStyle = "#3a3a46";
      ctx.fillRect(X - 11, fy - 16, 22, 16);
      ctx.fillStyle = Math.floor(t * 4) % 2 ? "#7fd0e8" : "#3a7a9a";
      ctx.fillRect(X - 8, fy - 13, 16, 8);
      ctx.fillStyle = "#ffd23c";
      ctx.fillRect(X - 8 + ((Math.floor(t * 6) * 3) % 14), fy - 11, 2, 2);
      break;
    case "plant":
      ctx.fillStyle = "#6a4f2a";
      ctx.fillRect(X - 5, fy - 6, 10, 6);
      ctx.fillStyle = "#8fd13f";
      ctx.fillRect(X - 2, fy - 16, 4, 10);
      ctx.fillRect(X - 6, fy - 14 + Math.sin(t * 2) * 1, 5, 3);
      ctx.fillRect(X + 2, fy - 12 - Math.sin(t * 2) * 1, 5, 3);
      ctx.fillStyle = "#e07ad0";
      ctx.fillRect(X - 3, fy - 19, 6, 3);
      break;
    case "rug":
      ctx.fillStyle = "#8a3a5a";
      ctx.fillRect(X - 15, fy - 3, 30, 3);
      ctx.fillStyle = "#d8b06a";
      for (let i = 0; i < 6; i++) ctx.fillRect(X - 13 + i * 5, fy - 2, 2, 1);
      break;
    case "tv":
      ctx.fillStyle = "#22222a";
      ctx.fillRect(X - 12, fy - 24, 24, 14);
      ctx.fillStyle = ["#7fd0e8", "#e0562a", "#8fd13f", "#ffd23c"][Math.floor(t * 3) % 4];
      ctx.fillRect(X - 10, fy - 22, 20, 10);
      ctx.fillStyle = "#3a3a46";
      ctx.fillRect(X - 2, fy - 10, 4, 10);
      break;
    case "crate":
      drawSprite(ctx, SPRITES.crate, X - 6, fy - 12, 2, { A: "#9a7a4a", B: "#6a4f2a" });
      break;
    case "trophy":
      ctx.fillStyle = "#3a3a46";
      ctx.fillRect(X - 5, fy - 4, 10, 4);
      ctx.fillStyle = "#ffd23c";
      ctx.fillRect(X - 4, fy - 14, 8, 10);
      ctx.fillStyle = "#000000";
      ctx.fillRect(X - 2, fy - 12, 4, 6);
      ctx.fillStyle = "#ffe9a8";
      ctx.fillRect(X - 1, fy - 18, 2, 4);
      break;
  }
}

export { textWidth, mix, irnd };
