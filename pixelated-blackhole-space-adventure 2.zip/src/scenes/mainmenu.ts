import type { Scene, SceneCtx } from "../game/engine";
import { drawText, drawTextCentered, drawTitleText, textWidth } from "../game/font";
import { Starfield, drawBlackHole, drawPlanet, drawHuman, makeNebula, asteroidCanvas, drawShip, shade } from "../game/sprites";
import { PLANETS, SKINS, SUITS, HAIRS, VISORS } from "../game/data";
import { getSave } from "../game/save";
import { rnd, irnd, clamp } from "./common";

const ITEMS = [
  { id: "map", label: "START GAME", sub: "NAV CHART" },
  { id: "launch", label: "BLACK HOLE RUN", sub: "MAIN MISSION" },
  { id: "hangar", label: "HANGAR", sub: "SHIPS + UPGRADES" },
  { id: "character", label: "PILOT", sub: "CUSTOMIZE" },
  { id: "shop", label: "SHOP", sub: "COINS + GEMS" },
  { id: "settings", label: "SETTINGS", sub: "" },
  { id: "codes", label: "CODES / SAVE", sub: "" },
  { id: "credits", label: "CREDITS", sub: "" },
];

export class MainMenuScene implements Scene {
  music = "menu" as string | null;
  t = 0;
  sel = 0;
  stars = new Starfield(150, 320, 180);
  neb!: HTMLCanvasElement;
  rocks: { x: number; y: number; r: number; v: number; s: number; c: string }[] = [];
  shipX = -40;

  init() {
    this.neb = makeNebula(320, 180, ["#2a1440", "#3d1d52", "#4a2338", "#161033"], 70);
    for (let i = 0; i < 9; i++)
      this.rocks.push({ x: rnd(0, 320), y: rnd(20, 170), r: rnd(3, 7), v: irnd(0, 7), s: rnd(4, 14), c: ["#6f6f60", "#8a7a6a", "#5a4a4a"][irnd(0, 2)] });
  }

  update(dt: number, c: SceneCtx) {
    this.t += dt;
    this.stars.update(dt, 5, 0, 320, 180);
    const i = c.input;
    if (i.just("up")) {
      this.sel = (this.sel - 1 + ITEMS.length) % ITEMS.length;
      c.sfx("move");
    }
    if (i.just("down")) {
      this.sel = (this.sel + 1) % ITEMS.length;
      c.sfx("move");
    }
    for (const r of this.rocks) {
      r.x -= (6 + r.s * 0.4) * dt;
      if (r.x < -12) {
        r.x = 332;
        r.y = rnd(16, 172);
      }
    }
    this.shipX += 22 * dt;
    if (this.shipX > 360) this.shipX = -40;

    const listY = 70;
    if (i.pointer.downNow) {
      const row = Math.floor((i.pointer.y - listY) / 12);
      if (i.pointer.x < 190 && row >= 0 && row < ITEMS.length) {
        if (row === this.sel) this.go(c);
        else {
          this.sel = row;
          c.sfx("move");
        }
      }
    }
    if (i.just("fire") || i.just("action") || i.just("start")) this.go(c);
  }

  go(c: SceneCtx) {
    c.sfx("select");
    c.goto(ITEMS[this.sel].id);
  }

  draw(ctx: CanvasRenderingContext2D, c: SceneCtx) {
    ctx.fillStyle = "#07040f";
    ctx.fillRect(0, 0, 320, 180);
    ctx.globalAlpha = 0.75;
    ctx.drawImage(this.neb, 0, 0);
    ctx.globalAlpha = 1;
    this.stars.draw(ctx);

    // hero black hole on the right (ARCO-style focal art)
    drawBlackHole(ctx, 236, 74, 26, this.t, 2, 0.3, 1);
    // small second hole far away
    drawBlackHole(ctx, 300, 22, 6, this.t * 1.4, 2, 0.32, 0.6);
    // planet below-right
    drawPlanet(ctx, 292, 132, 20, PLANETS[3], this.t * 0.3, 2);

    for (const r of this.rocks) {
      const s = Math.max(3, Math.round(r.s));
      ctx.drawImage(asteroidCanvas(r.v, 0, r.c), r.x | 0, r.y | 0, s, s);
    }

    // drifting ship
    const sv = getSave();
    drawShip(ctx, sv.ship, this.shipX, 150 + Math.sin(this.t) * 3, 1, sv.paint, sv.decal, 0.5, sv.trail, this.t);

    // ground ledge with the pilot standing (like the character in the reference art)
    ctx.fillStyle = "#1a1224";
    ctx.beginPath();
    ctx.moveTo(196, 180);
    ctx.lineTo(206, 166);
    ctx.lineTo(258, 162);
    ctx.lineTo(288, 172);
    ctx.lineTo(320, 168);
    ctx.lineTo(320, 180);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = "#2c1d3a";
    ctx.fillRect(206, 165, 52, 2);
    ctx.fillStyle = "#3a2850";
    for (let i = 0; i < 6; i++) ctx.fillRect(212 + i * 9, 168 + (i % 2), 4, 2);
    const ch = sv.char;
    drawHuman(ctx, 236, 148, 1, { skin: SKINS[ch.skin], suit: SUITS[ch.suit], hair: HAIRS[ch.hair], visor: VISORS[ch.visor] }, Math.floor(this.t * 2) % 2 === 0 ? 0 : 2);

    // dark gradient on the left so the text pops
    for (let x = 0; x < 200; x++) {
      const a = clamp(1 - x / 200, 0, 1) * 0.88;
      ctx.fillStyle = `rgba(8,4,14,${a})`;
      ctx.fillRect(x, 0, 1, 180);
    }

    // TITLE
    drawTitleText(ctx, "VOIDFALL", 10, 14, 4, ["#fff6d8", "#ffe9a8", "#ffc457", "#f2892a", "#d4561f", "#a12f1d", "#6b1c2c"], "#12071a");
    drawText(ctx, "RIDE A SPACESHIP INTO A BLACK HOLE", 12, 48, "#9a86b0", 1, "#0d0714");
    drawText(ctx, "AND SEE WHAT HAPPENS", 12, 58, "#6f5f86", 1, "#0d0714");

    // MENU LIST
    const listY = 70;
    for (let i = 0; i < ITEMS.length; i++) {
      const y = listY + i * 12;
      const on = i === this.sel;
      if (on) {
        ctx.fillStyle = "rgba(216,176,106,0.14)";
        ctx.fillRect(6, y - 2, 178, 12);
        ctx.fillStyle = "#d8b06a";
        ctx.fillRect(6, y - 2, 2, 12);
        if (Math.floor(this.t * 3) % 2 === 0) drawText(ctx, ">", 12, y, "#ffd23c", 1, "#0d0714");
      }
      drawText(ctx, ITEMS[i].label, 22, y, on ? "#fff6d8" : "#a294b8", 1, "#0d0714");
      if (on && ITEMS[i].sub) drawText(ctx, ITEMS[i].sub, 186 - textWidth(ITEMS[i].sub, 1), y, "#6f5f86", 1, "#0d0714");
    }

    // stats strip
    ctx.fillStyle = "rgba(10,6,18,0.8)";
    ctx.fillRect(0, 168, 320, 12);
    ctx.fillStyle = "#2c1d3a";
    ctx.fillRect(0, 167, 320, 1);
    drawText(ctx, `BLACK HOLES ENTERED: ${c.save.holes}`, 4, 171, "#ffd23c", 1, "#0d0714");
    drawText(ctx, `COINS ${c.save.coins}  GEMS ${c.save.gems}`, 150, 171, "#9fe4ff", 1, "#0d0714");
    const cr = "CREDITS: 1MFINZO / LOXA / DEVDEV1";
    drawText(ctx, cr, 320 - textWidth(cr, 1) - 2, 160, "#4f4364");
    void shade;
    void drawTextCentered;
  }
}
